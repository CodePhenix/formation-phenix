const imgAutumn = document.querySelector("#autumn-img");
const hideBtn = document.querySelector("#hide-img");

hideBtn.addEventListener("click", () => {
    const isHidden = imgAutumn.classList.toggle("hidden");

    imgAutumn.setAttribute("aria-hidden", isHidden);
});

imgAutumn.addEventListener("click", toggleZoom);

imgAutumn.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        toggleZoom();
    }
});

function toggleZoom() {
    imgAutumn.classList.toggle("zoom");
}

const formulaireConnexion = document.querySelector('form');

formulaireConnexion.addEventListener('submit', function (event) {

    event.preventDefault();
    
    const formData = new FormData(formulaireConnexion);

    const values = Object.fromEntries(formData.entries());

    console.log(values);

});