# Création de sites web sécurisés, accessibles et conformes en 2026

## Sécurisation et tests dans un projet web
Tout d'abord, il faut noter que le frontend seul ne garantit jamais la sécurité d'un site web. Toute validation critique doit être faite côté serveur. C'est certes le premier rempart contre les attaques, mais toute logique de sécurisation avancée se fera en backend. Cependant, de bonnes pratiques viennent améliorer l'expérience utilisateur, et prémunir contre certaines attaques.

### Les types d'attaques
- **Brute Force** : Tentatives répétées de deviner un mot de passe (via script ou logiciel) : en tentant énormément de possibilités comme `azerty`, `azerty0`, `azerty1`, etc.
- **Attaques XSS (Cross-Site Scripting)** : Vulnérabilités liées à l'insertion de code HTML ou
JavaScript non sécurisé dans une page web, pouvant voler des informations ou
modifier l'affichage : *voir l'exemple xss*
- **Attaques CSRF (Cross-Site Request Forgery)** : Forcer un utilisateur connecté à réaliser une
action non désirée sur un site web où il est authentifié. Le principe repose sur une idée simple :
  - Vous êtes connectés à un site (ex : banque, réseau social).
  - Votre navigateur garde une session active (cookie).
  - Vous visitez un site malveillant sans vous en rendre compte.
  - Ce site envoie une requête vers le site légitime (ex : "transférer de l'argent").
  - Comme votre navigateur est déjà connecté, il joint automatiquement vos cookies.
  - Le site légitime pense que c'est vous qui avez demandé l'action.
- **Injection SQL** : Insertion de code SQL (le langage des bases de données) malveillant dans des requêtes pour accéder à la BDD et supprimer ou modifier des données (injecter du code en dehors des limites de l'entrée utilisateur attendue). Prenons par exemple un formulaire de connexion côté frontend qui attend un nom d'utilisateur et un mot de passe, en envoyant un signal au backend qui dira à la BDD ceci : `SELECT user_id FROM users WHERE name = '(nom tapé dans l'input)' AND password = '(mot de passe tapé dans l'input)';` → si le backend ne vérifie pas les données entrantes pour garantir la sécurité du site, un hacker pourrait alors fournir les informations suivantes :
  - Utilisateur : Dupont';--
  - Mot de passe : n'importe lequel

  La requête devient alors : `SELECT user_id FROM Users WHERE name = 'Dupont';--' AND password = 'blabla';` Les caractères -- marquent le début d'un commentaire en SQL. La requête est donc équivalente à : `SELECT uid FROM Users WHERE name = 'Dupont';` Ainsi, l'attaquant peut alors se connecter sous l'utilisateur Dupont avec n'importe quel mot de passe. Il s'agit d'une injection de SQL réussie, car l'attaquant est parvenu à injecter les caractères qu'il voulait pour modifier le comportement de la requête.

### Sécurisation frontend : validation des données
Pour se prémunir contre ces attaques, il est déjà important de gérer la **validation des données** reçues de l'utilisateur :
- Côté backend, c'est obligatoire pour la sécurité.
- Côté frontend : on peut aussi sécuriser la donnée reçue de l'utilisateur en JavaScript → on attend par exemple d'un input d'email qu'il récupère des emails en JS front au bon format d'email (serveur mail qui échoue, accumulation de fausses adresses qui pèsent lourds, et accumulation des erreurs d'envoi). Exemple en JS frontend :
  ```html
  <input type="email" id="email" name="email" required pattern="^[a-z0-9](\.?[a-z0-9_-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*\.[a-z]{2,}$">
  ```
  Cette regex (ou expression régulière, regular expression en anglais) décrite dans l'attribut `pattern` de l'input email couvre les cas les plus courants, mais ne remplace pas une validation backend. Ici, elle :
    - interdit les .. dans l'email
    - interdit de commencer/finir par un point
    - autorise prenom.nom, prenom_nom, etc.
    - gère les sous-domaines (mail.google.com)
    - reste compatible avec la plupart des emails réels

    On utilise des regex dans les formulaires pour la validation des champs (email, numéro de téléphone et mot de passe au bon format) : on empêche ainsi les erreurs côté backend en lui envoyant des données propres, on améliore la sécurité en bloquant des combinaisons de caractères pouvant être du code malveillant, et on standardise la donnée pour qu'elle soit uniforme et propre en base de données.

### Sécurisation frontend : protection contre les attaques
- **Brute Force** :

Avoir en amont forcé les utilisateurs à renseigner des mots de passe complexes à deviner/hacker grâce à l'attribut `pattern` dans les input de type password.
- **XSS (Cross-Site Scripting)** : 

*voir l'exemple xss*

Il faut également échapper toutes les entrées utilisateurs = remplacer certains caractères spéciaux par des entités HTML qui ne seront pas interprétées comme du code par le navigateur. Les principaux caractères à échapper sont :
  ```html
  <	&lt;
  >	&gt;
  &	&amp;
  "	&quot;
  '	&#x27;
  ```

  De manière générale, utilisez textContent pour afficher du contenu utilisateur, car il est interprété comme du texte brut, alors que innerHTML interprète le contenu comme du HTML et peut exécuter du code malveillant.

- **CSRF (Cross-Site Request Forgery)** : utilisation des tokens CSRF dans les formulaires = un token CSRF est une valeur aléatoire et secrète générée par le serveur pour chaque session ou formulaire. C'est une valeur secrète, unique et imprévisible, qui sert à vérifier que la requête vient bien de votre site et non d'un site malveillant. Exemple en HTML :
  ```html
  <form method="POST">
    <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
    <button type="submit">Envoyer</button>
  </form>
  ```
  Quand l'utilisateur charge une page (ex : formulaire), le serveur :
  - génère un token unique,
  - le stocke côté serveur (ou dans la session),
  - l'insère dans le formulaire HTML.

  Puis, quand l'utilisateur soumet le formulaire :
  - le token est envoyé avec la requête.

  Ensuite, le serveur vérifie :
  - si le token reçu correspond à celui stocké,
  - s'il est valide pour cette session.

  Un site malveillant :
  - peut envoyer une requête (par exemple en ayant dans le HTML : `<img src="https://banque.com/transfer?to=attaquant&amount=1000">`),
  - le navigateur envoie également dans cette requête les cookeis toujours en cours (par exemple : session_id=ABC123),
  - MAIS le site malveillant ne peut pas lire le token CSRF du vrai site,
  - donc il ne peut pas le deviner ni le reproduire.

- **Injection SQL** : utilisation de requêtes préparées côté backend (on utilise $1, $2, etc. en PostgreSQL par exemple), mais le frontend peut aussi 'échapper' certains caractères, comme par exemple `;--`.

### Sécurisation : autres pratiques
- **Chiffrement**
  - HTTPS obligatoire.
  - Hashing sécurisé pour les mots de passe : utilisation de bcrypt (algorithme de hachage de mots de passe conçu pour stocker des mots de passe de façon sécurisée).

- **Tests recommandés**
  - Tests unitaires (ex : Jest, Vitest).
  - Tests d'intégration (ex : Cypress, Playwright).
  - Audit sécurité : OWASP ZAP, Snyk, SonarQube.

### Conservation et protection des données
- Stocker **uniquement le nécessaire**.
- **Chiffrement des données sensibles** = transformer des données lisibles (texte clair) en données illisibles (texte chiffré), pour qu'elles ne soient compréhensibles que par quelqu'un qui possède la clé. Les données sensibles sont : mots de passe, numéros de carte, informations médicales... De manière générale, un bonne pratique est de ne jamais stocker ces données en clair, même sur le serveur.
- **Anonymisation/pseudonymisation** lorsque possible.
- **RGPD & CNIL** :
  - Consentement explicite.
  - Droit d'accès, de rectification et de suppression.
  - Notification obligatoire en cas de fuite.
  - Limitation de la durée de conservation.

---

## Accessibilité (Handicap)
### Normes
- **WCAG 2.2 ("Web Content Accessibility Guidelines" : conseils donnés par le W3C)**
  - Texte alternatif pour images.
  - Contraste suffisant (ratio ≥ 4.5:1 pour le texte normal : la différence de luminosité et de couleur entre le texte et son fond).
  - Navigation clavier complète :
  - Focus visible (désigne l'état actif d'un élément interactif (bouton, lien, champ de formulaire) lorsqu'on navigue au clavier (avec Tab par exemple)).

- **RGAA (Référentiel général d'amélioration de l'accessibilité en France)**
  - Obligatoire pour sites publics.
  - Checklist de 117 critères pour conformité.

- **W3C (World Wide Web Consortium)**
  - Validation HTML/CSS.
  - Compatibilité avec navigateurs et lecteurs d'écran.

### Bonnes pratiques front-end
- Formulaires accessibles.

- Images et médias :
  - `alt` textuel pour les images.
  - Sous-titres et transcriptions pour vidéos.

- Tests :
  - Lecteurs d'écran : NVDA, VoiceOver.
  - Validation automatique : axe DevTools, Wave.

- Déplacement au clavier :
  - Utilisation de tabindex en HTML :
  ```HTML
    <div class="product-card" tabindex="0" role="button">
      <h3>Produit A</h3>
      <p>Description</p>
    </div>
  ```
  - Utilisation de `:focus` ou `:focus-visible` en CSS :
  ```CSS
    .product-card:focus-visible {
      outline: 2px solid blue;
      outline-offset: 3px;
    }
  ```
  - Gérer les évènements clavier en JS :
  ```js
    const card = document.querySelector(".product-card");

    card.addEventListener("click", openProduct);

    card.addEventListener("keydown", (evenement) => {
      if (evenement.key === "Enter" || evenement.key === " ") {
        evenement.preventDefault();
        openProduct();
      }
    });
  ```

---

## Éco-conception web
- Réduire le poids des pages :
  - Compression des images.
  - Lazy loading (charger une ressource uniquement quand elle devient nécessaire : `<img src="autumn.jpg" loading="lazy" alt="Forêt en automne">`).
- Minifier CSS/JS (supprimer tout ce qui est inutile dans le code sans changer son comportement), comme passer de :
  ```css
  button {
    background-color: blue;
    color: white;
  }
  ```
  à :
  ```css
  button{background-color:blue;color:white}
  ```
  Ne pas faire ça à la main, on a des outils pour ça maintenant (c'est surtout utile pour du code lourd de base).
- Design sobre pour diminuer l'énergie consommée.
- Éviter animations lourdes non essentielles.
- Évaluer l'empreinte carbone des pages (outils comme **Website Carbon Calculator** sur le web).

---

## Obligations légales et conformité
### RGPD et CNIL
- Consentement explicite pour cookies et collecte de données.
- Mentionner les finalités et destinataires.
- Droit à l'accès, rectification, suppression.
- Notification des violations dans les 72h.

### LCEN (France)
- Identification claire de l'éditeur.
- Coordonnées valides.
- Responsabilité sur les contenus publiés.

### Pages obligatoires
1. **Mentions légales** : éditeur, contact, hébergeur.
2. **Politique de confidentialité** : collecte, finalités, partage.
3. **Politique des cookies** : consentement avant tracking.
4. **CGV / CGU** : modalités de vente ou d'utilisation, responsabilités.

---

**En 2026 :**  
Tous les sites modernes doivent combiner **sécurité, accessibilité, performance éco-responsable et conformité légale**, dès la conception : ce sont maintenant des standards, pas des options.
