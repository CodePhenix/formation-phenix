// Exemple d'utilisation de innerHTML() :
const newBtnContainer = document.querySelector('#new-btn-container');
newBtnContainer.innerHTML = "<button id='submit'>Valider</button>"
// Formidable, on peut insérer directement dans le DOM des balises !

// Problème, c'est un risque d'attaque XSS, comme dans l'exemple ci-dessous :
const fullname = document.querySelector('#fullname');
const submitBtn = document.querySelector('#submit');

submitBtn.addEventListener("click", function () {
    const userLastname = document.querySelector('#user-lastname').value;
    const userFirstname = document.querySelector('#user-firstname').value;

    const userPseudo = `${userFirstname} ${userLastname}`;



    // MAUVAISE PRATIQUE :
    fullname.innerHTML = userPseudo;
    // Si l'utilisateur tape dans un des input : '<img src="x" onerror="alert('Attention aux attaques XSS !')">' :
    // l'image qui n'a pas de source va être en erreur et afficher le message d'alerte ; ce n'est qu'un exemple
    // non dangereux mais injecter un script plus problématique qu'un message d'alerte doit être empêché (vol de cookies,
    // redirection vers sites frauduleux, etc.)

    // BONNE PRATIQUE :
    // fullname.textContent = userPseudo;
    // OU ENCORE :
    // const safeText = escapeHTML(userPseudo);
    // fullname.innerHTML = safeText;
})

// Fonction servant à 'échapper' certains caractères ; c'est à dire forcer du texte contenant
// des symboles ayant une fonction particulière (comme ceci : < , ou encore ça : &) à être lu comme
// un texte avec des caractères normaux (< ne représentera pas un début de balise HTML par exemple,
// mais vraiment le signe inférieur) :
function escapeHTML(string) {
    return string
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#x27;');
}

// On préfère donc utiliser textContent, même si cela implique d'utiliser les méthodes createElement() et appendChild(),
// ce qui prend plus de ligne que de créer la structure HTML avec les balises avec innerHTML().

// Heureusement depuis février 2026 dans firefox, on peut utiliser setHTML(), qui est comme innerHTML() avec
// une injection de code depuis le JS, mais avec la particularité d'être liée à l'API Sanitizer, qui va :
// - parser le HTML (transformer des données brutes en une structure compréhensible et exploitable par un programme),
// - supprimer tout ce qui est dangereux, comme : <script>, onclick, onload, etc.
// - insérer une version sécurisée dans le DOM.
// Résultat : le HTML avec ses balises est utilisable mais sans risque XSS (plus pratique que textContent)