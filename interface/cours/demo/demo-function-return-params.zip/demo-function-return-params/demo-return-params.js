// Consigne : ouvrir le fichier return-params.html dans un navigateur, et regarder dans la console

console.log("********** DEBUT DE LA DEMO **********");

// 1. Une fonction ne s'exécute jamais toute seule, il faut l'appeler
// Ici, je la définis :
function direBonjour() {
  console.log("Salut !");
}
// Jusque là, rien ne s'est produit

// Là, je l'appelle :
direBonjour(); // Ici, elle s'exécute, et va marquer 'Salut !' dans la console



// Ca, c'est juste pour aérer ma console en sautant des lignes :
console.log("**********");



// 2. Appeler la fonction dans une constante
// On fait comme d'habitude, on définit notre fonction
function welcome() {
  console.log("Welcome !");
}
// Elle n'est pas encore exécutée.

// Cette fois, on ne l'appelle pas mais on la met dans une constante nommée 'welcomeMsg'
// Même si on la place dans une constante, la fonction s'exécute car on place '()' juste après,
//  c'est un appel : on va donc avoir 'Welcome' dans la console
const welcomeMsg = welcome();

// Par contre, si on essaie de récupérer le message 'Welcome' depuis notre constante, on
// ne va rien avoir (undefined dans la console) : notre constante n'a pas de valeur
console.log(welcomeMsg);

// Pourquoi ? Car rien n'est "retourné" depuis la fonction, elle s'exécute sans donner quelque 
// chose en retour



console.log("**********");



// 3. Utilisation du return
// L'instruction return met fin à l'exécution d'une fonction et définit une valeur à
//  renvoyer à la fonction appelante.

// On définit notre fonction
function getMessage() {
  // Cette fois, on ne va pas exécuter quelque chose dans la fonction, mais on va retourner
  // une valeur
  return "Hello !";
  // Après un return, la fonction s'arrête automatiquement, je ne pourrais pas rajouter de choses
  // après
}

// On peut maintenant stocker le résultat, qui sera placé dans une constante
const msg = getMessage();
// Ici, ma fonction est exécuté, mais elle n'équivaut pas à un console.log d'une string ; elle équivaut
// directement à une string, qu'on va pouvoir stocker dans notre constante 'msg'

// Notre constante est maintenant non plus undefined, mais est une string, dont la valeur
// est 'Hello !' : on va pouvoir l'utiliser plus tard ou l'afficer dans la console :
console.log(msg); // Hello !



console.log("**********");



// 4. Utilisation des paramètres :
// Ici, notre fonction est définie avec deux paramètres, nommés a et b
function add(a, b) {
  // Cette fonction fait une somme basique de ces deux paramètres, et retourne le résultat
  return a + b;
}

// On pourrait appeler directement notre fonction comme ceci :
add(5, 2);
// Mais on ne pourra pas récupérer cette somme

// On définit donc notre fonction avec des paramètres dans une constante
const somme = add(4, 6);
console.log(somme); // 10



console.log("**********");



// 5. Sans paramètres, et sans return ?
// Si on définit une fonction sans paramètres et sans return, juste avec une somme de nombres fixes
function sommeFausse() {
  // Il n'y a pas de return, la fonction fait juste un calcul
  5 + 8;
}

// Si on décide de stocker la fonction ou ce qu'elle pourrait nosu rendre comme valeur dans une constante :
const resultSommeFausse = sommeFausse(4, 6);
// On se rend compte qu'elle ne retourne rien :
console.log(resultSommeFausse); // undefined

// Par contre, même sans paramètres, si on retourne une addition d'une somme de nombres fixes
function sommeCorrecte() {
  // Ici, return renvoie la valeur du calcul (une somme)
  // La fonction s'arrête immédiatement après.
  return 5 + 8;
}

// Ici, la fonction s'exécute, stocke le résultat de sa valeur (ici, un number) dans une constante :
const resultSommeCorrecte = sommeCorrecte(4, 6);
// On peut ensuite s'en servir dans le reste de notre script, ou l'afficher dans la console :
console.log(resultSommeCorrecte); // 13



console.log("********** FIN DE LA DEMO **********");
console.log("**********");
console.log("********** DEBUT DES EXEMPLES **********");



// On peut utiliser le return et les paramètres de plusieurs manières différentes :

// a. Retourner un calcul
// On définit notre fonction nommée 'addition' en amont, ayant deux paramètres, nommés ici a et b
function addition(a, b) {
  // Ici, return renvoie la valeur du calcul (une somme)
  // La fonction s'arrête immédiatement après.
  return a + b;
}
// A ce stade, la fonction n'est pas exécutée

// On place le résultat de ce que la fonction va nous renvoyer dans une constante
// Elle s'exécute donc maintenant, et stocke la valeur du résultat de la somme dans la constante
const result = addition(3, 4);

// On décide de l'afficher dans la console pour vérifier :
console.log(result); // 7



console.log("**********");



// b. Retourner une chaîne de caractères
// On définit notre fonction nommée 'saluer' en amont, ayant un paramètre, nommé ici nom
function saluer(nom) {
  // Ici, return renvoie une autre chaîne de caractères plus complète
  // La fonction s'arrête immédiatement après.
  return "Bonjour " + nom + " !";
}

// On place le résultat de ce que la fonction va nous renvoyer dans une constante
const salutation = saluer("Mickaël");
console.log(salutation); // Bonjour Mickaël !



console.log("**********");



// c. Retourner un objet
// return peut renvoyer n'importe quel type de donnée, y compris un objet complet
function creerUtilisateur(nomUser, ageUser) {
  return {
    nom: nomUser,
    age: ageUser,
    superClient: true
  };
}

const objetUtilisateur = creerUtilisateur("Bob", 48);
console.log(objetUtilisateur); // { nom: 'Bob', age: 25, superClient: true }



console.log("**********");



// d. Utiliser return pour quitter la fonction plus tôt
function verifierAge(age) {
  if (age < 30) {
    return "Trop jeune"; // sort de la fonction immédiatement
  }
  return "Accès autorisé";
}

// Qu'on le mette ou non dans une constante, on peut vérifier ce que la fonction retourne
// avec le console.log dans la console du navigateur directement :
console.log(verifierAge(26)); // Trop jeune
console.log(verifierAge(34)); // Accès autorisé



console.log("**********");



// e. Ne rien retourner (ou undefined)
function direBonjour() {
  console.log("Salut !");
  return; // pas de valeur retournée
}

// Le console.log de 'Salut !' va s'exécuter juste en dessous :
const resultatBonjour = direBonjour();

// Mais par contre, on ne retourne rien de particulier, donc on aura aussi :
console.log(resultatBonjour); // undefined



console.log("**********");



// f. Retourner une autre fonction
// La fonction 'multiplier' prend un paramètre nommé 'x'
function multiplier(x) {
  // La fonction 'multiplier' retourne une autre fonction non nommée qui, elle, 
  // prend 'y' en paramètre
  return function (y) {
    return x * y;
  };
}

// Ici, on appelle la fonction 'multiplier' avec x = 2 :
const doubler = multiplier(2);
// La fonction ne renvoie pas un nombre, elle renvoie une nouvelle fonction :
/*
doubler = function(y) {
  return 2 * y;
}
*/

// Donc si on donne à la fonction 'doubler' le paramètre 'y' = 5, cela donne :
/*
function(5) {
  return 2 * 5;
}
*/
console.log(doubler(5)); // 2 * 5 = 10



console.log("**********");



// g. Retour conditionnéel avec l'opérateur ternaire
function estPair(n) {
  // Le ? signifie : “si la condition est vraie, retourne ceci ; sinon retourne cela.”
  // n % 2 === 0 utilise l'opérateur modulo (%).
  // n % 2 → reste de n divisé par 2 (que avec des entiers) :
  // 7 % 2  // 1, car 7 ÷ 2 = 3 reste 1
  // 10 % 2 // 0, car 10 ÷ 2 = 5 reste 0
  return n % 2 === 0 ? "pair" : "impair";
}

// Cela revient à faire :
/*
function estPair(n) {
  if (n % 2 === 0) {
    return "pair";
  } else {
    return "impair";
  }
}
*/

// ou encore :
/*
function estPair(n) {
  if (n % 2 === 0) {
    return "pair";
  }
  return "impair";
}
*/

console.log(estPair(4)); // pair
console.log(estPair(7)); // impair



console.log("**********");



// h. Utilisation de async et des promesses
// async transforme automatiquement la fonction en Promise (promesse)
async function obtenirDonnees() {
  // Même si on écrit juste 'return "Voici les données";', JavaScript
  // emballe cette valeur dans une Promise résolue.
  return "Voici les données";
}

// Normalement, un return dans une fonction classique renvoie directement la valeur.
// Mais dans une fonction async, le return renvoie une Promise qui sera résolue avec cette valeur.

// Donc :
const resultat = obtenirDonnees();
console.log(resultat); // affiche 'Promise {<fulfilled>: 'Voici les données'}'

// Donc obtenirDonnees() ne renvoie pas directement la chaîne, mais une Promise qui, 
// lorsqu'elle sera “résolue”, contiendra "Voici les données"

// Mais alors, comment récupérer la valeur d'une Promise ?
// Une Promise est un objet qui représente une valeur qui sera disponible dans le futur
// Pour accéder à cette valeur, on peut utiliser .then() :

// .then() est une méthode des Promises qui attend que la Promise soit résolue
// Il équivaut à dire "Quand tu auras fini ton travail et que tu auras une valeur,
// fais ceci avec la valeur." : ici, 'ceci' correspond au console.log de la valeur du return

// On dit que le code de mon script JavaScript est synchrone de base, mais lorsque je place
// 'async' devant une fonction, elle devient asynchrone : elle va donc attendre que tout
// le reste de mon code synchrone s'exécute avant de résoudre sa promesse (ce n'est pas l'exécution 
// de la fonction qui attend, c'est le résultat (la valeur renvoyée) qui est mise en file d'attente
//  pour plus tard.)

obtenirDonnees().then(console.log); // affiche 'Voici les données'

// C'est pour ça que le message 'Voici les données' est visible dans la console sous le
// 'FIN DES EXEMPLES'

// Si vous souhaitez aller plus loin, n'hésitez pas à regarder dans la doc les mots-clés 'async' et
// 'await', mais aussi la fonction 'fetch()', très utilisé pour communiquer via les API ou avec le
// backend



console.log("********** FIN DES EXEMPLES **********");