// OBJECT (objet)
console.log("I. OBJECT (objet)")

// Un objet est un autre type de données en JavaScript
// Il peut comporter plusieurs propriétés, qui peuvent être des string, des number, des boolean...
// Voici sa syntaxe :

const person = {firstname: "Mike", age: 23, password: "1234abc", isConnected: true}

// Ici, la constante person est un objet possédant quatre propriétés, firstname dont la valeur sera une 
// string, age dont la valeur sera un number, password dont la valeur sera une string, et isConnected dont la valeur
// sera un boolean

// Pour aller chercher la valeur d'une des propriétés de l'objet, on écrit nomDeLObjet.nomDeLaPropriété :
console.log(person.firstname)
console.log(person.age, person.password, person.isConnected)

console.log(`Je sais que ${person.firstname} a ${person.age} ans, et que son mot de passe est ${person.password}.`)

if (person.firstname.startsWith("A")) {
    console.log(`Je sais que ${person.firstname} a son prénom qui commence par un 'A'`);
} else {
    console.log(`Je sais que ${person.firstname} a son prénom qui ne commence PAS par un 'A'`);
}

// Même si on a défini notre objet avec une constante, on peut modifier les valeurs de ses propriétés :
person.isConnected = false;

if (person.isConnected) {
    console.log(`${person.firstname} est connecté !`);
} else {
    console.log(`${person.firstname} n'est pas connecté.`);
}


console.log("**********")

// ARRAY (tableau / liste)
console.log("II. ARRAY (tableau / liste)")

// Un tableau est encore un autre type de données en JavaScript, qui peut lui même être composé
// de différents types de données ; des string, des number, des boolean, des objets...
// Voici sa syntaxe :

const fruitsArray = ["pomme", "banane", "fraise"];
let fruit = "banane";

// Dans les tableaux, chaque valeur a un index, c'est à dire son emplacement dans le tableau ;
// on commence par 0, puis 1, puis 2, etc
// Dans le tableau fruitsArray, la valeur "pomme" a l'index 0, la valeur "banane" a l'index 1, etc
// On peut utiliser les méthodes .indexOf() pour chercher les index des valeurs si on les connait :
const indexDeFraise = fruitsArray.indexOf("fraise")
console.log(`Voici l'index de la valeur fraise : ${indexDeFraise}`)

// On peut aussi utiliser la méthode .at() si on connait l'index mais pas la valeur :
const valeurDeIndex1 = fruitsArray.at(1)
console.log(`Voici la valeur du tableau qui a l'index 1 : ${valeurDeIndex1}`)


if (fruitsArray.includes(fruit)) {
    console.log(`Il y a une ${fruit} dans la liste !`);
} else {
    console.log(`Il y a PAS de ${fruit} dans la liste !`);
}

fruit = "pêche";

if (fruitsArray.includes(fruit)) {
    console.log(`Il y a une ${fruit} dans la liste !`);
} else {
    console.log(`Il y a PAS de ${fruit} dans la liste !`);
}

// Je peux rajouter des valeurs à mon tableau avec la méthode .push()
fruitsArray.push("pêche");

console.log(fruitsArray)

// Je peux enlever des valeurs à mon tableau avec la méthode .splice() après être allé
// chercher leur index avec .indexOf()

const indexDuFruitAEnlever = fruitsArray.indexOf("fraise");

fruitsArray.splice(indexDuFruitAEnlever, 1)

console.log(fruitsArray)



const grades = [14, 9, 12, 16]

// Je calcule la moyenne des notes qui constituent mon tableau grades
let average = grades.reduce((sum, grade) => sum + grade, 0) / grades.length;

console.log(`Moyenne : ${average} sur 20.`);


let newGrade = 18;

grades.push(newGrade);

// Je recalcule la nouvelle moyenne avec le même tableau 'grades' mais qui a une valeur en plus
average = grades.reduce((sum, grade) => sum + grade, 0) / grades.length;

console.log(`Moyenne : ${average} sur 20.`);


let gradeToRemove = 8;

let indexDuNombreAEnlever = grades.indexOf(gradeToRemove);

// Si la méthode .indexOf() ne trouve pas l'index de la note 8 dans mon tableau, elle ressort -1
// Donc si l'index de ma note à enlever est différent de -1, on retire la note du tableau
// avec .splice()
// Sinon (donc si l'index est égal à -1), je ne fais qu'un console.log :
if (indexDuNombreAEnlever !== -1) {
    grades.splice(indexDuNombreAEnlever, 1);
} else {
    console.log(`La note ${gradeToRemove} n'est pas dans la liste. Rien à retirer.`);
}

gradeToRemove = 9;

indexDuNombreAEnlever = grades.indexOf(gradeToRemove);

if (indexDuNombreAEnlever !== -1) {
    grades.splice(indexDuNombreAEnlever, 1);
} else {
    console.log(`La note ${gradeToRemove} n'est pas dans la liste. Rien à retirer.`);
}

// Je recalcule la nouvelle moyenne avec le même tableau 'grades' mais qui a une valeur en plus
average = grades.reduce((sum, grade) => sum + grade, 0) / grades.length;

console.log(`Moyenne : ${average} sur 20.`);



// On peut aussi avoir des tableaux dont les valeurs sont de type différents :
const bazarArray = ["pomme", 3, "June", true, "49"];

// Mais ne nous attardons pas là dessus, car travailler avec ce genre de tableau est complexe


console.log("**********")

// TABLEAUX D'OBJETS
console.log("III. TABLEAUX D'OBJETS")

// On peut donc faire un tableau, rempli non pas directement par des string, des number, des boolean, mais
// par des... objets ! On a donc un tableau d'objets (aussi appelée une liste d'objets) ; chaque
// valeur du tableau sera un objet qui pourra lui-même être composé de propriétés qui auront des valeurs
// en string, number, boolean...
// Voici sa syntaxe :

const peopleArray = [
    {firstname: "Mike", age: 23, password: "1234abc"},
    {firstname: "Jane", age: 54, password: "Ab@Jc48Ff"},
    {firstname: "John", age: 7, password: "@j0hnY"},
    {firstname: "Bill", age: 48, password: "b!iLL"},
    {firstname: "Fred", age: 65, password: "freddy65"},
    {firstname: "Jill", age: 34, password: "593351"}
]

// On va avoir besoin de rentrer dans le tableau, puis dans les objets, pour aller chercher les valeurs
// des propriétés. Si on veut uniquement afficher le prénom de chaque valeur/élément/entrée du tableau,
// (ici, ce sont des objets), nous allons devoir 'boucler' sur le tableau pour le parcourir en entier 
// (on va d'objet en objet dans l'ordre) et à chaque entrée du tableau, aller récupérer seulement la 
// valeur de la propriété firstname.
// Pour cela on utilise une boucle, il en existe de plusieurs sortes, utilisées pour différents usages.
// On va utiliser ici une boucle FOR OF :


for (const person of peopleArray) {
// Je définis 'person' mais je peux écrire ce que je veux, c'est pour dire que pour toutes les entrées
// (tous les objets dans l'ordre) du tableau 'peopleArray', je souhaite m'arrêter à chaque entrée, 
// puis récupérer les propriétés que je souhaite

    const prenom = person.firstname;
    const âge = person.age;

    console.log(prenom);
    console.log(`${âge} ans`);

    // Ici, je stoppe la boucle avec ma condition, dès que l'une des personnes a plus de 55 ans :
    // Même si d'autres personnes plus loin dans le tableau ont un age inférieur à 55 ans, la boucle
    // va s'arrêter.
    if (person.age > 55) break;

    console.log("Cette personne a moins de 55 ans.")

    // Si jusque là personne n'a un age supérieur à 55 ans, on peut créer d'autres conditions :
    if (prenom.startsWith("J")) {
        console.log(`Le prénom ${prenom} commence par un J.`);
    } else if (prenom.startsWith("M")) {
        console.log(`Le prénom ${prenom} commence par un M.`);
    } else {
        console.log(`Le prénom ${prenom} ne commence PAS par un J ni par un M.`);
    }

    console.log("**********")
}