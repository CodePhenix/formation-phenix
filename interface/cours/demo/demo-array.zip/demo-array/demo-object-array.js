// Tableau d'objets représentant les contacts
const contacts = [
  { firstname: "Alice", age: 30, email: "alice@gmail.com", clientPremium: false },
  { firstname: "Bob", age: 25, email: "bobby@orange.fr", clientPremium: false },
  { firstname: "Clara", age: 42, email: "cla@laposte.net", clientPremium: true }
];

// Sélection de la div dans laquelle on va injecter les contacts
const contactsList = document.querySelector("#contacts-list");

// On parcourt le tableau de contacts, cette fois avec forEach :
// Je déclare le nom que je veux pour représenter chaque objet de mon
// tableau (ici, 'contact') :
contacts.forEach(contact => {
  // Ce que je fais maintenant dans la boucle va s'appliquer pour
  // chaque objet de mon tableau (chaque contact)

  // Création d'une carte pour chaque contact
  const card = document.createElement("div");

  // On ajoute une classe pour cette carte
  card.classList.add("contact-card");

  // Si le contact est un client premium, on ajoute une autre
  // classe pour cette carte
  if (contact.clientPremium) {
    card.classList.add("premium-card");
  }

  // Création d'un titre h2 pour chaque contact
  const name = document.createElement("h2");

  // Ce titre prendra le nom du contact
  name.textContent = contact.firstname;

  // On place le titre h2 avec le nom du contact dans la 
  // div de la carte
  card.appendChild(name);

  // Création d'un bouton pour chaque contact
  const button = document.createElement("button");

  // Ce bouton prendra le texte 'Voir détails'
  button.textContent = "Voir détails";

  // On ajoute une classe pour ce bouton
  button.classList.add("toggle-btn");

  // On place le bouton dans la div de la carte
  card.appendChild(button);

  // Création d'une div details pour chaque contact
  const details = document.createElement("div");

  // On ajoute une classe pour cette div
  details.classList.add("contact-details");

  // Cette div details prendra le texte avec l'age et l'email du contact
  details.textContent = `Âge : ${contact.age} | Email : ${contact.email}`;

  // On place la div details du contact dans la 
  // div de la carte
  card.appendChild(details);

  // Gestion du clic sur le bouton pour chaque contact
  button.addEventListener("click", () => {
    // Pas de toggle ici car on souhaite un texte différent
    if (details.classList.contains("visible")) {
      details.classList.remove("visible");
      button.textContent = "Voir détails";
    } else {
      details.classList.add("visible");
      button.textContent = "Masquer détails";
    }
  });

  // Ajout de la div complète de la carte de chaque contact dans 
  // la div qui a l'id "contacts-list" qui va donc accumuler les
  // cartes de chaque contact, dans l'ordre du tableau
  contactsList.appendChild(card);
});