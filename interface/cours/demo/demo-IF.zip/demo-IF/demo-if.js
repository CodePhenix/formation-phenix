// Déclaration des constantes
// Vous pouvez modifier ces trois premières constantes pour observer les différentes actions
// dans le navigateur en lançant le fichier demo.html :
const firstname = "Mike";
const age = 23;
const password = "1234abc";

const resultFirstname = document.querySelector('#resultFirstname');
const resultAge = document.querySelector('#resultAge');
const typeAge = document.querySelector('#typeAge');
const resultPassword = document.querySelector('#resultPass');

// 1. Test prénom
document.querySelector('.btnFirstname').addEventListener('click', () => {

    if (firstname.startsWith("A")) {
        resultFirstname.textContent = `Le prénom ${firstname} commence par un A, bienvenue.`;
    } else {
        resultFirstname.textContent = `Le prénom ${firstname} ne commence PAS par un A, mauvaise page.`;
    }

});

// 2. Test âge
document.querySelector('.btnAge').addEventListener('click', () => {

    if (age >= 20) {

        if (age >= 20 && age < 30) {
            typeAge.classList.add("twenties")
            typeAge.textContent = "La vingtaine, la jeunesse !"
        }
        if (age >= 30 && age < 40) {
            typeAge.classList.add("thirties")
            typeAge.textContent = "La trentaine, au top !"
        }
        if (age >= 40 && age < 50) {
            typeAge.classList.add("forties")
            typeAge.textContent = "La quarantaine, les meilleures années !"
        }
        if (age >= 50 && age < 60) {
            typeAge.classList.add("fifties")
            typeAge.textContent = "La cinquantaine, on profite !"
        }
        if (age >= 60) {
            typeAge.classList.add("sixties")
            typeAge.textContent = "C'est la sagesse."
        }

        resultAge.textContent = `Avec ${age} ans, tout va bien.`;

    } else {
        resultAge.textContent = `Avec ${age} ans, je ne sais ce que tu fais là.`;
    }

});

// 3. Test mot de passe
document.querySelector('.btnPass').addEventListener('click', () => {

    if (password.length > 8) {
        resultPassword.textContent = "Mot de passe assez long : Bienvenue !";
    } else {
        alert("Mot de passe trop court, choisissez-en un de plus de 8 caractères.")
    }

});