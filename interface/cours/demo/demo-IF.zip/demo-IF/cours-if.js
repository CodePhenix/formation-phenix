// COURS IF, ELSE, ELSE IF

// En JavaScript, il existe plusieurs types de données différents :
// - les string (les chaînes de caractères / le texte)
// - les number (les nombres)
// - les boolean (les booléens, qui sont soit true (vrai), soit false (faux))
// - les object (les objets)
// - les array (tableaux / listes)
// et plein d'autres que nous pourrons aborder plus tard

// Nous pouvons utiliser des fonctions (qui sont des objets de type spécial), des boucles
// (structures de contrôle qui organisent l'exécution du code), mais aussi des conditions
// comme if/else, ou encore des opérateurs que le moteur JavaScript utilise pour effectuer des 
// opérations sur des valeurs.

// On peut dire que le if fait une vérification booléenne, c'est à dire vérifie si la condition
// est remplie (true), puis applique une conséquence, mais la valeur testée peut être
// de différents types : une méthode de comparaison de chaînes de caractères (comme startsWith()
// ou toLowerCase()), une opération de number (score > 25), etc.
// Pour le moment, nous allons nous focaliser sur les grands cas d'usage de ces conditions
//  if, else, et else if, avec quelques opérateurs. Pour cela, ouvrez sur un navigateur le fichier
// index/html, et regardez la onsole (clic droit, inspecter, console).



// 1. Vérification de chaînes de caractères au début et à la fin
console.log("1. Vérification de chaînes de caractères au début et à la fin :")

const firstname = "Alice";
console.log(firstname);
console.log(`Votre prénom est ${firstname}.`);

if (firstname.startsWith("A")) {
    console.log("Votre prénom commence par un A !");
} else if (firstname.startsWith("Dam")) {
    console.log("Votre prénom commence par 'Dam' !");
} else {
    console.log("Votre prénom ne commence ni par un A ni par 'Dam' !");
}

if (firstname.endsWith("ce")) {
    console.log("Votre prénom finit par 'ce' !");
}


console.log("**********")

// 2. Comparaison de chaînes de caractères
console.log("2. Comparaison de chaînes de caractères :")

console.log(`Votre prénom en minuscules : ${firstname.toLowerCase()}`);
console.log(`Votre prénom en majuscules : ${firstname.toUpperCase()}`);

if (firstname.toLowerCase() === "alice") {
    console.log("Vous vous appelez bien Alice.");
}

if (firstname.toUpperCase() === "ALICE") {
    console.log("Vous vous appelez bien Alice.");
}


console.log("**********")

// 3. Vérification avec includes()
console.log("3. Vérification avec includes() :")

const sentence = "J'ai mangé une pomme hier."

if (sentence.includes("pomme")) {
    console.log("Le mot pomme apparaît dans la phrase !");
}

let word = "pomme";

if (sentence.includes(word)) {
    console.log(`Le mot ${word} apparaît dans la phrase suivante : ${sentence}`);
}

word = "poire";

if (sentence.includes(word)) {
    console.log(`Le mot ${word} apparaît dans la phrase suivante : ${sentence}`);
} else {
    console.log(`Le mot ${word} n'apparaît PAS dans la phrase suivante : ${sentence}`);
}


console.log("**********")

// 4. Longueur de chaîne
console.log("4. Longueur de chaîne :")

const password = "1234abc";

if (password.length > 8) {
    console.log("Mot de passe sécurisé car plus de 8 caractères, vous puvez continuer.");
} else {
    console.log("Mot de passe trop court car moins de 8 caractères, je vous ramène à la page d'accueil !");
}


console.log("**********")

// 5. Comparaison de nombres
console.log("5. Comparaison de nombres :")

let age = 18;

if (age >= 18) {
    console.log("Tu es majeur !");
} else {
    console.log("Tu es mineur.");
}

age = 17;

if (age >= 18) {
    console.log("Tu es majeur !");
} else {
    console.log("Tu es mineur.");
}


console.log("**********")

// 6. Vrai ou Faux
console.log("6. Vrai ou Faux :")

let isConnected = true;

// Les 2 conditions suivantes demandent dans mon IF si je suis connecté, c'est à dire si
// ma variable isConnected, qui est un booléen, est égale à true. Si c'est le cas, la
// conséquence sera d'afficher le message 'Bienvenue !'.
// Si ce n'est pas le cas (donc si ma variable est isConnected est égale à false), dans mon ELSE,
// je choisis pour ma conséquence d'afficher le message 'Merci de vous connecter.'.
if (isConnected === true) {
    console.log("Bienvenue !");
} else {
    console.log("Merci de vous connecter.");
}

if (isConnected) {
    console.log("Bienvenue !");
} else {
    console.log("Merci de vous connecter.");
}

// Les 3 conditions suivantes demandent dans mon IF si je ne suis PAS connecté, donc si ma
// variable isConnected est égale à false. Si on arrive dans le ELSE, cela veut dire que
// ma variable est égale à true.
if (isConnected === false) {
    console.log("Je crois que vous n'êtes pas connectés, je vous renvoie à la page de connexion.");
} else {
    console.log("Vous êtes bien connectés, bienvenue.");
}

if (isConnected !== true) {
    console.log("Je crois que vous n'êtes pas connectés, je vous renvoie à la page de connexion.");
} else {
    console.log("Vous êtes bien connectés, bienvenue.");
}

if (!isConnected) {
    console.log("Je crois que vous n'êtes pas connectés, je vous renvoie à la page de connexion.");
} else {
    console.log("Vous êtes bien connectés, bienvenue.");
}


console.log("**********")

// 7. Comparaison == vs ===
console.log("7. Comparaison == vs === :")

const nb1 = 5;
const nb2 = "5";

if (nb1 == nb2) {
    console.log("== : Les valeurs sont égales (type ignoré)");
}

if (nb1 === nb2) {
    console.log("=== : Les valeurs et les types sont égaux");
} else {
    console.log("=== : Les types ou valeurs sont différents");
}


console.log("**********")

// 8. Comparaison != et !==
console.log("8. Comparaison != et !== :")

let score = 200;

if (score != 200) {
    console.log("Le score est différent de 200");
} else {
    console.log("Le score est égal à 200");
}

if (score !== 200) {
    console.log("Le score est différent de 200 (avec type)");
} else {
    console.log("Le score est égal à 200 (avec le bon type)");
}

score = "200";

if (score != 200) {
    console.log("Le score est différent de 200");
} else {
    console.log("Le score est égal à 200");
}

if (score !== 200) {
    console.log("Le score est différent de 200 (avec type)");
} else {
    console.log("Le score est égal à 200 (avec type)");
}


console.log("**********")

// 9. Comparaison <, <=, >, >=
console.log("9. Comparaison <, <=, >, >= :")

let price = 150;

if (price > 200) {
    console.log("Le prix est trop élevé, c'est trop cher pour moi !");
} else if (price < 5) {
    console.log("C'est sûrement une arnaque, je me méfie...");
} else {
    // Ici, j'ai deux conditions au dessus : soit je rentre dans le premier IF si mon prix
    // est supérieur à 200, soit je rentre dans le deuxième IF ELSE si mon prix est inférieur
    // à 5, donc si je ne rentre dans aucune de ces conditions (ce qui veut dire que mon prix
    // est compris entre 5 et 200), je rentre dans mon ELSE :
    console.log("Ca me va, j'achète.");
}

if (price <= 150) {
    console.log("Ca rentre dans mes moyens, je prends.");
} else {
    console.log("Au delà de 150, pas possible.");
}


console.log("**********")

// 10. Opérateur logique && (ET)
console.log("10. Opérateur logique && (ET) :")

let temperature = 22;
let isRaining = false;

if (temperature > 20 && isRaining === false) {
    console.log("On peut aller se promener !");
} else {
    console.log("Sortez le parapluie et/ou la doudoune !");
}

isRaining = true;

if (temperature > 20 && !isRaining) {
    console.log("On peut aller se promener !");
} else {
    console.log("Sortez le parapluie et/ou la doudoune !");
}


console.log("**********")

// 11. Opérateur logique || (OU)
console.log("11. Opérateur logique || (OU) :")

let day = "jeudi";

if (day === "samedi" || day === "dimanche") {
    console.log("C'est le week-end !");
} else if (day === "lundi" || day === "mardi" || day === "mercredi" || day === "jeudi" || day === "vendredi") {
    console.log(`Nous sommes ouverts car aujourd'hui, c'est ${day} !`);
}


console.log("**********")

// 12. IF, ELSE IF, ELSE IF, ELSE... et condition dans condition dans condition ?
console.log("12. IF, ELSE IF, ELSE IF, ELSE... et condition dans condition dans condition ? :")

// On peut vérifier dans un premier temps une première condition dans un IF, puis une deuxième
// dans un ELSE IF, puis une troisième dans un autre ELSE IF, et gérer le reste si ces trois 
// conditions ne sont pas remplies dans le ELSE :
let âge = 30;

if (âge < 18) {
    console.log(`Vous avez ${âge} ans : vous n'avez pas l'âge requis pour conduire une voiture !`);
} else if (âge >= 80) {
    console.log(`Vous avez ${âge} ans : peut être faudrait-il repasser le permis ?`);
} else {
    console.log(`Vous avez ${âge} ans, entre 18 et 80 : quel modèle de voiture vous intéresse ?`);
}

// Mais on peut aussi ajouter des conditions au sein d'autres conditions...
// N'hésitez pas à modifier la variable 'âge' ci-dessous puis observer les messages 
// dans la console :
âge = 36;

if (âge < 18) {

    console.log(`Vous avez ${âge} ans : vous n'avez pas l'âge requis pour conduire une voiture !`);

    if (âge < 12) {
        console.log(`Vous avez ${âge} ans : qu'est ce que vous faites sur Internet ??`);
    } else if (âge === 16 || âge === 17) {
        console.log(`Vous avez 16 ou 17 ans, bientôt le permis ?`);
    } else {
        console.log(`Vous avez entre 12 et 15 ans, bientôt le code ?`);
    }

} else if (âge >= 80) {

    console.log(`Vous avez ${âge} ans : peut être faudrait-il repasser le permis ?`);

} else {

    console.log(`Vous avez ${âge} ans, entre 18 et 80 : quel modèle de voiture vous intéresse ?`);

    if (âge >= 25) {

        if (âge >= 25 && âge < 40) {
            console.log(`Vous avez ${âge} ans, une Peugeot 308 ?`);
        } else if (âge >= 40 && âge < 55) {
            console.log(`Vous avez ${âge} ans, une Citroën C4 ?`);
        } else if (âge >= 55 && âge < 80) {
            console.log(`Vous avez ${âge} ans, une petite Rolls ?`);
        }

    } else {
        console.log(`Vous avez moins de 25 ans, on vous conseille une Fiat Panda.`);
    }

}