// TOUT ECRIRE ICI, DANS LE FICHIER JS

// On récupère l'input de texte (text-input) :
const textInput = document.querySelector("#text-input");

// On récupère la zone d'affichage du texte converti (text-output) :
const textOutput = document.querySelector("#text-output");

// On récupère le bouton de conversion Majuscules (btn-upper) :
const btnUpper = document.querySelector("#btn-upper");

// On récupère l'input de température (temp-input) :
const tempInput = document.querySelector("#temp-input");

// On récupère la zone d'affichage du résultat température (temp-output) :
const tempOutput = document.querySelector("#temp-output");

// On récupère le bouton de conversion température Convertir en °F (btn-to-f) :
const btnToF = document.querySelector("#btn-to-f");

// ========== DEBUT DE L'ETAPE 1 ==========
// Objectif : Sélectionner les éléments HTML avec querySelector()
// Sélectionnez les éléments suivants :
// - le bouton de conversion Minuscules (btn-lower) :

// - le bouton de conversion température Convertir en °C (btn-to-c) :

// - le bouton de thème Mode sombre (btn-dark) :

// ========== FIN DE L'ETAPE 1 ==========


// On va ajouter un écouteur d'événement "click" sur le bouton Majuscules :
btnUpper.addEventListener("click", function () {
    // Quand on clique, on va récupérer le contenu de l'input de texte
    const txt = textInput.value;
    // On va vérifier si le texte n'est pas vide
    if (txt !== "") {
        // On va convertir le texte en MAJUSCULES avec toUpperCase(), et
        // afficher le résultat dans la zone text-output
        textOutput.textContent = txt.toUpperCase();
    }
});

// ========== DEBUT DE L'ETAPE 2 ==========
// Objectif : Gérer la conversion du texte
// Maintenant, vous allez faire la même chose, mais pour la fonctionnalité minuscules :
// – Ajouter un écouteur d'événement "click" sur le bouton Minuscules

    // - Quand on clique, récupérer le contenu de l'input de texte

    // - Vérifier si le texte n'est pas vide

        // - Convertir le texte qu'on a récupéré en minuscules avec toLowerCase(), et
        // afficher le résultat dans la zone text-output

        // Fin du if :

// Fin du addEventListener :

// ========== FIN DE L'ETAPE 2 ==========


// On va ajouter un écouteur "click" sur le bouton Convertir en °F
btnToF.addEventListener("click", function () {
    // On va récupérer la valeur de l'input température et la
    // convertir en nombre avec la méthode Number()
    const temp = Number(tempInput.value);
    // On va appliquer la formule de conversion de celsius en
    // fahrenheit : (°C × (9/5)) + 32
    const fahrenheit = (temp * (9 / 5)) + 32;
    // On va afficher le résultat à l'écran dans temp-output 
    // avec la méthode .toFixed(1) pour 1 décimale (1 chiffre
    // après la virgule)
    tempOutput.textContent = temp + "°C = " + fahrenheit.toFixed(1) + "°F";
});

// ========== DEBUT DE L'ETAPE 3 ==========
// Objectif : Convertir en température
// – Ajouter un écouteur "click" sur le bouton Convertir en °C

    // - Récupérer la valeur de l'input température et la
    // convertir en nombre avec Number()

    // - Appliquer la formule de conversion de fahrenheit en
    // celsius : (°F − 32) × (5/9)

    // - Afficher le résultat à l'écran dans temp-output 
    // avec la méthode .toFixed(1) pour 1 décimale (1 chiffre
    // après la virgule)

// Fin du addEventListener :

// ========== FIN DE L'ETAPE 3 ==========


// ========== DEBUT DE L'ETAPE 4 ==========
// Objectif : Gérer le thème dark de la page
// – Ajouter un écouteur "click" sur le bouton Mode sombre

    // - Ajouter ou retirer la classe "dark-theme" sur le
    // document.body en utilisant classList.toggle

// Fin du addEventListener :

// ========== FIN DE L'ETAPE 4 ==========