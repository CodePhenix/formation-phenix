// =============================================
// COURS JAVASCRIPT
// =============================================

// En JavaScript, une variable et une constante sont des moyens de
// stocker des données pour les réutiliser plus tard.

// La valeur d'une constante ne peut pas être changée :
// const monTexte = "Hello !"
// La valeur de la constante monTexte restera toujours "Hello !"

// La valeur d'une variable peut être modifiée :
// let monNouveauTexte = "Bonjour, ça va ?"
// La valeur de la variable monNouveauTexte peut être modifié :
// monNouveauTexte = "Bonjour, ça va bien ?"

// Les types de données sont variés en Javascript, on en retiendra 5 :
// - les string (chaînes de caractères) : "Hello, ça va ?"
// - les number (nombres) : 52
// - les boolean (booléens : vrai ou faux) : true/false
// - les object (objets)
// - les array (tableaux/listes)

// Nous allons d'abord voir les outils les plus utilisés pour manipuler 
// des éléments HTML et CSS à l'aide de JavaScript.

// =============================================
// 1. SELECTIONNER UN ÉLÉMENT AVEC querySelector
// =============================================

// querySelector est une méthode JavaScript qui permet de récupérer 
// un élément HTML pour interagir avec lui.
// On utilise un sélecteur CSS : #id, .classe, ou nom de balise.
// On définit une constante avec const ou une variable avec let 
// pour garder en mémoire cet élément HTML dans notrte fichier JS.

// Exemple :
// On choisit de créer une constante 'titre' (on la nomme comme on veut) :
const titre = document.querySelector("h1");
// J'ai récupéré toute la balise h1 :
console.log("Titre sélectionné :", titre);
// Si je souhaite voir le texte de la balise h1 :
console.log("Texte du titre sélectionné :", titre.textContent);

// Autre exemples :
// const monInput = document.querySelector("#mon-input");
// const monBouton = document.querySelector(".bouton");

// =============================================
// 2. ÉCOUTER UN ÉVÉNEMENT (comme un clic)
// =============================================

// addEventListener est une autre méthode JavaScript qui 
// permet d'exécuter une fonction quand un événement se produit, 
// on appelle cela un écouteur d'évènement.

// Exemple :
// Je récupère l'élément HTML que je souhaite écouter : ici,
// c'est le bouton qui a l'id btn-test :
const boutonTest = document.querySelector("#btn-test");

// J'écoute chaque clic sur mon bouton, et je définis une
// fonction ensuite qui sera l'exécution de la conséquence
// de chaque clic :
boutonTest.addEventListener("click", function () {
    // A chaque clic, il y aura un nouveau console.log
    // dans la console avec le texte suivant :
    console.log("Le bouton a été cliqué !");
});

// =============================================
// 3. LIRE LA VALEUR D’UN INPUT
// =============================================

// On utilise .value pour récupérer ce que l’utilisateur a tapé :

// Exemple :
// Je récupère l'élément HTML que je souhaite écouter : ici,
// c'est le bouton qui a l'id btn-input :
const boutonInput = document.querySelector("#btn-input");
// Je récupère aussi l'élément HTML dont je souhaite lire
// le texte tapé par l'utilisateur : ici, c'est un input :
const inputTexte = document.querySelector("#input-texte");

boutonInput.addEventListener("click", function () {
    // A chaque clic sur mon bouton, je vais lire la valeur de
    // mon input et l'afficher dans la console :
    console.log("Texte saisi :", inputTexte.value);
});

// =============================================
// 4. MODIFIER LE TEXTE D’UN ÉLÉMENT
// =============================================

// On utilise .textContent pour afficher du texte dans une balise :
// c'est comme si on écrivait du HTML mais directement en JavaScript !

// Exemple :
// Je récupère ma div HTML qui a l'id resultat en définissant une constante :
const affichage = document.querySelector("#resultat");

// Dans cette div, je vais afficher le texte voulu (ici, Bonjour !) :
affichage.textContent = "Bonjour !";

// =============================================
// 5. MANIPULER LES CHAÎNES DE CARACTÈRES
// =============================================

// On peut manipuler des string, c'est à dire des chaînes de caractères,
// avec différentes méthodes :
// .toUpperCase() permet de transformer tout le texte en majuscules,
// .toLowerCase() permet de transformer tout le texte en minuscules.

const exempleTexte = "JavaScript";

console.log("En majuscules :", exempleTexte.toUpperCase()); // JAVASCRIPT
console.log("En minuscules :", exempleTexte.toLowerCase()); // javascript

// =============================================
// 6. VÉRIFIER UNE CONDITION (if / else)
// =============================================

// On peut vérifier si une condition est remplie avec IF / ELSE

const age = 34;

// IF est égal à SI en français, et ELSE à SINON :
// SI la valeur de la constante age est supérieure ou égale à 80 :
if (age >= 80) {
    // Conséquence, on affiche le texte suivant :
    console.log("Senior : au dessus de 80 ans.");
} else {
    // SINON, donc dans ce cas si la valeur de la constante age est
    // inférieure à 80, on affiche le texte suivant :
    console.log("Junior : moins de 80 ans.");
}

// =============================================
// 7. GÉRER LES CLASSES CSS AVEC classList
// =============================================

// Avec la méthode .classList, on peut ajouter et enlever des classes
// à des éléments HTML.

// Exemple :
// Je récupère tout le contenu HTML de mon body :
const corps = document.body;

// Ajouter une classe :
// corps.classList.add("exemple-classe");

// Retirer une classe :
// corps.classList.remove("exemple-classe");

// Ajouter une classe si elle n'est pas présente OU retirer une 
// classe si elle est déjà présente :
// corps.classList.toggle("exemple-classe");

// On peut donc écouter le clic du bouton qui va permettre d'ajouter
// OU d'enlever une classe au body de notre page :
const boutonClasse = document.querySelector("#btn-toggle-classe");

boutonClasse.addEventListener("click", function () {
    // En utilisant classList.toggle, à chaque clic sur mon bouton, je vais 
    // ajouter la classe appelée 'exemple-classe' à mon body si il n'a pas déjà
    // cette classe.
    // Si mon body a déjà cette classe, il va l'enlever.
    // Cette classe est déjà présente dans mon fichier doc.css et possède 
    // un background-color jaune.
    // Ainsi, à chaque clic, c'est comme si j'ajoutais et enlevais automatiquement
    // la couleur jaune au body de ma page.
    corps.classList.toggle("exemple-classe");
});

// =============================================
// 8. LES METHODES
// =============================================

// Il existe plein de méthodes natives en JavaScript (déjà fonctionnelles)
// permettant de manipuler les données :
// Pour manipuler des string :
//      - toLowerCase()
//      - toUpperCase()
//      - startsWith()
//      - endsWith()
//      - includes()
// Pour manipuler des numbers :
//      - Number()
//      - toFixed()

