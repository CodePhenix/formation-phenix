function Level(firstroom){
	this.room = firstroom;
}