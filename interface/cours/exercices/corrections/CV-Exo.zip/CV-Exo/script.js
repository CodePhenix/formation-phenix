// Aller chercher le bouton d'ouverture du menu :
const menuBtn = document.querySelector("#menu-btn");

// Aller chercher la navigation à rendre visible :
const nav = document.querySelector("nav");

// Ecouter le clic sur le bouton d'ouverture du menu :
menuBtn.addEventListener("click", function() {
    // On ajoute la classe visible à la nav :
    nav.classList.add("visible");
    // Dans notre CSS, la nav avec la classe visible passe de display: none à
    // display: block, passant d'invisible à visible.
})

// On fait pareil pour le bouton de fermeture du menu, on va le chercher :
const closeBtn = document.querySelector("#close-btn");

// Ecouter le clic sur le bouton de fermeture du menu :
closeBtn.addEventListener("click", function() {
    // On enlève la classe visible à la nav :
    nav.classList.remove("visible");
    // Dans notre CSS, la nav sans la classe visible passe de display: block à
    // display: none, passant de visible à invisible.
})