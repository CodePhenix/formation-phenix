// ********* OVERLAY **********
const overlay = document.getElementById('overlay');

// ********* MENU BUTTONS **********
const openBtn = document.querySelector("#open-btn");
const closeBtn = document.querySelector("#close-btn");

const nav = document.querySelector("nav");

openBtn.addEventListener("click", () => {
    nav.classList.add("show-nav");
    overlay.classList.add('active');
    closeBtn.classList.add("show-btn");
});

function closeNav() {
    nav.classList.remove("show-nav");
    overlay.classList.remove('active');
    closeBtn.classList.remove("show-btn");
};

closeBtn.addEventListener("click", closeNav);

document.querySelectorAll("nav a[href^='#']").forEach(link => {
    link.addEventListener("click", closeNav);
});

overlay.addEventListener("click", closeNav);

// ********* TAGS CREATION **********
const tags = [
    "Travel", "New York", "Dinner", "Salmon", "France",
    "Drinks", "Ideas", "Flavours", "Cuisine", "Chicken",
    "Dressing", "Fried", "Fish", "Duck"
];

const tagsContainer = document.querySelector("#tag-container");

tags.forEach(tag => {
    const tagBtn = document.createElement("button");
    tagBtn.textContent = tag;
    tagsContainer.appendChild(tagBtn);
});

const boutons = document.querySelectorAll("#tag-container button");

boutons.forEach(bouton => {
    bouton.addEventListener("click", () => {
        // On garde en mémoire si notre bouton possède la classe 'style-tag' :
        const isActive = bouton.classList.contains("style-tag");
        
        boutons.forEach(b => b.classList.remove("style-tag"));

        const allArticles = document.querySelectorAll("#articles-container article");

        if (isActive) {
            allArticles.forEach(article => {
                article.style.display = "block";
            });
        } else {
            bouton.classList.add("style-tag");
            const selectedTag = bouton.textContent;

            allArticles.forEach(article => {
                // On avait un attribut personnalisé pour chaque article, nommé data-tags, comme par ex :
                // <article class="articles" data-tags="Travel,France,Flavours,Cuisine".
                // Ici, on va récupérer la valeur de l’attribut data-tags via dataset.tags, puis utiliser
                // la méthode split pour transformer cette chaîne de caractères en tableau, comme ceci :
                // "Travel,France,Flavours,Cuisine" va devenir const tags = ["Travel", "France",
                // "Flavours", "Cuisine"]
                const tags = article.dataset.tags.split(',');
                if (tags.includes(selectedTag)) {
                    article.style.display = "block";
                } else {
                    article.style.display = "none";
                }
            });
        }
    });
});

// ********* ARTICLES CREATION **********
const articles = [
    {
        img: "myfood/images/sandwich.jpg",
        alt: "sandwich",
        titre: "The Perfect Sandwich, A Real NYC Classic",
        texte: "Just some random text, lorem ipsum text praesent tincidunt ipsum lipsum.",
        tags: ["Travel", "New York", "Ideas", "Flavours", "Cuisine", "Chicken", "Dressing", "Fried"]
    },
    {
        img: "myfood/images/steak.jpg",
        alt: "steak",
        titre: "Let Me Tell You About This Steak",
        texte: "Once again, some random text to lorem lorem lorem lorem ipsum text praesent tincidunt ipsum lipsum.",
        tags: ["Dinner", "Ideas", "Flavours", "Cuisine", "Dressing"]
    },
    {
        img: "myfood/images/cherries.jpg",
        alt: "cherries",
        titre: "Cherries, interrupted",
        texte: "Lorem ipsum text praesent tincidunt ipsum lipsum. What else?",
        tags: ["Travel", "Flavours", "Cuisine"]
    },
    {
        img: "myfood/images/wine.jpg",
        alt: "wine",
        titre: "Once Again, Robust Wine and Vegetable Pasta",
        texte: "lorem ipsum text praesent tincidunt ipsum lipsum.",
        tags: ["Travel", "Dinner", "France", "Drinks", "Ideas", "Flavours", "Cuisine"]
    },
    {
        img: "myfood/images/popsicle.jpg",
        alt: "popsicle",
        titre: "All I Need Is a Popsicle",
        texte: "Lorem ipsum text praesent tincidunt ipsum lipsum.",
        tags: ["Ideas"]
    },
    {
        img: "myfood/images/salmon.jpg",
        alt: "salmon",
        titre: "Salmon For Your Skin",
        texte: "Once again, some random text to lorem lorem lorem lorem ipsum text praesent tincidunt ipsum lipsum.",
        tags: ["Dinner", "Salmon", "Flavours", "Cuisine", "Dressing", "Fish"]
    },
    {
        img: "myfood/images/sandwich.jpg",
        alt: "sandwich",
        titre: "The Perfect Sandwich, A Real NYC Classic",
        texte: "Just some random text, lorem ipsum text praesent tincidunt ipsum lipsum.",
        tags: ["Travel", "New York", "Ideas", "Flavours", "Cuisine", "Chicken", "Dressing", "Fried"]
    },
    {
        img: "myfood/images/croissant.jpg",
        alt: "croissant",
        titre: "Le French",
        texte: "Lorem lorem lorem lorem ipsum text praesent tincidunt ipsum lipsum.",
        tags: ["Travel", "France", "Flavours", "Cuisine"]
    }
];

const articlesContainer = document.querySelector("#articles-container");

articles.forEach(articleData => {
    const articleCard = document.createElement('article');
    articleCard.classList.add('articles');

    const titre = document.createElement('h3');
    titre.textContent = articleData.titre;

    const image = document.createElement('img');
    image.src = articleData.img;
    image.alt = articleData.alt;

    const texte = document.createElement('div');

    // Différent de text.classList.add("articles-text") : ici, .className efface et remplace toutes les
    // classes qu'aurait pu avoir la div 'texte' (mais même comportement ici, c'est pour l'exemple)
    texte.className = 'articles-text';

    // Ici, après chaque fin de phrase finissant par un point, si ce point est suivi d'un caractère ou d'un
    // espace suivi d'un caractère, cela va ajouter deux sauts de ligne (pour l'article "Cherries")
    const texteStr = articleData.texte.replace(/\.(\s*)(\S)/g, ".\n\n$2");
    texte.textContent = texteStr;

    articleCard.appendChild(image);
    articleCard.appendChild(titre);
    articleCard.appendChild(texte);

    // Ci-dessous, on ajoute ou modifie l’attribut data-tags de l'article html articleCard :
    // element.dataset est un objet spécial qui représente tous les attributs data-* d’un élément HTML.
    // On spécifie dataset.tags donc on va créer pour chaque article l'attribut data-tags.
    // La méthode join(',') transforme le tableau en chaîne de caractères séparée par des virgules.
    articleCard.dataset.tags = articleData.tags.join(',');
    // En somme, ça stocke dans le html cet attribut personnalisé nommé data-quelquechose : l'article html
    // intitulé "Le French" aura donc la forme suivante :
    // <article class="articles" data-tags="Travel,France,Flavours,Cuisine".

    articlesContainer.appendChild(articleCard)
});