// 1. Gestion du thème 'dark'

const toggleButton = document.getElementById('logo-dark-theme');

// Avec toggle :
toggleButton.addEventListener('click', () => {
    // Ici, on prend tout le body du document html (le DOM):
    document.body.classList.toggle('dark-theme');
});

// Sans toggle :
/*
toggleButton.addEventListener('click', () => {
  if (document.body.classList.contains('dark-theme')) {
    document.body.classList.remove('dark-theme');
  } else {
    document.body.classList.add('dark-theme');
  }
});
*/



// 2. Gestion de l'affichage de la sidebar

// On définit des constantes qui récupèrent les éléments HTML souhaités
const toggleBtn = document.getElementById('menu-toggle');
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('overlay');

// Avec la définition d'une fonction en amont, que l'on nomme toggleMenu :
// Cette fonction ne s'exécute que si on l'appelle
function toggleMenu() {
    // Dans les deux cas (vue mobile ou vue desktop), on va ajouter ou enlever la classe .visible
    // à la sidebar :
    sidebar.classList.toggle('visible');

    // Par contre, l'affichage du body sera différent selon la vue (décalage de tout le main
    // et du footer pour la vue desktop, et affichage de l'overlay pour la vue mobile)

    const isDesktop = window.innerWidth >= 1024;
    // Ici, isDektop est un booléen, donc soit true (vrai), soit faux (false), ce qui revient
    // à écrire if (isDektop === true), ou encore if (window.innerWidth >= 1024)
    if (isDesktop) {
        document.body.classList.toggle('menu-open');
    } else {
        overlay.classList.toggle('active');
    }
}

// Lors de ces deux écoutes d'évènements (clic sur le bouton Menu, et clic sur l'overlay), on
// exécute la fonction définie au-dessus :
toggleBtn.addEventListener('click', toggleMenu);
overlay.addEventListener('click', toggleMenu);

// Version plus longue (car je dois écrire la fonction deux fois) :
/*
toggleBtn.addEventListener('click', function() {
    const isDesktop = window.innerWidth >= 1024;
    sidebar.classList.toggle('visible');

    if (isDesktop) {
        document.body.classList.toggle('menu-open');
    } else {
        overlay.classList.toggle('active');
    }
});

overlay.addEventListener('click', function() {
    const isDesktop = window.innerWidth >= 1024;
    sidebar.classList.toggle('visible');

    if (isDesktop) {
        document.body.classList.toggle('menu-open');
    } else {
        overlay.classList.toggle('active');
    }
});
*/



// 3. Gestion de l'affichage de la sidebar (pas nécessaire, seulement pour les transitions de vues)
window.addEventListener('resize', () => {
    // J'ai déjà déclarée cette constante, mais dans une autre fonction ; en dehors, elle n'est 
    // pas reconnue !
    const isDesktop = window.innerWidth >= 1024;

    overlay.classList.remove('active');
    sidebar.classList.remove('visible');
    document.body.classList.remove('menu-open');
});



// 4. Gestion d'un renvoi de page plus complet qu'avec seulement du CSS
const scrollLink = document.querySelector("#scroll-to-countries");

// Cette fois, notre fonction comporte un paramètre entre parenthèse : event, qui est un objet-instance
// natif contenant des informations sur l'évènement en question (ici, le clic), on le place en paramètres
// pour l'utiliser plus tard :
scrollLink.addEventListener("click", function (event) {
    // Cela empêche le rechargement de la page :
    event.preventDefault();

    const target = document.querySelector(".countries");

    // On déclare une fonction native setTimeout où on va pouvoir rajouter un délai de 0.5sec :
    setTimeout(() => {
        // On utilise la méthode scrollIntoView pour indiquer le comportement de notre défilement :
        target.scrollIntoView({
            behavior: "smooth",
            block: "center"
        });
    }, 500);
});
