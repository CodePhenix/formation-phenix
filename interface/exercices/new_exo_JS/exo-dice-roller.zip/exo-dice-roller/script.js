console.log("Démarrage du jeu");

// ========== DEBUT DE L'ETAPE 2 ==========
// Objectif : Tirer un nombre aléatoire
// On ajoute la fonction pour tirer un nombre aléatoire
// Dans cette fonction :
// > min et max sont des arguments de la fonction
// > on définit dans la fonction une constante, qui est renvoyée hors de la fonction (ça sera sa valeur)
// > cette constante reprend la formule Math.floor(Math.random() * (max - min + 1)) + min
// > cette constante est locale à la fonction (DONC non accessible à l'extérieur)
// > on utilise return pour retourner la constante 





// Fin de la fonction

// ========== DEBUT DE L'ETAPE 3 ==========
// Objectif : Lancer plusieurs dés
// On définit une variable qui sera le nombre de dés lancé :


// ========== DEBUT DE L'ETAPE 4 ==========
// Objectif : Choisir le nombre de dés à lancer
// On va chercher la div qui permet de sélectionner le nombre de dés, et on l'affiche :



// On va chercher le curseur et la valeur du nombre de dés :



// On va chercher le bouton qui permet de lancer les dés, et on l'affiche :



// Au changement du curseur, lorsque l'input est modifié :
// - le texte de la valeur du nombre de dés affichée doit se modifier et être égale à la valeur du curseur
// - la variable du nombre de dés doit être égal à la valeur du curseur (comme cette dernière est une chaîne de
// caractères, il faut la transformer en Number grâce à la fonction 'Number()')





// On créé une nouvelle fonction, qui va reprendre ce qu'on a défini dans les étapes précédentes
// Est-ce que cette fonction a besoin d'un paramètre ?
//      NON
// Est-ce que cette fonction a besoin de faire un return ?
//      NON
// Début de cette fonction :


    // On appelle la fonction définie plus haut
    // > si randomNumber est la const qui récupère le résultat du lancer de dé, et generateRandomNumber() la fonction :


    // Variable de la position à injecter dans backgroundPosition plus tard pour décaler le sprite de l'image des dés :


    // ========== DEBUT DE L'ETAPE 1 ==========
    // Objectif : Création d'un dé
    // Création d'une div :


    // On utilise la formule style.backgroundPosition = "-" + position + "px 0" pour faire
    // bouger l'image afin de tomber sur le visuel de la face du dé correspondant au chiffre obtenu aléatoirement :

    // ========== FIN DE L'ETAPE 2 ==========

    // Ajout de la classe dice :


    // Sélection du container :


    // Remplacement de la classe 'hidden' par la classe 'board' :


    // Mettre la div dans le container :

    // ========== FIN DE L'ETAPE 1 ==========

    // Fin de la fonction


// Au clic sur le bouton "Valider et Lancer" :


    // On va chercher la div du player :

    // On la vide :


    // Bonus : On va chercher la div du player 2 :

    // Bonus : On modifie le nom de la classe du player 2 ; la classe ne sera plus 'hidden' mais 'board'

    // Bonus : On la vide :


    // Il faut boucler avec une boucle for, de 0 au nombre de dés (défini dans notre variable déclarée plus haut)
    // A l'intérieur de cette boucle, on appelle la fonction permettant de créer des dés




    // ========== FIN DE L'ETAPE 3 ==========

    // Fin du addEventListener :

// ========== FIN DE L'ETAPE 4 ==========

