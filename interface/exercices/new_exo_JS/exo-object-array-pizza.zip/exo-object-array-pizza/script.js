// TOUT CODER DANS CE FICHIER JAVASCRIPT !

// Objectif : Créer une page gérant différentes parties d'une pizzeria, l'affichage d'une pizza, puis d'un tableau
// des prix et enfin d'un menu, avec un filtre sur les calzones



// =============================
// I. OBJET PIZZA
// =============================

const onePizza = {
  name: "Margherita",
  description: "Tomate, mozzarella, basilic",
  price: 9.5
};

// ========== DEBUT DE L'ETAPE 1 ==========
// Objectif : Sélectionner la div 'pizza-objet' avec querySelector

// ========== FIN DE L'ETAPE 1 ==========



// ========== DEBUT DE L'ETAPE 2 ==========
// Objectif : Afficher dans cette div le texte contenant : nomdelapizza : descriptiondelapizza — prixdelapizza €, en
// utilisant uniquement les valeurs des propriétés de l'objet onePizza

// ========== FIN DE L'ETAPE 2 ==========



// =============================
// II. TABLEAU DE PRIX
// =============================

const pricePizzasArray = [9.5, 13.7, 11.0, 11.5, 11.0, 12.0, 11.8];

// ========== DEBUT DE L'ETAPE 3 ==========
// Objectif : Sélectionner la div 'prix-array' qui va contenir les prix des pizzas avec querySelector

// ========== FIN DE L'ETAPE 3 ==========



// Nous allons boucler sur le tableau en utilisant une boucle for...of, pour définir ce qu'il faut faire pour
// chaque élément du tableau (ici, des nombres) :
for (const price of pricePizzasArray) {

  // ========== DEBUT DE L'ETAPE 4 ==========
  // Objectif : Pour chaque prix du tableau :
  // - créer un <p> et le nommer avec une constante

  // - ajouter du texte à cette constante : le prix 'price' suivi de "€"

  // - ajouter cette constante/paragraphe dans la div 'prix-array'

  // ========== FIN DE L'ETAPE 4 ==========

  // Fin de la boucle :
}

// On calcule le prix moyen de toutes les pizzas :
const averagePrice = pricePizzasArray.reduce((sum, currentPrice) => sum + currentPrice, 0) / pricePizzasArray.length;

// ========== DEBUT DE L'ETAPE 5 ==========
// Objectif : Sélectionner le paragraphe 'prix-moyen' avec querySelector

// ========== FIN DE L'ETAPE 5 ==========



// ========== DEBUT DE L'ETAPE 6 ==========
// Objectif : Afficher le prix moyen calculé 'averagePrice' dans le paragraphe 'prix-moyen'

// ========== FIN DE L'ETAPE 6 ==========



// =============================
// III. TABLEAU D’OBJETS (MENU)
// =============================

const pizzas = [
  {
    name: "Margherita",
    description: "Tomate, mozzarella, basilic",
    price: 9.5,
    isCalzone: false
  },
  {
    name: "Calzone 8 Fromages",
    description: "Mozzarella, chèvre, bleu, parmesan, reblochon, emmental, comté, gorgonzola",
    price: 13.7,
    isCalzone: true
  },
  {
    name: "Pepperoni",
    description: "Tomate, mozzarella, pepperoni",
    price: 11.0,
    isCalzone: false
  },
  {
    name: "Queen Calzone",
    description: "Jambon, champignons, olives, oignons, mozzarella",
    price: 11.5,
    isCalzone: true
  },
  {
    name: "Végétarienne",
    description: "Tomate, courgette, poivrons, aubergines, fromage",
    price: 10.0,
    isCalzone: false
  },
  {
    name: "Calzone BBQ Chicken",
    description: "Poulet, sauce BBQ, oignons rouges, cheddar",
    price: 12.0,
    isCalzone: true
  },
  {
    name: "Spéciale Hawaïenne",
    description: "Poivrons, jalapenos, sauce BBQ, mozzarella, jambon, ananas",
    price: 11.8,
    isCalzone: false
  }
];

// Les éléments du DOM (déjà sélectionnés) :
const showPizzasBtn = document.querySelector("#show-menu-btn");
const calzoneToggle = document.querySelector("#toggle-calzone");
const menuPizzasContainer = document.querySelector("#menu-pizzas");
const calzoneToggleWrapper = document.querySelector(".switch");

// On met de base une variable à faux (elle indiquera l'état du menu, si il est visible ou non) :
let isMenuVisible = false;

// On cache le bouton toggle des calzones dès le départ :
calzoneToggleWrapper.classList.add("hidden");

// Fonction fournie : elle affiche un tableau de pizzas :
function showPizzas(listPizzas) {
  // A chaque nouveau clic, le container du menu se vide :
  menuPizzasContainer.textContent = "";

  // On boucle sur le tableau d'objets contenant toutes les pizzas (chaque pizza est un objet) :
  for (const pizza of listPizzas) {

    // ========== DEBUT DE L'ETAPE 7 ==========
    // Objectif : Créer une <div> et la nommer avec une constante 'card'

    // ========== FIN DE L'ETAPE 7 ==========


    // ========== DEBUT DE L'ETAPE 8 ==========
    // Objectif : Ajouter la classe "pizza-card" à cette constante/div

    // ========== FIN DE L'ETAPE 8 ==========

    
    if (pizza.isCalzone) {

      // ========== DEBUT DE L'ETAPE 9 ==========
      // Objectif : Si la pizza est une calzone, donc que sa propriété isCalzone est égale à 'true',
      // ajouter la classe "calzone" à cette constante/div

      // ========== FIN DE L'ETAPE 9 ==========

    }

    // On affiche dans cette constante/div le texte contenant : nomdelapizza : descriptiondelapizza — prixdelapizza €, et si
    // la pizza est une calzone ou une pizza normale :
    card.textContent = `${pizza.name} : ${pizza.description} — ${pizza.price}€ (${pizza.isCalzone ? "Calzone" : "Normale"})`;

    // ========== DEBUT DE L'ETAPE 10 ==========
    // Objectif : Afficher la const/div 'card' dans le container 'menuPizzasContainer'

    // ========== FIN DE L'ETAPE 10 ==========

    // Fin de la boucle for...of :
  }
  // Fin de la fonction 'showPizzas()' :
}

// Fonction fournie : elle filtre les calzones si le toggle est activé :
function updateMenu() {
  // Si isMenuVisible est faux, on ne fait rien :
  if (!isMenuVisible) return;

  // On déclare une variable pizzasToShow qui pour l'instant est vide :
  let pizzasToShow;

  if (calzoneToggle.checked) {
    // On filtre uniquement les calzones si le bouton des calzones est coché :
    pizzasToShow = pizzas.filter(pizza => pizza.isCalzone);
  } else {
    // Sinon, on affiche toutes les pizzas :
    pizzasToShow = pizzas;
  }

  // On appelle la fonction showPizzas en lui fournissant les éléments à afficher (soit toutes les pizzas,
  // soit que les calzones) :
  showPizzas(pizzasToShow);
}

// Ecouteur d'évènement fourni : en cliquant sur le bouton 'showPizzasBtn' on affiche ou on masque le menu
showPizzasBtn.addEventListener("click", () => {

  // On inverse le booléen :
  isMenuVisible = !isMenuVisible;

  if (isMenuVisible) {
    // Si le menu de toutes les pizzas est visible, on affiche dans le bouton le texte :
    showPizzasBtn.textContent = "Masquer le menu";
    // On montre le bouton permettant de trier les calzones :
    calzoneToggleWrapper.classList.remove("hidden");
    // On appelle la fonction updateMenu() :
    updateMenu();
  } else {
    // Sinon, si rien n'est visible, on affiche dans le bouton le texte :
    showPizzasBtn.textContent = "Afficher le menu";
    // On cache le bouton permettant de trier les calzones :
    calzoneToggleWrapper.classList.add("hidden");
    // On vide le contenu du menu de pizzas :
    menuPizzasContainer.textContent = "";
  }

});

// On écoute le bouton permettant de trier les calzones, dès qu'il change on appelle la fonction updateMenu :
calzoneToggle.addEventListener("change", updateMenu);