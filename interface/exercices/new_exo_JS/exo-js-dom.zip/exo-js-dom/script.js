// TOUT ECRIRE ICI (sauf pour le bonus : coder en JS ici + dans le fichier CSS)

// ========== DEBUT DE L'ETAPE 1 ==========
// Objectif : Sélectionner les éléments HTML
// Utiliser querySelector pour sélectionner le bouton 'toggle-btn' et la div 'box', en leur assignant des constantes.


// ========== FIN DE L'ETAPE 1 ==========



// ========== DEBUT DE L'ETAPE 2 ==========
// Objectif : Ajouter un écouteur d’événement au bouton 'toggle-btn'
// Début du addEventListener :

// Quand on clique dessus, il doit :
// - ajouter OU retirer la classe 'color-change' à la boîte (Astuce : Utiliser classList.toggle) :

// Fin du addEventListener :

// ========== FIN DE L'ETAPE 2 ==========



// ========== DEBUT DE L'ETAPE 3 ==========
// Objectif : Sélectionner les autres boutons
// Utiliser querySelector pour sélectionner les boutons 'move-btn-left' et 'move-btn-right', en leur assignant des constantes.


// ========== FIN DE L'ETAPE 3 ==========



// ========== DEBUT DE L'ETAPE 4 ==========
// Objectif : Ajouter un autre écouteur d’événement pour les boutons 'move-btn-left' et 'move-btn-right'
// Début du addEventListener sur le bouton de gauche :

// Quand on clique sur le bouton gauche, il doit :
// - supprimer la classe 'move-right' :

// - ajouter la classe 'move-left' :

// - changer le texte dans la boîte pour afficher "Déplacée à gauche" :

// Fin du addEventListener du bouton de gauche :


// Début du addEventListener sur le bouton de droite :

// Quand on clique sur le bouton droit, il doit :
// - supprimer la classe 'move-left' :

// - ajouter la classe 'move-right' :

// - changer le texte dans la boîte pour afficher "Déplacée à droite" :

// Fin du addEventListener du bouton de droite :

// ========== FIN DE L'ETAPE 4 ==========



// ========== DEBUT DE L'ETAPE 5 BONUS ==========
// Objectif : Ajouter un écouteur d’événement au bouton secret (il faut fouiller dans le fichier html !)
// Commencer par sélectionner le bouton secret

// Pour qu'il apparaisse, utiliser la formule : nom-de-la-constante-du-bouton-secret.style.display = "block";

// Créer une classe dans le fichier CSS, la nommer comme vous préférez

// Quand on clique sur le bouton secret :
// - la boîte doit revenir au centre
// - on doit pouvoir ajouter OU retirer à la boîte la classe que vous avez créé dans le fichier CSS
// - le texte de la boîte est changé en "Transformation !"
// Dans votre fichier CSS, faites-en sorte que cette classe arrondissent les angles de la boîte...

// ========== FIN DE L'ETAPE 5 BONUS ==========