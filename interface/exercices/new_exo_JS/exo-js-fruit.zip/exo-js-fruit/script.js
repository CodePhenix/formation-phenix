// TOUT ECRIRE ICI, DANS LE FICHIER SCRIPT.JS

// Objectif : Réaliser un mini quiz sur les fruits avec un affichage conditionnel
// En fonction de la réponse à la question "Quel est votre fruit préféré", on souhaite
// afficher un texte personnalisé pour plusieurs réponses.

// ========== DEBUT DE L'ETAPE 1 ==========
// Objectif : Sélectionner les éléments HTML via la déclaration de constantes (Astuce :
// utilisez une méthode JavaScript commençant par query... et finissant par ...tor)
// Il nous faut les éléments suivants (allez vérifier dans le fichier HTML !) :
// - L'input de type texte pour récupérer la réponse à la question :

// - Le bouton "Valider" :

// - Le paragraphe prévu pour afficher le texte personnalisé (la réponse) :

// - Le bouton "Changer de thème" :

// ========== FIN DE L'ETAPE 1 ==========



// ========== DEBUT DE L'ETAPE 2 ==========
// Objectif : Ajouter un écouteur d’événement sur le clic du bouton "Valider"
// Début du addEventListener :

// Quand on clique dessus, on doit :
// - récupérer la valeur du champ texte via la déclaration d'une nouvelle constante (Astuce :
// utiliser la propriété .value) :

// - convertir cette valeur en minuscules avec la méthode .toLowerCase() (pour être sûr d'avoir 
// le bon texte à comparer ensuite) via la déclaration d'une autre constante :

// Conseil : Bien sûr, adaptez le nom des constantes pour qu'elles soient compréhensibles facilement !
// ATTENTION, c'est la fin de l'étape 2, mais pas la fin du addEventListener(), il ne faut pas fermer
// l'accolade maintenant !
// ========== FIN DE L'ETAPE 2 ==========



// ========== DEBUT DE L'ETAPE 3 ==========
// Objectif : Vérifier le contenu de la réponse et agir en conséquence
// Début du if (la condition qui suit doit être entre parenthèses) :
// - si la réponse (ma constante dernière constante déclarée, celle qui capte la réponse de 
// l'utilisateur convertie en minuscule) inclus le mot "pomme" (utilisez soit la méthode includes() 
// soit l'opérateur === ), alors conséquence (ouvrez les accolades) : 

// - afficher un message adapté (ex : "Votre fruit préféré est la pomme, excellent choix" ou
// encore : "Vous avez choisi la pomme, le fruit des bretons, kenavo !", comme vous voulez), en
// sélectionnant la constante représentant le paragraphe prévu pour afficher le texte personnalisé 
// (la réponse), et lui donner un nouveau texte... (Astuce : la propriété JS commence par text... 
// et finit par ...tent) :

// - fin de la conséquence/instruction, début du else if pour une autre condition : refaites le même
// procédé pour les fruits suivants : "fraise", "poire", "banane", "ananas" (à chaque fois, personnalisez
// le message de la réponse) :












// - si le champ est vide, afficher un message spécifique (ex : "Vous n'avez pas de
// fruit préféré ?", Astuce : un champ vide peut s'écrire "") :


// - sinon (donc juste else, pas de else if, car il n'y a pas de condition), afficher un message par 
// défaut (ex : "Je ne connais pas le nom de ce fruit") :


// Fin du if/else...if et de l'étape 3 :

// ... mais également fin du addEventListener() :

// ========== FIN DE L'ETAPE 3 ==========



// ========== DEBUT DE L'ETAPE 4 ==========
// Objectif : Ajouter un écouteur d’événement sur le bouton "Changer de thème"
// Début du addEventListener :

// Quand on clique dessus, on doit :
// - ajouter OU retirer la classe "dark" sur document.body :

// Cela permet de basculer entre le thème clair et le thème sombre (quelle chance, la
// classe dark est déjà prévue pour le body dans le fichier CSS, allez y faire un tour !)
// Fin du addEventListener :

// ========== FIN DE L'ETAPE 4 ==========



// ========== DEBUT DE L'ETAPE 5 BONUS ==========
// Objectif : Afficher un fond différent au body pour chaque fruit
// Là, il va falloir retourner dans la partie codée pendant les étapes 2 et 3 :
// - dans l'écouteur d'évènement du bouton Valider, avant les if, enlever les classes "pomme",
// "fraise", "poire", "banane", et "ananas" au document.body
// - dans chaque condition du if/else...if, ajouter la classe correspondant au fruit renseignée par 
// l'utilisateur au body (ça tombe bien, toutes les classes dont le nom est égal à ces fruits ont déjà
// des propriétés css affiliées au body, et même au body en mode dark)
// ex : si la réponse inclus le mot "pomme", alors non seulement nous allons afficher du texte
// personnalisé pour cette réponse, mais nous allons aussi ajouter la classe "pomme" à mon document.body
// ========== FIN DE L'ETAPE 5 BONUS ==========