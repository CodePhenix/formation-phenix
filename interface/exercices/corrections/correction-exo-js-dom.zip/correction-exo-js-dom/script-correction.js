// Étape 1 : Sélectionner les éléments HTML
const toggleButton = document.querySelector('#toggle-btn');

const box = document.querySelector('.box');

// Étape 2 : Ajouter un écouteur d’événement au bouton 'toggle-btn'
toggleButton.addEventListener('click', function () {
  box.classList.toggle('color-change');
});

// Étape 3 : Sélectionner les autres boutons
const moveButtonLeft = document.querySelector('.move-btn-left');

const moveButtonRight = document.querySelector('.move-btn-right');

// Étape 4 : Ajouter un écouteur d’événement au bouton move
moveButtonLeft.addEventListener('click', function () {
  box.classList.remove('move-right');
  box.classList.add('move-left');
  box.textContent = 'Déplacée à gauche';
});

moveButtonRight.addEventListener('click', function () {
  box.classList.remove('move-left');
  box.classList.add('move-right'); 
  box.textContent = 'Déplacée à droite'; 
});


// Étape 5 Bonus : Ajouter un écouteur d’événement au bouton 'secret-btn'
const secretButton = document.querySelector('#secret-btn');

secretButton.style.display = "block";

secretButton.addEventListener('click', function () {
  box.classList.remove('move-left', 'move-right');
  box.classList.toggle('border-circle');
  box.textContent = 'Transformation !';
});