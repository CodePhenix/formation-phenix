console.log("Démarrage du jeu");

// ========== DEBUT DE L'ETAPE 2 ==========
// Objectif : Tirer un nombre aléatoire
// On ajoute la fonction pour tirer un nombre aléatoire
// Dans cette fonction :
// > min et max sont des arguments de la fonction
// > on définit dans la fonction une constante, qui est renvoyée hors de la fonction (ça sera sa valeur)
// > cette constante reprend la formule Math.floor(Math.random() * (max - min + 1)) + min
// > cette constante est locale à la fonction (DONC non accessible à l'extérieur)
// > on utilise return pour retourner la constante 
function generateRandomNumber(min, max) {
    const searchedNumber = Math.floor(Math.random() * (max - min + 1) + min);
    console.log(`Nombre généré : ${searchedNumber}`);
    return searchedNumber;
}
// Fin de la fonction

// On appelle la fonction définie plus haut
// > si randomNumber est la const qui récupère le résultat du lancer de dé, et generateRandomNumber() la fonction :
const randomNumber = generateRandomNumber(1, 6);

// Variable de la position à injecter dans backgroundPosition plus tard pour décaler le sprite de l'image des dés :
const position = (randomNumber - 1) * 100;

// ========== DEBUT DE L'ETAPE 1 ==========
// Objectif : Création d'un dé
// Création d'une div :
const diceDiv = document.createElement("div");

// On utilise la formule style.backgroundPosition = "-" + position + "px 0" pour faire
// bouger l'image afin de tomber sur le visuel de la face du dé correspondant au chiffre obtenu aléatoirement :
diceDiv.style.backgroundPosition = "-" + position + "px 0";
// ========== FIN DE L'ETAPE 2 ==========

// Ajout de la classe dice :
diceDiv.classList.add("dice");

// Sélection du container avec l'id 'player' :
const divPlayer = document.querySelector("#player");

// Remplacement de la classe 'hidden' par la classe 'board' :
divPlayer.className = "board";

// Mettre la div dans le container :
divPlayer.appendChild(diceDiv);
// ========== FIN DE L'ETAPE 1 ==========