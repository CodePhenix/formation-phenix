console.log("Démarrage du jeu");

// ========== DEBUT DE L'ETAPE 1 ==========
// Objectif : Création d'un dé

// Création d'une div :
const diceDiv = document.createElement("div");

// Ajout de la classe dice :
diceDiv.classList.add("dice");

// Sélection du container avec l'id 'player' :
const divPlayer = document.querySelector("#player");

// Remplacement de la classe 'hidden' par la classe 'board' :
divPlayer.className = "board";

// Mettre la div dans le container :
divPlayer.appendChild(diceDiv);
// ========== FIN DE L'ETAPE 1 ==========