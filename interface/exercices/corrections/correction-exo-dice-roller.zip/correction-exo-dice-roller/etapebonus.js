console.log("Démarrage du jeu");

// ========== DEBUT DE L'ETAPE 2 ==========
// Objectif : Tirer un nombre aléatoire
// On ajoute la fonction pour tirer un nombre aléatoire
// Dans cette fonction :
// > min et max sont des arguments de la fonction
// > on définit dans la fonction une constante, qui est renvoyée hors de la fonction (ça sera sa valeur)
// > cette constante reprend la formule Math.floor(Math.random() * (max - min + 1)) + min
// > cette constante est locale à la fonction (DONC non accessible à l'extérieur)
// > on utilise return pour retourner la constante 
function generateRandomNumber(min, max) {
    const searchedNumber = Math.floor(Math.random() * (max - min + 1) + min);
    console.log(`Nombre généré : ${searchedNumber}`);
    return searchedNumber;
}
// Fin de la fonction

// ========== DEBUT DE L'ETAPE 3 ==========
// Objectif : Lancer plusieurs dés
// On définit une variable qui sera le nombre de dés lancé :
let nbDices = 4;

// ========== DEBUT DE L'ETAPE 4 ==========
// Objectif : Choisir le nombre de dés à lancer
// On va chercher la div qui permet de sélectionner le nombre de dés, et on l'affiche :
const nbDiceSelector = document.querySelector("#number-dice-selector");
nbDiceSelector.classList.remove("hidden");

// On va chercher le curseur et la valeur du nombre de dés :
const cursor = document.querySelector("#cursor");
const valueNbDice = document.querySelector("#value-nb-dice");

// On va chercher le bouton qui permet de lancer les dés, et on l'affiche :
const playBtn = document.querySelector("#play-game");
playBtn.classList.remove("hidden");

// Au changement du curseur, lorsque l'input est modifié :
// - le texte de la valeur du nombre de dés affichée doit se modifier et être égale à la valeur du curseur
// - la variable du nombre de dés doit être égal à la valeur du curseur (comme cette dernière est une chaîne de
// caractères, il faut la transformer en Number grâce à la fonction 'Number()')
cursor.addEventListener("input", () => {
    valueNbDice.textContent = cursor.value;
    nbDices = Number(cursor.value);
});

// On créé une nouvelle fonction, qui va reprendre ce qu'on a défini dans les étapes précédentes
// Est-ce que cette fonction a besoin d'un paramètre ?
//      NON
// Est-ce que cette fonction a besoin de faire un return ?
//      NON
// Début de cette fonction :
function createDice(containerId) {

    // On appelle la fonction définie plus haut
    // > si randomNumber est la const qui récupère le résultat du lancer de dé, et generateRandomNumber() la fonction :
    const randomNumber = generateRandomNumber(1, 6);

    // Variable de la position à injecter dans backgroundPosition plus tard pour décaler le sprite de l'image des dés :
    const position = (randomNumber - 1) * 100;

    // ========== DEBUT DE L'ETAPE 1 ==========
    // Objectif : Création d'un dé
    // Création d'une div :
    const diceDiv = document.createElement("div");

    // On utilise la formule style.backgroundPosition = "-" + position + "px 0" pour faire
    // bouger l'image afin de tomber sur le visuel de la face du dé correspondant au chiffre obtenu aléatoirement :
    diceDiv.style.backgroundPosition = "-" + position + "px 0";
    // ========== FIN DE L'ETAPE 2 ==========

    // Ajout de la classe dice :
    diceDiv.classList.add("dice");

    // Sélection du container :
    const divPlayer = document.querySelector(containerId);

    // Remplacement de la classe 'hidden' par la classe 'board' :
    divPlayer.className = "board";

    // Mettre la div dans le container :
    divPlayer.appendChild(diceDiv);
    // ========== FIN DE L'ETAPE 1 ==========

    // Fin de la fonction
}

// Au clic sur le bouton "Valider et Lancer" :
playBtn.addEventListener("click", function () {

    // On va chercher la div du player :
    const divPlayer = document.querySelector("#player");
    // On la vide :
    divPlayer.innerHTML = "";

    // On va chercher la div du player 2 :
    const divPlayer2 = document.querySelector("#player2");
    // On modifie le nom de la classe du player 2 ; la classe ne sera plus 'hidden' mais 'board'
    divPlayer2.className = "board";
    // On la vide :
    divPlayer2.innerHTML = "";

    // Il faut boucler avec une boucle for, de 0 au nombre de dés (défini dans notre variable déclarée plus haut)
    // A l'intérieur de cette boucle, on appelle la fonction permettant de créer des dés
    for (let i = 0; i < nbDices; i++) {
        createDice("#player");
        createDice("#player2");
    }
    // ========== FIN DE L'ETAPE 3 ==========

    // Fin du addEventListener :
})
// ========== FIN DE L'ETAPE 4 ==========

