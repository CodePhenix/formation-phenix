// ---------------------------------------------------------
// VARIABLES GLOBALES
// ---------------------------------------------------------

let questions = [];             // Tableau qui contiendra toutes les questions du quiz
let current = 0;                // Index de la question actuellement affichée
let selectedBtn = null;         // Référence au bouton de réponse actuellement sélectionné
let selectedAnswer = null;      // Réponse choisie par l'utilisateur
let userAnswers = [];           // Tableau pour stocker toutes les réponses de l'utilisateur

let time = 20;                  // Temps imparti par question (en secondes)
let timerInterval = null;       // Référence à l'intervalle du timer pour pouvoir l'arrêter

// Éléments DOM
const restartBtn = document.querySelector("#restart-btn");              // Bouton pour recommencer le quiz

const questionNumberElem = document.querySelector("#question-number");  // Élément qui affichera le numéro de question

const progressBar = document.querySelector("#progress-bar");            // Conteneur de la barre de progression
const progressFill = document.querySelector("#progress-fill");          // Barre de progression
const circleContainer = document.querySelector("#timer-circle");        // Conteneur du timer
const circle = document.querySelector("#timer-circle circle");          // Cercle du timer (SVG)
const circleLength = 188;                                               // Longueur du cercle pour l'animation
circle.style.strokeDasharray = circleLength;                            // Initialise le dasharray pour l'animation du cercle
const timeElem = document.querySelector("#time");                       // Élément affichant le temps restant

const quizContainer = document.querySelector("#quiz-container");        // Conteneur de tout le quiz
const questionContainer = document.querySelector("#question");          // Élément qui affichera la question
const answersElem = document.querySelector("#answers");                 // Conteneur des boutons de réponses
const nextBtn = document.querySelector("#next-btn");                    // Bouton "Suivant"
const resultSection = document.querySelector("#result");                // Section qui affichera le résultat final
const resultContainer = document.querySelector("#result-container");    // Conteneur des résultats détaillés
const resultScore = document.querySelector("#result-score");            // Élément pour afficher le score final


// ---------------------------------------------------------
// CHARGER LES QUESTIONS
// ---------------------------------------------------------

fetch("quiz.json")                              // Charge le fichier JSON contenant les questions
    .then(res => res.json())                    // Transforme la réponse en objet JSON
    .then(data => {
        questions = data;                       // Stocke les questions dans la variable globale
        if (!questions.length) {                // Si aucune question n'a été trouvée
            questionContainer.textContent = "Erreur : aucune question trouvée.";
            return;                             // Stop l'exécution
        }
        resultSection.classList.add("hidden");  // Assure que la section des résultats est cachée
        showQuestion();                         // Affiche la première question
    });

// ---------------------------------------------------------
// FONCTIONS UTILES
// ---------------------------------------------------------

// Fonction pour mélanger un tableau
function shuffle(array) {
    return array.sort(() => Math.random() - 0.5);
}

// Fonction pour cacher le bouton "Suivant"
function hideButton() {                  
    nextBtn.classList.add("hidden");
}

// Fonction pour afficher le bouton "Suivant"
function showButton() {                  
    nextBtn.classList.remove("hidden");
}

// Fonction pour démarrer le timer d'une question
function startTimer(onTimeout) { 
    circleContainer.classList.remove("hidden");
    clearInterval(timerInterval);           // S'assure qu'aucun timer précédent ne tourne
    time = 20;                              // Réinitialise le temps à 20 secondes
    timeElem.textContent = time;            // Affiche le temps initial
    circle.style.strokeDashoffset = 0;      // Réinitialise l'animation du cercle

    timerInterval = setInterval(() => {     // Crée un intervalle qui décrémente le temps toutes les secondes
        time--;
        timeElem.textContent = time;        // Met à jour l'affichage du temps
        circle.style.strokeDashoffset = circleLength - (time / 20) * circleLength; // Met à jour l'animation du cercle

        if (time <= 0) {                    // Si le temps est écoulé
            clearInterval(timerInterval);   // Stop le timer
            onTimeout();                    // Appelle la fonction de timeout (passage auto à la question suivante)
        }
    }, 1000);
}

// ---------------------------------------------------------
// AFFICHER UNE QUESTION
// ---------------------------------------------------------

function showQuestion() {
    progressBar.classList.remove("hidden");
    questionNumberElem.classList.remove("hidden");
    const currentQuestion = questions[current];       // Récupère la question actuelle
    questionNumberElem.textContent = `${current + 1} / ${questions.length}`; // Affiche le numéro de question
    if (!currentQuestion) {                           // Si aucune question n'existe (fin du quiz)
        showResult();                    // Affiche le résultat final
        return;
    }

    // Cache la section résultat pendant le quiz
    resultSection.classList.add("hidden");

    hideButton();               // Cache le bouton "Suivant" tant qu'aucune réponse n'est sélectionnée
    answersElem.innerHTML = ""; // Vide les anciennes réponses
    selectedBtn = null;         // Réinitialise le bouton sélectionné
    selectedAnswer = null;      // Réinitialise la réponse sélectionnée

    questionContainer.textContent = currentQuestion.question; // Affiche le texte de la question

    // Mélange les réponses pour éviter l'ordre fixe
    const answers = shuffle([...currentQuestion.answers]);

    // Création des boutons pour chaque réponse
    answers.forEach(answer => {
        const btn = document.createElement("button");   // Crée un bouton
        btn.textContent = answer.text;                  // Texte du bouton
        btn.className = "answer-btn";                   // Classe CSS
        btn.dataset.correct = answer.value;             // Stocke si la réponse est correcte

        btn.addEventListener("click", () => {           // Gestion du clic sur une réponse
            // Déselection si on reclique dessus
            if (btn === selectedBtn) {
                btn.classList.remove("selected");
                selectedBtn = null;
                selectedAnswer = null;
                hideButton();                           // Cache le bouton "Suivant"
                return;
            }
            if (selectedBtn) selectedBtn.classList.remove("selected"); // Déselectionne l'ancienne réponse
            btn.classList.add("selected");          // Sélectionne le nouveau bouton
            selectedBtn = btn;                      // Met à jour le bouton sélectionné
            selectedAnswer = answer;                // Met à jour la réponse sélectionnée
            showButton();                           // Affiche le bouton "Suivant"
        });

        answersElem.appendChild(btn);               // Ajoute le bouton au DOM
    });

    startTimer(() => autoNext());                   // Démarre le timer et passe automatiquement à la question suivante si le temps expire
}

// ---------------------------------------------------------
// TIMEOUT → PASSAGE AUTOMATIQUE
// ---------------------------------------------------------

function autoNext() {
    if (!selectedAnswer) selectedAnswer = null;   // Si aucune réponse n'est sélectionnée, reste null
    goNextQuestion();                             // Passe à la question suivante
}

// ---------------------------------------------------------
// PASSAGE À LA QUESTION SUIVANTE
// ---------------------------------------------------------

function goNextQuestion() {
    clearInterval(timerInterval);                 // Stop le timer actuel

    progressBar.classList.remove("hidden");

    // Sauvegarde la réponse de l'utilisateur
    userAnswers.push({
        question: questions[current].question,   // Texte de la question
        answers: questions[current].answers,     // Toutes les réponses possibles
        userAnswer: selectedAnswer ? selectedAnswer.text : null // Réponse choisie ou null
    });

    current++;                                   // Passe à la question suivante

    // Si des questions restent
    if (current < questions.length) {
        const progress = (current / questions.length) * 100;    // Calcule la progression
        progressFill.style.width = progress + "%";              // Met à jour la barre de progression
        showQuestion();                                         // Affiche la prochaine question
    } else {
        // Si toutes les questions ont été répondues
        progressFill.style.width = "100%";                 // Barre de progression complète

        setTimeout(() => {
            showResult();                                  // Affiche le résultat final après un petit délai
        }, 700);
    }
}

// Bouton Suivant
nextBtn.onclick = () => {
    if (!selectedAnswer) selectedAnswer = null;   // Si aucune réponse n'est sélectionnée, reste null
    goNextQuestion();                             // Passe à la question suivante
};

// Bouton Recommencer
restartBtn.classList.remove("hidden");
restartBtn.onclick = () => restartQuiz();       // Relance le quiz

// ---------------------------------------------------------
// RECOMMENCER LE QUIZ
// ---------------------------------------------------------

function restartQuiz() {
    progressBar.classList.remove("hidden");
    current = 0;                // Reset index de la question
    userAnswers = [];           // Vide les réponses de l'utilisateur
    selectedAnswer = null;      // Réinitialise la réponse sélectionnée
    selectedBtn = null;         // Réinitialise le bouton sélectionné

    progressFill.style.width = "0%";          // Reset barre de progression
    circle.style.strokeDashoffset = 0;        // Reset animation du cercle
    resultContainer.innerHTML = "";           // Vide les résultats affichés
    resultScore.textContent = "";             // Reset score

    resultSection.classList.add("hidden");    // Cache la section résultat
    quizContainer.classList.remove("hidden"); // Affiche la section quiz

    showQuestion();                           // Affiche la première question
}

// ---------------------------------------------------------
// AFFICHER LE RÉSULTAT FINAL
// ---------------------------------------------------------

function showResult() {
    // Cache le quiz
    quizContainer.classList.add("hidden");

    let scoreCount = 0;                        // Compteur de réponses correctes
    resultContainer.innerHTML = "";            // Vide le conteneur de résultats

    // Pour chaque réponse de l'utilisateur
    userAnswers.forEach(ua => {
        const qDiv = document.createElement("div"); // Crée un div pour chaque question
        qDiv.classList.add("result-question");      // Classe CSS pour la question

        const correctAnswer = ua.answers.find(a => a.value === true).text; // Trouve la réponse correcte
        const isCorrect = ua.userAnswer === correctAnswer;                 // Vérifie si l'utilisateur a répondu correctement

        let prefix = "";
        if (ua.userAnswer === null) {           // Pas de réponse
            prefix = "Pas de réponse";
        } else if (!isCorrect) {                // Réponse incorrecte
            prefix = "Mauvaise réponse";
        } else {                                // Réponse correcte
            prefix = "Bonne réponse";
        }

        const qTitle = document.createElement("p");             // Crée un élément pour le texte de la question
        qTitle.textContent = `${prefix} : "${ua.question}"`;    // Affiche le préfixe + question
        qTitle.classList.add("result-title");                   // Classe CSS
        qDiv.appendChild(qTitle);                               // Ajoute au div question

        // Affiche toutes les réponses possibles
        ua.answers.forEach(ans => {
            const ansDiv = document.createElement("div");   // Div pour chaque réponse
            ansDiv.classList.add("result-answers");         // Classe CSS
            ansDiv.textContent = ans.text;                  // Texte de la réponse

            if (ans.value === true) ansDiv.style.backgroundColor = "#A1E6A1"; // Highlight vert pour la bonne réponse
            if (ua.userAnswer === ans.text && ans.value === false) ansDiv.style.backgroundColor = "#F8A6A6"; // Highlight rouge si mauvaise réponse

            qDiv.appendChild(ansDiv);                       // Ajoute au div question
        });

        if (isCorrect) scoreCount++;                        // Incrémente le score si correct
        resultContainer.appendChild(qDiv);                  // Ajoute le div question au conteneur de résultats
    });

    resultScore.textContent = `Score final : ${scoreCount} / ${questions.length}`; // Affiche le score final
    resultSection.classList.remove("hidden");              // Affiche la section résultat
}
