// Je déclare mes variables globales :
let questions = [];             // Tableau pour l'instant vide qui contiendra toutes les questions du quiz
let currentIndex = 0;                // Index (emplacement dans le tableau) de la question actuellement affichée
let selectedBtn = null;         // Référence au bouton de réponse actuellement sélectionné (pour l'instant à null car non sélectionné)
let selectedAnswer = null;      // Réponse choisie par l'utilisateur (pour l'instant à null car pas de réponse sélectionnée au départ)
let userAnswers = [];           // Tableau pour l'instant vide pour stocker toutes les réponses de l'utilisateur

// Je déclare mes constantes globales :
const questionContainer = document.querySelector("#question");          // - la div conteneur qui affichera la question
const nextBtn = document.querySelector("#next-btn");                    // - le bouton "Suivant"
const resultSection = document.querySelector("#result");                // - la section qui affichera le résultat final du quiz
const resultScore = document.querySelector("#result-score");            // - la div pour afficher le score final

// ========== DEBUT DE L'ETAPE 1 ==========
// Objectif : Créer les constantes qui viennent récupérer tous les éléments du DOM
// ** Il va également falloir venir récupérer :
const quizContainer = document.querySelector("#quiz-container");        // - la div principale qui est le conteneur de tout le quiz
const answersElem = document.querySelector("#answers");                 // - la div conteneur des boutons de réponses
const resultContainer = document.querySelector("#result-container");    // - le conteneur des résultats détaillés
// ========== FIN DE L'ETAPE 1 ==========

// Pour charger les questions, on utilise le fetch, qui est une fonction globale fournie par l’environnement.
// Ici, on va venir 'fetch' (on va 'aller chercher') le fichier de type JSON contenant les questions et leurs réponses
fetch("quiz.json")
    // Même si le fichier est déjà en JSON, fetch ne donne pas directement l’objet JavaScript, mais une réponse HTTP.
    // Il faut donc lire le contenu de cette réponse nommée 'res' et le convertir en objet JS utilisable.
    .then(res => res.json())
    // Quand l’opération asynchrone est terminée avec succès, on exécute la suite, grâce au .then :
    // .then() ne s’exécute pas tout de suite, il attend que la 'Promise' (la promesse de ce qui est demandé avant) soit résolue.
    .then(data => {
        // On récupère le contenu transformé en objet JS nommé 'data', 
        // qu'on va stocker dans la variable du tableau pour l'instant vide qui contiendra toutes les questions du quiz
        questions = data;     
        // Si aucune question n'a été trouvée (que la longueur du tableau n'est pas en positif, donc que le tableau est vide) :                  
        if (!questions.length) {      
            // On écrit alors dans la div conteneur qui affichera la question :      
            questionContainer.textContent = "Erreur : aucune question trouvée.";
            // Le 'return' va stopper l'éxécution de la suite du fetch :
            return;
        }
        // On s'assure que la section des résultats est cachée
        resultSection.classList.add("hidden");
        // Et on lance la fonction showQuestion() déclarée plus bas, qui affichera la première question :
        showQuestion();                         
    });


// Fonction pour afficher une question :
function showQuestion() {
    // On récupère la question actuelle en allant la chercher dans le tableau des questions, à l'index actuel :
    // questions[0] va me donner la première question, questions[1] la deuxième, etc.
    const currentQuestion = questions[currentIndex];       
    // Si aucune question n'existe (si c'est la fin du quiz) :
    if (!currentQuestion) { 
        // On appelle la fonction showResult() définie plus bas pour afficher le résultat final                           
        showResult();    
        // Et le 'return' va stopper la suite de la fonction showQuestion()              
        return;
    }

    // On réinitialise le bouton sélectionné 
    selectedBtn = null;  

    // On réinitialise la réponse sélectionnée    
    selectedAnswer = null;              


    // ========== DEBUT DE L'ETAPE 2 ==========
    // Objectif : Afficher correctement la question actuelle à l'écran :

    // ** Cacher la section résultat pendant le quiz en lui ajoutant la classe 'hidden' (aller vérifier cette classe en css):
    resultSection.classList.add("hidden");

    // ** Cacher le bouton "Suivant" pour le moment (tant qu'aucune réponse n'est sélectionnée) en lui ajoutant aussi la classe 'hidden' :
    nextBtn.classList.add("hidden");  

    // ** Vider la div conteneur des boutons de réponses (Astuce : utiliser innerHTML) :
    answersElem.innerHTML = "";   

    // ** Afficher le texte de la question = le texte de la div conteneur qui affichera la question doit être égal à la valeur
    // de la propriété 'question' de l'objet 'currentQuestion' (la question actuelle)
    questionContainer.textContent = currentQuestion.question; 
    // ========== FIN DE L'ETAPE 2 ==========

    // ========== DEBUT DE L'ETAPE 3 ==========
    // Objectif : Afficher correctement les réponses possibles à la question actuelle à l'écran :
    // ** Définir dans une constante les réponses de la question actuelle (la propriété 'answers' (qui est un tableau) de l'objet 'currentQuestion') :
    const answers = currentQuestion.answers;

    // Comme il y a plusieurs réponses dans chaque question, il va falloir créer plusieurs boutons (un par réponse) pour que l'utilisateur puisse
    // cliquer dessus :
    // ** Commencer par faire une boucle 'forEach' sur la constante que vous venez de définir :
    answers.forEach(answer => {
        
        // ** Créer un élément de type 'button' contenu dans une constante :
        const btn = document.createElement("button");

        // ** Donner au texte du bouton la propriété 'text' de l'objet de chacune des réponse :
        btn.textContent = answer.text;

        // ** Donner la classe CSS "answer-btn" à ce bouton :            
        btn.className = "answer-btn";

        // dataset est une propriété des éléments HTML qui permet d’accéder aux attributs data-* 
        // Ces attributs servent à stocker des informations personnalisées dans le HTML, sans que ça gêne le rendu ou le style.
        // Ils sont très utilisés pour passer des données du HTML au JS.
        // On peut mettre plusieurs propriétés dedans : 'button.dataset.id', 'button.dataset.role', etc.
        // ** Stocker dans la propriété dataset.correct du bouton la propriété 'value' de l'objet de chacune des réponse :             
        btn.dataset.correct = answer.value;                

        // ** Ecouter le clic sur un bouton de réponse :
        btn.addEventListener("click", () => {   
            // Début de if : si le bouton est strictement égal au bouton sélectionné (selectedBtn) :   
            if (btn === selectedBtn) {
                // ** alors on enlève la classe 'selected' au bouton :
                btn.classList.remove("selected");
                // ** 'selectedBtn' et 'selectedAnswer' redeviennent 'null' :
                selectedBtn = null;
                selectedAnswer = null;
                // ** Cacher le bouton "Suivant" en lui ajoutant la classe 'hidden' :
                nextBtn.classList.add("hidden");
                // ** Faire un 'return' pour ne pas exécuter la fin du addEventListener :
                return;
                // ** Fin du if :
            }

            // Si un autre bouton avait été sélectionné, on déselectionne l'ancienne réponse
            if (selectedBtn) selectedBtn.classList.remove("selected"); 

            // ** Sélectionner le nouveau bouton en lui ajoutant la classe 'selected' :
            btn.classList.add("selected");     

            // ** Mettre à jour le bouton sélectionné 'selectedBtn' (il doit être égal au bouton sur lequel on vient de cliquer) :
            selectedBtn = btn;          

            // ** Mettre à jour la réponse sélectionnée 'selectedAnswer' (elle doit être égale à la réponse actuelle sélectionnée)
            selectedAnswer = answer;  

            // ** Affiche le bouton "Suivant" en lui enlevant la classe 'hidden' :       
            nextBtn.classList.remove("hidden");    
            
            // ** Fin du addEventListener :
        });

        // ** Ajouter le bouton au DOM dans la div conteneur des boutons de réponses :
        answersElem.appendChild(btn); 

        // ** Fin de la boucle forEach :
    });
    // ========== FIN DE L'ETAPE 3 ==========

    // Fin de la fonction showQuestion() :
}

// Fonction pour passer à la question suivante :
function goNextQuestion() {

    // On sauvegarde la réponse de l'utilisateur dans le tableau 'userAnswers'
    userAnswers.push({
        // Texte de la question
        question: questions[currentIndex].question,    
        // Toutes les réponses possibles  
        answers: questions[currentIndex].answers,       
        // Réponse choisie ou null si pas de réponse
        userAnswer: selectedAnswer ? selectedAnswer.text : null
    });

    // On passe à la question suivante en ajoutant de +1 la variable 'currentIndex'
    currentIndex++;                                     

    // Si il reste des questions dans le tableau (on regarde la longueur du tableau que l'on compare avec l'index actuel)
    if (currentIndex < questions.length) {
        // Si l'index est toujours inférieur à la longueur du tableau (ex : index 3 alors qu'il y a 7 questions), on affiche
        // la prochaine question en appelant la fonction showQuestion()
        showQuestion();                             
    } else {
        // Sinon (si c'est la fin du tableau des questions), on affiche le résultat final :
        showResult();    
        // Fin du if...else :                       
    }
    // Fin de la fonction goNextQuestion() :
}

// Sur le clic du bouton "Suivant"
nextBtn.onclick = () => {
    // Si aucune réponse n'est sélectionnée, reste null
    if (!selectedAnswer) selectedAnswer = null; 
    // On passe à la question suivante en appelant la fonction goNextQuestion()
    goNextQuestion();                               
};


// Fonction pour afficher le résultat final du quiz :
function showResult() {

    // ========== DEBUT DE L'ETAPE 4 ==========
    // Objectif : Afficher le résultat final du quiz :
    // ** Cacher la div principale qui est le conteneur de tout le quiz en lui ajoutant la classe 'hidden' :
    quizContainer.classList.add("hidden");

    // On initialise une variable qui sera le compteur de réponses correctes (pour l'instant égal à 0)
    let scoreCount = 0;

    // ** Vider au cas où le conteneur des résultats détaillés :                       
    resultContainer.innerHTML = "";            

    // Pour chaque réponse de l'utilisateur (utilisation de la boucle forEach sur le tableau des 'userAnswers')
    userAnswers.forEach(userAnswerElement => {
        // ** Créer une div pour chaque question dans une constante :
        const questionDiv = document.createElement("div"); 

        // ** Ajouter à cette constante la classe CSS 'result-question' :
        questionDiv.classList.add("result-question");     

        // On trouve la réponse correcte grâce à la méthode find = on va chercher la propriété 'text' de la réponse qui a également
        // sa propriété 'value' à true (donc dans correctAnswer, on aura le texte de la bonne réponse à chaque question)
        const correctAnswer = userAnswerElement.answers.find(answer => answer.value === true).text; 

        // On vérifie si l'utilisateur a répondu correctement en comparant la propriété userAnswer définie plus haut et la bonne réponse de
        // chaques question ; cette vérification est placée dans un booléen isCorrect (soit à true, soit à false)
        const isCorrect = userAnswerElement.userAnswer === correctAnswer;                 

        // On va écrire davantage de texte avant l'affichage de l'intitulé de la question, soit :
        let prefix = "";
        // "Pas de réponse" :
        if (userAnswerElement.userAnswer === null) {           
            prefix = "Pas de réponse";
        // "Mauvaise réponse" :
        } else if (!isCorrect) {                
            prefix = "Mauvaise réponse";
        // ou "Bonne réponse" :
        } else {                                
            prefix = "Bonne réponse";
        }

        // ** Créer un élément pour le texte de la question (préfixe et titre de la question) dans une constante :
        const questionTitle = document.createElement("p"); 

        // ** Donner à cette constante le texte correspondant à valeurPréfixe : valeurDeLaPropriétéQuestionDuuserAnswerElement :
        questionTitle.textContent = `${prefix} : "${userAnswerElement.question}"`;  

        // ** Donner à cette constante la classe CSS result-title :
        questionTitle.classList.add("result-title");        

        // ** Ajouter cette constante dans la div pour chaque question (que vous avez créé juste après le début du forEach) :  
        questionDiv.appendChild(questionTitle);                               

        // On affiche toutes les réponses possibles
        userAnswerElement.answers.forEach(answerElement => {
            // Div pour chaque réponse
            const answerDiv = document.createElement("div");
            // Classe CSS   
            answerDiv.classList.add("result-answers");       
            // Texte de la réponse  
            answerDiv.textContent = answerElement.text;                  

            // Highlight vert pour la bonne réponse
            if (answerElement.value === true) answerDiv.style.backgroundColor = "#A1E6A1"; 
            // Highlight rouge si mauvaise réponse
            if (userAnswerElement.userAnswer === answerElement.text && answerElement.value === false) answerDiv.style.backgroundColor = "#F8A6A6"; 

            // ** Ajouter cette div 'answerDiv' dans la div pour chaque question (que vous avez créé juste après le début du forEach) :  
            questionDiv.appendChild(answerDiv);                      
        });

        // On incrémente le score si isCorrect = true
        if (isCorrect) scoreCount++;  

        // ** Ajouter la div question au conteneur de résultats détaillés             
        resultContainer.appendChild(questionDiv);      
        
        // Fin de la boucle forEach :
    });

    // On affiche le score final (avec à côté le nombre de questions du quiz)
    resultScore.textContent = `Score final : ${scoreCount} / ${questions.length}`; 

    // ** Pour afficher la section qui affichera le résultat du quiz, lui enlever la classe 'hidden' :
    resultSection.classList.remove("hidden");  
    // ========== FIN DE L'ETAPE 4 ==========
    
    // Fin de la fonction showResult() :
}
