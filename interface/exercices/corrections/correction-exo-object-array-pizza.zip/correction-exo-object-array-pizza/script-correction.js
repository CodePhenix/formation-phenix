// =============================
// I. OBJET PIZZA
// =============================

const onePizza = {
  name: "Margherita",
  description: "Tomate, mozzarella, basilic",
  price: 9.5
};

const pizzaObjetDiv = document.querySelector("#pizza-objet");

pizzaObjetDiv.textContent = `${onePizza.name} : ${onePizza.description} — ${onePizza.price}€`;


// =============================
// II. TABLEAU DE PRIX
// =============================

const pricePizzasArray = [9.5, 13.7, 11.0, 11.5, 11.0, 12.0, 11.8];

const pricePizzaDiv = document.querySelector("#prix-array");

for (const price of pricePizzasArray) {
  const pizzaPriceP = document.createElement("p");
  pizzaPriceP.textContent = `${price}€`;
  pricePizzaDiv.appendChild(pizzaPriceP);
}

// Calcul et affichage du prix moyen
const averagePrice = pricePizzasArray.reduce((sum, currentPrice) => sum + currentPrice, 0) / pricePizzasArray.length;

const averagePriceParagraph = document.querySelector("#prix-moyen");

averagePriceParagraph.textContent = `Prix moyen : ${averagePrice} €`;


// =============================
// III. TABLEAU D’OBJETS (MENU)
// =============================

const pizzas = [
  {
    name: "Margherita",
    description: "Tomate, mozzarella, basilic",
    price: 9.5,
    isCalzone: false
  },
  {
    name: "Calzone 8 Fromages",
    description: "Mozzarella, chèvre, bleu, parmesan, reblochon, emmental, comté, gorgonzola",
    price: 13.7,
    isCalzone: true
  },
  {
    name: "Pepperoni",
    description: "Tomate, mozzarella, pepperoni",
    price: 11.0,
    isCalzone: false
  },
  {
    name: "Queen Calzone",
    description: "Jambon, champignons, olives, oignons, mozzarella",
    price: 11.5,
    isCalzone: true
  },
  {
    name: "Végétarienne",
    description: "Tomate, courgette, poivrons, aubergines, fromage",
    price: 10.0,
    isCalzone: false
  },
  {
    name: "Calzone BBQ Chicken",
    description: "Poulet, sauce BBQ, oignons rouges, cheddar",
    price: 12.0,
    isCalzone: true
  },
  {
    name: "Spéciale Hawaïenne",
    description: "Poivrons, jalapenos, sauce BBQ, mozzarella, jambon, ananas",
    price: 11.8,
    isCalzone: false
  }
];

const showPizzasBtn = document.querySelector("#show-menu-btn");
const calzoneToggle = document.querySelector("#toggle-calzone");
const menuPizzasContainer = document.querySelector("#menu-pizzas");
const calzoneToggleWrapper = document.querySelector(".switch");

let isMenuVisible = false;

calzoneToggleWrapper.classList.add("hidden");

function showPizzas(listPizzas) {
  menuPizzasContainer.textContent = "";

  for (const pizza of listPizzas) {
    const card = document.createElement("div");
    card.classList.add("pizza-card");

    if (pizza.isCalzone) {
      card.classList.add("calzone");
    }

    card.textContent = `${pizza.name} : ${pizza.description} — ${pizza.price}€ (${pizza.isCalzone ? "Calzone" : "Normale"})`;

    menuPizzasContainer.appendChild(card);
  }
}

function updateMenu() {
  if (!isMenuVisible) return;

  let pizzasToShow;

  if (calzoneToggle.checked) {
    pizzasToShow = pizzas.filter(pizza => pizza.isCalzone);
  } else {
    pizzasToShow = pizzas;
  }

  showPizzas(pizzasToShow);
}

showPizzasBtn.addEventListener("click", () => {

  isMenuVisible = !isMenuVisible;

  if (isMenuVisible) {
    showPizzasBtn.textContent = "Masquer le menu";
    calzoneToggleWrapper.classList.remove("hidden");
    updateMenu();
  } else {
    showPizzasBtn.textContent = "Afficher le menu";
    calzoneToggleWrapper.classList.add("hidden");
    menuPizzasContainer.textContent = "";
  }

});

calzoneToggle.addEventListener("change", updateMenu);