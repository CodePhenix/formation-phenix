// Étape 1 : Sélectionner les éléments HTML nécessaires en leur assignant une constante
const answerInput = document.querySelector("#answerInput");
const submitBtn = document.querySelector("#submitBtn");
const responseP = document.querySelector("#response");
const themeBtn = document.querySelector("#themeBtn");

// Étape 2 : Ajouter un écouteur d’événement sur le clic du bouton "Valider"
submitBtn.addEventListener("click", () => {
    const answerNotManaged = answerInput.value;
    const answer = answerNotManaged.toLowerCase();

    // Étape 5 Bonus
    document.body.classList.remove("pomme", "fraise", "poire", "banane", "ananas");

    // Étape 3 : Vérifier le contenu de la réponse et agir en conséquence
    if (answer.includes("pomme")) {
    // On aurait aussi pu écrire  : if (answer === "pomme")
        document.body.classList.add("pomme");
        responseP.textContent = "Je vais tomber dans les pommes tellement j'adore ça aussi !";
    } else if (answer.includes("fraise")) {
        document.body.classList.add("fraise");
        responseP.textContent = "Les fraises, c’est l’été !";
    } else if (answer.includes("poire")) {
        document.body.classList.add("poire");
        responseP.textContent = "Vous êtes normand ?";
    } else if (answer.includes("banane")) {
        document.body.classList.add("banane");
        responseP.textContent = "Le jaune, ça nous donne la banane !";
    } else if (answer.includes("ananas")) {
        document.body.classList.add("ananas");
        responseP.textContent = "Est-ce que le S se prononce à la fin ?";
    } else if (answer === "") {
        responseP.textContent = "Pas de fruit préféré ?";
    } else {
        responseP.textContent = "Je connais pas, mais je vous confiance !";
    }


    /*
    switch (answer) {
        case "pomme":
            document.body.classList.add("pomme");
            responseP.textContent = "Je vais tomber dans les pommes tellement j'adore ça aussi !";
            break;

        case "fraise":
            document.body.classList.add("fraise");
            responseP.textContent = "Les fraises, c’est l’été !";
            break;

        case "poire":
            document.body.classList.add("poire");
            responseP.textContent = "Vous êtes normand ?";
            break;

        case "banane":
            document.body.classList.add("banane");
            responseP.textContent = "Le jaune, ça nous donne la banane !";
            break;

        case "ananas":
            document.body.classList.add("ananas");
            responseP.textContent = "Est-ce que le S se prononce à la fin ?";
            break;

        case "":
            responseP.textContent = "Pas de fruit préféré ?";
            break;

        default:
            responseP.textContent = "Je connais pas, mais je vous confiance !";
            break;
    }
    */
});

// Étape 4 : Ajouter un écouteur d’événement sur le bouton "Changer de thème"
themeBtn.addEventListener("click", () => {
    document.body.classList.toggle("dark");
});