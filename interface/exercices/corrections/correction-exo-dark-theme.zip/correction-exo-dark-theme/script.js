const toggleBtn = document.querySelector("#theme-toggle");

toggleBtn.addEventListener("click", () => {
  document.body.classList.toggle("dark-theme");

  if (document.body.classList.contains("dark-theme")) {
    toggleBtn.textContent = "Mode clair";
  } else {
    toggleBtn.textContent = "Mode sombre";
  }
});
