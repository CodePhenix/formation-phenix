# Questions soutenance
## SEO
- Ça veut dire quoi le SEO, et ça désigne quoi exactement ? 
- Comment ça marche le référencement ?
- Comment avez-vous optimisé le SEO de votre site ? (3 choses dans le <head>, 3 dans le <body>) 
- C'est quoi le SEA ?

## Amont projet / Design
- Comment avez-vous fait le design de votre site ? Par quelle étapes êtes-vous passés ?
- Présentez quelques bonnes pratiques de structuration des sites web 
- C'est quoi la différence entre UI et UX ?
- C'est quoi la charte graphique ? 
- C'est quoi l'identité visuelle ?
- C'est quoi leur lien ?
- C'est quoi le responsive ?

## Amont projet / choix technologique
- Quelles sont les différentes étapes de la création d'un projet ?
- Quels sont les outils de gestion de version que vous avez pu utiliser et comment vous en êtes-vous servi ?
- Quel est votre IDE ?
- Quel est votre OS ?
- Quels outils avez-vous utilisé pour débugger lorsque vous coder ?
- Citer des bonnes pratiques en terme d'accessibilité ?
- Quels moyens avez-vous mis en place pour rendre votre site accessible aux personnes en situation de handicap ?

## HTML
- En HTML, c'est quoi une balise et un attribut ?
- En HTML, quelle est la structure typique d'une page (trois grandes balises) ?
- Les balises de titres vont de quel numéro à quel numéro ?

## CSS
- En CSS, comment on gère le côté responsive du site ?
- Ca veut dire quoi faire du mobile-first ?
- En CSS, quels sont les breakpoints pour mobile/tablette et tablette/ordinateur ?
- En CSS, comment charge-t-on une police ? Et comment définit-on une animation ?
- Pouvez-vous citer trois propriétés flex (et à quoi elles servent) ?
- C'est quoi une media query, à quoi ca sert ?
- Que veux dire EM ?
- Quelle est la différence entre EM, REM et PX ?

## Javascript
- En JS, quels sont les différents types de variables ?
- En JS, quand est-ce qu'on utilise const vs let ?
- En JS, quelles sont les différents types de données ?
- Quelles sont les différentes manières de détecter les interactions avec les utilisateurs en JavaScript ?
- Qu'est-ce que le DOM ?
- En JS, avec quelle méthode peut-on aller chercher des éléments du DOM ?
- C'est quoi un écouteur d'évènement et comment l'utilise-ton ?
- C'est quoi la différence entre un fichier JPG et un fichier PNG ?
- C'est quoi une erreur 404 ?
- Que veux-dire RegEx ?
- Quelles sont les caractéristiques des RegEx pour un mot de passe, et où est ce qu'on les place dans le HTML ?

## Sécurité
- C'est quoi l'ANSSI ?
- C'est quoi la RGPD ? la CNIL ?
- C'est quoi OWASP ?
- Pouvez-vous me donner des exemples de failles de sécurité ?
- C'est quoi un mot de passe fort ?

## Divers
- Quels sont vos sites ou outils de références que vous utilisez en développant ?
- Comment peut-on rendre un site plus "éco-responsable" ?
- C'est quoi le versioning ? Comment on peut en faire ?

## Entretien final
- Quelle est la suite pour vous ? Quels objectifs ?

## Accronymes à connaitre
- WWW: World Wide Web, est un système d'information interconnecté qui permet d'accéder à des documents et à d'autres ressources via Internet. 

- HTML: HyperText Markup Language, est le langage de balisage standard utilisé pour créer des pages Web.

- CSS: Cascading Style Sheets (feuilles de style en cascade), est un langage de style utilisé pour décrire l'apparence et la mise en page des documents HTML. CSS permet aux développeurs de contrôler la présentation visuelle d'une page web.

- DOM: Document Object Model, est une interface de programmation qui représente la structure d'un document HTML ou XML sous la forme d'une arborescence d'objets.

- HTTP/HTTPS: Hypertext Transfer Protocol (Secure), protocole utilisé pour récupérer des ressources telles que des fichiers HTML. HTTP fournit une norme de messagerie pour faciliter les échanges de communication entre les clients Web (par exemple, un navigateur) et les serveurs Web.

- API: Application Programming Interface

- CRUD: Create, Read, Update, Delete

- JSON:	JavaScript Object Notation

- SEO:	Search Engine Optimization

- SEA:	Search Engine Advertising

- RGPD:	Règlement Général sur la Protection des Données

- CNIL:	Commission Nationale de l'Informatique et des Libertés

- OWASP:	Open Worldwide Application Security Project

## Vocabulaire qu'ils doivent connaitre
### `<img src="..." class="..."/>`
- C'est une balise
- src et class sont les attributs de la balise

### `let a = 10;`
- On définit une variable
- "a = 10;" on assigne une nouvelle valeur à la variable

### `function addition(a, b)`
- "addition" est le nom de la fonction ; elle est ici définie
- "a" et "b" sont les paramètres définis dans la fonction

### `addition(a, b)`
- "addition" est le nom de la fonction ; elle est ici appelée
- "a" et "b" sont les arguments utilisés dans l'appel de la fonction


