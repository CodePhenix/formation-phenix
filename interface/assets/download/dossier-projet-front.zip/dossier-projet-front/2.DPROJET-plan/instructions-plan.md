# Plan de Dossier de Projet

Aujourd'hui, c'est création du plan de dossier de projet.

En gros, la liste des titres et sous-titres qui vont apparaître dans votre dossier de projet, comment vous allez le présenter, l'ordonner, dans quel sens, pourquoi, comment...

Une sorte de sommaire, mais avec plus de détails : ce fichier va vous permettre de commencer votre dossier de projet plus facilement, de savoir où vous allez et de structurer vos idées !

## Instructions

Pour vous aider, voici une trame d'un plan attendu pour le dossier de projet :

```
I. Introduction
    1. Présentation du projet
    2. Facultatif : Présentation du contexte professionnel

II. Dossier de conception fonctionnel = Cahier des charges
    1. Enjeux
        1.1. Besoins
        1.2. Objectifs
    2. Fonctionnalités du projet
    3. Personnes cibles
        3.1. Cible principale 
        3.2. Cible secondaire 
        3.3. Cœur de cible
        3.4. Personas
    4. User stories
    5. Contraintes techniques et fonctionnelles
    6. Accessibilité
    7. Autres facultatifs (analyse concurrentielle, contexte métier)

III. Dossier de conception structurel = Conception UX/UI
    1. UI : charte graphique
        1.1. Palette de couleurs
        1.2. Typographie
    2. UX
        2.1. Arborescence
        2.2. Zoning (version mobile et desktop)
        2.3. Autres besoins (écoconception, sécurisation, législation)

IV. Maquettage
    1. Wireframes (version mobile et desktop)
    2. User flows
    3. Maquettes (version mobile et desktop)
    4. Autre facultatif (prototypes)

V. Gestion de projet
    1. Organisation de travail
    2. Technologies utilisées
        2.1. Environnement de développeur
        2.2. Environnement technique

VI. Réalisations permettant la mise en œuvre des Compétences
    1. Pages développées
        1.1. Interfaces Utilisateur Statiques Web et Web Mobile
        1.2. Interfaces Utilisateur Dynamiques Web et Web Mobile
    2. SEO
    3. Compatibilité de navigateurs
    4. Accessibilité

VII. Retour d'expérience
    1. Difficultés rencontrées
    2. Évolutions possibles du site
    3. Évolution personnelle
```

Que ce soit bien clair, ceci est un **exemple** de trame, si vous souhaitez ajouter des sous-parties, modifier leur ordre, ou ajouter des sous-sous-parties, faites-le si cela correspond davantage aux qualités de votre projet que vous souhaitez mettre en avant !

Une seule consigne : les grandes parties (en I, II, III etc. jusqu'à VII) doivent rester telles quelles, dans cet ordre.

**Vous pouvez donc commencer l'écriture du dossier de projet !**

Ouvrez un fichier texte avec le logiciel de traitement de texte (OpenOffice Writer, LibreOffice Writer, Word, etc.) de votre choix, nommez le **votrenom-dossier-projet** et commencez par :
- une page de garde qui contiendra le titre de votre certification, le titre 'Dossier de projet', le nom de votre projet, et votre nom,
- le sommaire de votre dossier (qui sera votre plan) ; vous pouvez l'écrire deux fois de suite : une fois pour le sommaire et une autre après avec les gros titres de chaque partie, dans lesquelles vous mettrez la suite du dossier de projet.

## Definition of Done

- [ ] J'ai compris la logique du déroulé du dossier de projet au travers de mon plan.
- [ ] Je visualise en amont tout ce que je vais devoir mettre dans chaque partie (dans les grandes lignes).
- [ ] J'ai créé un fichier texte, que j'ai nommé `dprojet-monnom`.
- [ ] J'ai complété ma page de garde.
- [ ] J'ai renseigné tout le déroulé de mon plan de projet dans un sommaire.
- [ ] J'ai copié/collé mon plan de projet à la suite de mon sommaire pour pouvoir remplir chaque partie plus tard.

### Le mot de la fin

Ca aide pour mieux se repérer dans les tâches à faire, non ?