# Résumé de Projet

Pour commencer gentiment à se rapprocher de la fin, et pour se rendre compte de tout le travail accompli, vous allez écrire le résumé de votre projet ; il s'agit surtout de réduire à l'essentiel votre projet personnel.

Ce résumé va présenter votre projet, il faut donc qu'il soit joli, clair, concis, qu'il dise en un minimum de mots ce que vous avez fait et pourquoi, et surtout, qu'il indique ce que vous avez envie de dire à votre jury en amont de la soutenance sur le-dit projet.

## Objectifs

Compléter la présentation de votre projet, dont une partie servira d'introduction pour votre projet web. Si besoin est, ne pas oublier de présenter le contexte professionnel ayant inspiré (et influencé) votre projet.

## Instructions

La forme du résumé est la suivante : 

> Résumé du projet en français d’une longueur d’environ 20 lignes soit 200 à 250 mots, ou environ 1200 caractères espaces non compris.

Vous pouvez commencer l'écriture de ce fichier avec le logiciel de votre choix, si possible dans le dossier 10.DPROJET-resume pour ne pas s'y perdre !

## Contenu du résumé

Voici quelques indications sur ce que le résumé peut contenir :

- une introduction (d'où vient l'idée, pourquoi ce projet, le contexte pro : c'est ce qui servira d'introduction en première partie de votre dossier de projet)
- l’objectif de l’application web
- les principales fonctionnalités de l’application
- les rôles utilisateurs de l’application (si différents rôles autre que visiteurs)
- les technologies frontend utilisées pour l’application

Ca tombe bien, vous avez déjà défini tout ça (ça peut faire redite, mais ici, on vise un résumé, on ne va pas dans le détail !).

**Pour vous aider dans cette tâche, n'hésitez pas à demander à votre formateur ou à des collègues de consulter des résumés des précédentes promotions.**

## Definition of Done

- [ ] Le résumé de projet a été rédigé dans un fichier de texte à part.

### Le mot de la fin

Vous avez vu votre dossier de projet grandir au fur et à mesure, il est à présent terminé ! La suite au prochain ticket : `DPROJET-final`.