# Charte graphique

Plongeons dans l'essence même de la charte graphique, un véritable guide qui sculpte l'identité visuelle d'une marque, d'un projet ou d'une entreprise. Imaginez-la comme le code génétique de votre image de marque, définissant chaque détail visuel pour transmettre un message clair et cohérent.

Dans cet univers visuel complexe, chaque élément joue un rôle crucial pour véhiculer l'image et les valeurs de la marque de manière efficace et cohérente.

## Objectif

La plupart des éléments suivants doivent être pensés et justifiés, pas choisis au hasard :

1. **Couleurs :** Le choix des couleurs n'est pas anodin. Chaque couleur transmet des émotions et des messages spécifiques. La charte graphique définit donc une palette de couleurs cohérente et harmonieuse, ainsi que leur utilisation appropriée dans différents contextes.

2. **Typographie :** Les polices de caractères utilisées dans la communication visuelle d'une marque contribuent à son identité. La charte graphique spécifie les polices à utiliser pour le logo, les titres, les paragraphes, etc., afin de maintenir une cohérence visuelle.

3. **Images et Illustrations :**  Les images et illustrations jouent un rôle important dans la communication visuelle. La charte graphique peut définir des directives concernant le style, la résolution et l'utilisation des images pour garantir une apparence uniforme et professionnelle.

4. **Mise en Page :** La manière dont les éléments visuels sont disposés sur une page ou un écran est essentielle pour la lisibilité et l'impact visuel. La charte graphique peut inclure des directives sur la structure, la hiérarchie visuelle et l'utilisation de l'espace blanc pour une mise en page efficace.

5. **Iconographie :** Les icônes et les symboles sont des éléments visuels importants pour la navigation et la communication. La charte graphique peut définir un ensemble d'icônes cohérentes pour une utilisation sur les différents supports.

6. **Ton et Style :** La charte graphique peut également définir le ton et le style de la communication visuelle, en spécifiant par exemple un langage visuel formel ou décontracté, moderne ou traditionnel, selon l'image de marque de l'entreprise ou du projet.

7. **Facultatif : Logo :** Le logo est l'élément central de toute charte graphique. Lorsqu'il est possible de le réaliser en amont (souvent par un graphiste, en interne ou non), il incarnera une fois introduit dans les pages web l'essence même de la marque et doit donc être conçu avec soin pour être mémorable, reconnaissable et adaptable à différents formats et contextes.

En résumé, la charte graphique est un document essentiel qui guide l'utilisation cohérente des éléments visuels pour renforcer l'identité et la reconnaissance d'une marque, d'une institution, d'une personne, d'un projet. En respectant ces directives, vous pouvez créer une expérience visuelle unifiée et mémorable pour votre public cible.

## Instructions

Complétez chaque sous-partie de la Charte Graphique dans votre fichier texte du dossier de projet.

Vous pouvez piocher dans certains éléments ci-dessus (ou tous si ils ont tous une importance pour votre projet) afin de justifier vos choix visuels.

Ecrire et justifier sa charte graphique permet de montrer que notre projet a été pensé et préparé et que même un simple bouton au coin d'une page a un style bien particulier pour une certaine raison (couleur vive pour attirer l'oeil, border-radius élevé pour correspondre avec les autres images rondes de la page), que telle police a été choisie car plus sérieuse et lisible pour tous, etc.

## Cours associés et Outils

Se rendre sur https://codephenix.com -> Outils -> Color Wheel, Icomoon, Typos, etc.

## Definition of Done

- [ ] La charte graphique a été pensée, et justifiée à l'écrit dans votre fichier texte du dossier de projet.
- [ ] Savoir répondre à la question : Qu'est-ce qu'une charte graphique et en quoi est-elle cruciale pour la cohérence visuelle d'un projet ?
- [ ] Savoir répondre à la question : Quels sont les différents éléments inclus dans une charte graphique et comment fonctionnent-ils ensemble pour créer une identité visuelle unifiée ?
- [ ] Savoir répondre à la question : Comment choisir les couleurs appropriées pour représenter votre marque et comment les intégrer harmonieusement dans votre design ?
- [ ] Savoir répondre à la question : Quel rôle joue la typographie dans la création de la personnalité visuelle d'une marque et comment choisir les polices de caractères qui correspondent le mieux à votre identité ?

### Le mot de la fin

Avoir un visuel personnalisé pour son propre site, réfléchi en fonction du public cible, des fonctionnalités et selon ses propres goûts, c'est quand même sympa non ?

