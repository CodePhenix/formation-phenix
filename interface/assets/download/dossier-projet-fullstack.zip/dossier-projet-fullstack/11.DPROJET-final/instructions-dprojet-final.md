# FINAL

Félicitations, le dossier de projet est complété ! Enfin, en partie, et ce ticket va vous aider à le finaliser.

## Objectifs

Se relire, apporter de la cohérence; en résumé, il faut rendre votre dossier de projet cohérent et agréable à lire.

## Instructions

Reprenez le fichier texte qui est votre dossier de projet.

A l'aide de votre plan de dossier de projet, vérifiez le contenu des différentes parties que vous avez réalisées pour votre projet :
    - l'introduction de votre projet en partie 1 (vous pouvez vous servir de votre résumé du ticket `DPROJET-resume`),
    - le cahier des charges en partie 2 (réalisé dans le ticket `DPROJET-cdc`: ne pas oublier la capture d'écran du fichier `user-stories.md`),
    - la conception UX/UI en partie 3 (réalisée dans le ticket `DPROJET-ux` : ajouter les dessins des zoning et de l'arborescence),
    - le maquettage en partie 4 (réalisé dans le ticket `DPROJET-maquettage` : ne pas oublier d'intégrer les photos de vos wireframes et de votre user-flow)
    - la gestion de projet en partie 5 (réalisée dans le ticket `DPROJET-gestion-projet`)
    - les réalisations permettant la mise en œuvre des compétences en partie 6 (réalisées dans le ticket `DPROJET-dev`) : 
        - **MONTRER DES EXEMPLES : CA DOIT MARCHER, ET CA SE VOIT**
        - **AJOUTER DES CAPTURES D'ECRAN EN THEME CLAIR**
        - **AJOUTER DES CAPTURES D'ECRAN DE VOTRE SITE WEB**
        - **ARGUMENTER VOS EXEMPLES** (il ne faut pas seulement mettre une capture d'écran mais expliquer ce que vous cherchiez à faire, comment vous l'avez implémenter dans votre code)
        - **COMPLETER LES SOUS-PARTIES** (SEO, Compatibilité de navigateurs, Accessibilité) en décrivant à l'aide de captures d'écran ce que vous avez implémenté.
    - le retour d'expérience en partie 7 (réalisé dans le ticket `DPROJET-retour-xp`) :

- Changer la taille des titres pour qu'ils se voient bien,
- Ajustez le visuel de votre fichier texte (couleurs, police),
- Ajouter une jolie image en page de garde (screenshot du site ou logo),
- Activez la numérotation de pages,
- Votre sommaire doit rendre compte exactement des parties de votre dossier,
- Rendez le propre, lisible, et vérifiez les fautes d'orthographes.

**Pour vous aider dans cette tâche, n'hésitez pas à demander à votre formateur ou à des collègues de consulter des Dossiers de Projets des précédentes promotions.**

### Le mot de la fin

Votre dossier de projet est enfin terminé, pour de vrai cette fois... Il va rester un dernier ticket (cette fois, c'est promis) ; créer votre support pour la soutenance (rassurez-vous, vous allez vous servir de votre dossier de projet pour ça).