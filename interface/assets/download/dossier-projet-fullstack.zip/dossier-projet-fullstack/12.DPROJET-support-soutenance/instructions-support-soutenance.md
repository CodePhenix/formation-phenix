# SUPPORT SOUTENANCE

Le jour de la soutenance, il y aura une présentation de 20min de votre projet; pour cela et pour vous aider à le présenter, un support de type diaporama de 5 à 10 slides pourra bien vous aider !

## Instructions

Pour votre présentation, ouvrez votre meilleur éditeur de présentation (*LibreOffice Impress par exemple*).

1. Utilisez des mots-clés. Pas de phrase dans ce fichier ! Sinon vous allez vouloir les lire et si vous les lisez, ce ne sera pas très naturel devant le jury !

2. Ce support doit contenir le plan de la présentation :
    - une présentation rapide de soi, puis du projet ;
    - une courte parenthèse sur l'historique de la période de projet en fin de formation (comment vous vous êtes organisés) ;
    - l'expression des besoins du projet pour définir les objectifs et les limites du projet ;
    - le cahier des charges, quelques zonings, wireframes et maquettes ainsi que des indications d'UX et d'UI ;
    - les fonctionnalités attendues ;
    - l'environnement technique ;
    - les réalisations permettant la mise en œuvre des compétences (captures d'écran de votre code : **prenez les éléments de code les plus significatifs, ceux qui sont les plus complexes pour montrer ce que vous savez faire**, ainsi qu'une slide prévue pour faire la transition avec la démonstration en direct du code) ;
    - une synthèse (pourquoi pas les prochaines étapes du projet), votre objectif professionnel après la certification, et une conclusion (satisfactions et difficultés rencontrées).

3. Votre présentation découle directement de votre dossier de projet, il s'agit, en quelque sorte, du condensé de ce dernier. Donc ne partez pas d'une page vierge, mais de votre dossier de projet.

4. Numérotez vos slides ! Ça pourra servir pour la présentation (savoir quoi dire à telle ou telle page), et tout ce qui peut vous faciliter la tâche est précieux !

5. Tout comme pour le dossier professionnel et le dossier de projet, il faut continuer d'utiliser des captures de code en thème light !

6. A la fin, vous pouvez nommer ce fichier **votrenom-presentation**.

7. Il ne vous reste plus qu'à écrire un court texte sur ce que vous allez dire pendant la présentation ; là aussi, pas de phrases, c'est juste une fiche d'aide avec des points clés et des grands titres pour savoir quoi dire et dans quel ordre.

**Pour vous aider dans cette tâche, n'hésitez pas à demander à votre formateur ou à des collègues de consulter des supports de soutenance des précédentes promotions.**

### Le mot de la fin
C'était le dernier ticket, bravo ! Félicitations pour tout ce que vous avez accompli pendant ce projet !