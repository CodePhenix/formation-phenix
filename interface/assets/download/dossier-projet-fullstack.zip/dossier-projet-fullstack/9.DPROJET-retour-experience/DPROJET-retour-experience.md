# Retour d'expérience

Après avoir développé votre projet web, le dossier de projet n'est pas tout à fait terminé !

Trois sous-parties sont à remplir : 

1. Difficultés rencontrées : après avoir énoncé les difficultés que vous pensiez rencontrer pendant le développement de votre projet, c'est maintenant le temps de parler des réelles difficultées rencontrées : est ce que ce sont les mêmes ? Est ce que vous avez été freiné par une aspect en particulier (html, css, js) ou au contraire une crainte que vous avez su bien gérer ?

2. Évolutions possibles du site : vous aviez parlé des fonctionnalités 'nice-to-have' (les bonus) ; avez-vous pu en commencer certaines ? Avez vous eu d'autres idées de fonctionnalités à ajouter au cours du développement ?

3. Évolution personnelle : au cours de ce projet, qu'est ce que la préparation des documents de conception et le développement vous ont apporté ? Cela vous a-t-il donné d'autres idées de métiers dans le web ? Qu'est ce que ce projet a conforté dans votre projet professionnel ou dans vos envies futures de projet ?

## Objectif

**Percevoir les évolutions de votre parcours tout au long de ce projet (et aussi pendant la formation en généal !)**

## Instructions

Complétez chaque sous-partie de Retour d'expérience dans votre fichier texte du dossier de projet.

Vous pouvez utiliser votre fichier 'logbook' de suivi de gestion de projet détaillé (dans le dossier 7.DPROJET-gestion-projet) pour voir l'évolution de votre travail et de votre ressenti pendant cette période.

C'est un peu la conclusion de votre dossier de projet !

## Definition of Done

- [ ] La partie 7 'Retour d'Expérience' avec toutes ses sous-parties a été remplie.

### Le mot de la fin

Allez, c'est bientôt fini, courage !