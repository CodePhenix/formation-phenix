# Maquettage

Imaginez que vous êtes un architecte en train de concevoir les plans d'une maison. Avant de commencer la construction, vous avez besoin de maquettes détaillées pour visualiser chaque pièce, chaque mur, chaque fenêtre. De la même manière, dans le domaine du développement de projets, la création de maquettes est une étape essentielle pour concevoir et communiquer efficacement le design d'un site web, d'une application ou de tout autre projet numérique.

Ca tombe bien, vous avez déjà commencé tout ça avec vos dessins de zoning !

## Objectif

1. **Comprendre les Besoins et les Objectifs :** La première étape consiste à comprendre les besoins et les objectifs du projet. (**Ca tombe bien, vous les avez déjà défini !**) Quel est le public cible ? (**Ca tombe bien, vous l'avez déjà défini !**) Quels sont les principaux objectifs de l'interface utilisateur ? (**Ca tombe bien, vous l'avez déjà défini !**) Quelles fonctionnalités doivent être mises en avant ? (**Ca tombe bien, vous les avez déjà défini !**)

2. **Identifier les Éléments Essentiels :** Ensuite, identifiez les éléments essentiels de l'interface utilisateur, tels que le logo, la navigation, les boutons d'action, les carousels, les formulaires, les images et le contenu. Ce sont ces éléments qui seront représentés dans la maquette.

3. **Choisir l'Outil de Création :** Il existe de nombreux outils disponibles pour créer des maquettes, tels que Sketch, Adobe XD, Figma, etc. Mais un bon wireframe peut aussi être fait à la main (on priviligiera l'utilisation d'un règle si possible).

4. **Créer les wireframes :** Commencez par définir la structure générale du wireframe en plaçant les différents éléments sur la page. Utilisez des grilles ou des lignes directrices pour assurer une mise en page cohérente et équilibrée. Comme pour le zoning, il y aura un wireframe par page, en version mobile et desktop, et en noir et blanc.

5. **Créer les maquettes :** Une fois la structure en place, vous pouvez reprendre la base de vos wireframes mais en y ajoutant les détails visuels tels que les couleurs, les typographies, les images et les icônes : ce seront les véritables maquettes, appelées mockups. Veillez à respecter les principes de design et à maintenir la cohérence avec la marque du projet. Ici aussi, on attendra une maquette pour chaque page, en version mobile et desktop.

## Instructions

Créez vos **wireframes** pour toutes les pages principales de votre projet.  
   - Version **mobile** et **desktop**.
   - En **noir et blanc**, à la main ou sur paint, sans design graphique (pas de couleurs, pas de vraies images).
   - Utilisez des zones claires pour les menus, boutons, contenus, formulaires, etc.
   - Soignez l’alignement, la hiérarchie visuelle et l’organisation globale.

Créez ensuite vos **maquettes (mockups)** :
   - Reprenez la base de vos wireframes.
   - Appliquez votre **charte graphique** : couleurs, typographies, icônes, visuels, etc.
   - Toujours en version **mobile** et **desktop**.
   - Chaque maquette doit permettre de comprendre à quoi ressemblera visuellement chaque page du site.

>Des exemples de wireframes et de mockups pour deux pages d'un même site sont disponibles en version desktop et mobile dans le dossier 6.DPROJET-maquettage -> exemples-mockups et exemples-wireframes.

Organisez tous vos fichiers (ou scans/photos de dessins si fait à la main) dans le dossier 6.DPROJET-maquettage (ajoutez des dossiers si vous voulez bien vous y retrouvez), pour garder une bonne structure dans votre projet.

## Definition of Done

- [ ] Avoir créé un **wireframe pour chaque page**, en version mobile ET desktop, en noir et blanc.
- [ ] Avoir créé une **maquette graphique** (mockup) pour chaque page, en version mobile ET desktop, en respectant la charte graphique définie.
- [ ] Savoir répondre à la question : Quels sont les éléments essentiels à prendre en compte lors de la création d'une maquette pour un projet ?
- [ ] Savoir répondre à la question : Pourquoi est-il important de comprendre les besoins et les objectifs du projet avant de commencer la création de la maquette ?
- [ ] Savoir répondre à la question : Quels sont les avantages de l'utilisation de grilles et de lignes directrices lors de la création d'une maquette ?

### Le mot de la fin

Vous êtes presque au bout de la phase de **conception** ! Les maquettes sont votre pont entre l’idée et le code, c’est avec elles que vous allez pouvoir **communiquer visuellement** vos intentions de design et commencer à **donner vie à votre projet**.

Prenez votre temps ici : ce que vous finalisez maintenant, ce sont les plans de votre future interface.