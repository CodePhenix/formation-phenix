# Dossier de projet

En parallèle du Dossier Professionnel, vous allez réaliser un Dossier de Projet de 30 à 50 pages qui suivra l'évolution et la réalisation de votre projet personnel, que ce soit dans la phase de conception et dans la phase de développement.

Voici dans l'ordre toutes les étapes à respecter pour réaliser un projet web (rassurez-vous, chaque étape sera définie dans un ticket, on va faire les choses petit à petit, c'est la clé !).

### Définition du projet : Cahier des charges

Le cahier des charges est un recueil de besoins ; dans le cas d'un contexte client, il se rédige en amont avec le client et formalise : les objectifs du projet, les cibles utilisateurs, les fonctionnalités attendues, les contraintes techniques (navigateur, responsive, accessibilité, etc.), le budget et les délais, les livrables (tout ce qu'il va falloir livrer au client : le projet final, les fichiers, la documentation, les tests, les tutoriels, le dossier de conception, etc...).

Dans le cas d'un projet personnel, cela va être à vous de réfléchir en amont à ces questions, pour définir ces éléments dans le futur dossier de conception de votre projet web, comprenant une partie fonctionnelle qui va reprendre une partie du cahier des charges, et une autre structurelle.

## Dossier de conception

C'est là que débute votre dossier de projet, par un dossier (oui, encore) de conception ! C'est la première étape, c'est à partir de ce moment que vous allez quitter vos fichiers html, css et js, vous les retrouverez d'ici quelques jours ne vous en faites pas... Un dossier de conception s'écrit, se dessine, se réfléchit, et il n'y aura pas une seule ligne de code écrite avant la phase de développement !

### Fonctionnel : Cahier des charges

Le cahier de charges dans votre dossier de conception reprend les questionnements énoncés plus hauts, auxquels il va falloir répondre :

- But / objectifs du projet : Pourquoi ce site / cette application web ? Quels problèmes veut-on résoudre ?

- Public cible / personas : Qui va utiliser le produit ?

- User stories / cas d’usage : Scénarios décrivant les actions possibles par l’utilisateur (souvent sous la forme : En tant que [utilisateur], je veux [action] afin de [but]).

- Les fonctionnalités du projet, et par conséquent, les contraintes fonctionnelles et techniques.

- Les attentes en accessibilité (handicap, responsive, etc.).

- Facultatifs :
    - Analyse concurrentielle : Quels sont les sites similaires ? Qu’est-ce qui fonctionne ailleurs ? Quoi faire pour apporter mieux ?

    - Le contexte métier pour lequel le site web s'applique, pour bien en comprendre les besoins.

### Structure : Conception UX/UI (expérience et interface utilisateur)

#### UI (User Interface ou Interface Utilisateur)

- Charte graphique : Définition des couleurs, typographies, logos, éléments d’identité visuelle.

#### UX (User Experience ou Expérience Utilisateur)

- Zoning : Schéma simplifié qui montre la structure générale d'une page ou d’un écran, sans détails graphiques, montrant la répartition des zones fonctionnelles dans une page (en mode très basique : header, nav, main, sidebar, footer).

- Parcours utilisateur (arborescence) : Cartographie des interactions entre les pages et actions possibles.

- Besoins importants pour l'expérience utilisateur : 
    - Ecoconception = Optimisation des ressources et de l'arborescence pour minimiser les clics, design épuré (pas trop d'animations) pour ne pas alourdir le projet web, contenu léger (images et vidéos) et amélioration de la performance (ex : ne pas mettre trop de polices sur ses pages web ce qui va alourdir le chargement des pages, minimiser le CSS et le JS en factorisant et optimisant au maximum).
    - Tenir compte des exigences de sécurisation pour protéger son site mais aussi pour l'utilisateur, y compris de l’utilisateur en situation de handicap.
    - La législation en vigueur doit être respectée, y compris celle relative à l’accessibilité (en France, c'est le RGAA, le Référentiel général d'amélioration de l'accessibilité qui définit des méthodes et un cadre pour répondre aux exigences en terme d'accessibilité).

## Réalisation des Maquettes graphiques (UI design) et de leur enchainement

Le dossier de conception est prêt ! On peut donc suite au zoning commencer à réaliser :

- les Wireframes en noir et blanc : ce sont des schémas plus précis que le zoning mais toujours simples pour organiser les contenus, sans design, montrant l’agencement des éléments (boutons, formulaires, blocs de contenu...).

- les User Flows, qui sont des schémas simplifiés d'enchaînement des interfaces ; ce sont des parcours dynamiques, scénarisés, avec des conditions, des décisions ("si l’utilisateur clique ici, alors...") qu'il est possible de visualiser facilement. Ils montrent les étapes clés d’un parcours utilisateur, avec des boîtes (étapes, écrans, actions) et des flèches (transitions) : ce sont des représentations abstraites ou symboliques des écrans ou des étapes.

- les maquettes (mockups) créées à partir des wireframes et de la charte graphique : ce sont des versions détaillées des interfaces web statiques avec couleurs, polices, images, etc. 

- Facultatif : 

    - les prototypes : Version interactive (avec clics, transitions, etc.) des mockups pour tester l’expérience utilisateur (UX) avant de coder.

Outils typiques utilisés pour cette étape de maquettage : Figma, Adobe XD, Sketch...

## Développement

Ouf, une bonne partie du travail a été faite !

Une fois les maquettes réalisées vous allez :

- développer les interfaces statiques (HTML/CSS)

- puis les rendre dynamiques côté client (frontend : vanilla JS, interactivité, etc.)

Plus tard, on peut imaginer un ajout de fonctionnalités côté serveur (backend : bases de données, NodeJS, etc.), une phase de tests, une intégration (assemblage frontend et backend) suivie d'une containérisation (le fait d'emballer tout ce dont l'application a besoin : code, dépendances, système, etc. dans un container isolé, portable et reproductible), puis un déploiement sur le web...

## Instructions

Ca fait beaucoup d'infos d'un coup, on va simplement réfléchir à notre projet, ce qu'on aimerait mettre en place comme fonctionnalités, pourquoi on le ferait, qui est-ce qu'on ciblerait avec ce site...

## Definition of Done

- [ ] J'ai lu l'entièreté de ce ticket, l'ai compris, et m'apprête à me lancer dans le prochain !
- [ ] J'ai une idée de mon projet et de ce qu'il va proposer.

### Le mot de la fin
C'est le début du projet, c'est grisant, ça peut faire peur, mais la suite des tickets vont vous aider à progresser pas à pas !