# Cahier des charges

Imaginez-vous en train de construire une maison. Avant de poser la première pierre, vous avez besoin d'un plan détaillé qui guide chaque étape de la construction. De la même manière, dans le monde du développement de projets, un cahier des charges joue le rôle crucial de ce plan détaillé.

## Objectif

Rappel du plan du Cahier des Charges : 

```
1. Enjeux
    1.1. Besoins
    1.2. Objectifs

2. Fonctionnalités du projet

3. Personnes cibles
    3.1. Cible principale 
    3.2. Cible secondaire 
    3.3. Cœur de cible
    3.4. Personas

4. User stories

5. Contraintes techniques et fonctionnelles

6. Accessibilité

7. Autres facultatifs (analyse concurrentielle, contexte métier)
```

1. **Enjeux - Définition du Projet :** Tout commence par une vision. Le cahier des charges définit clairement le but, les objectifs, les besoins et les attentes du projet. C'est le point de départ qui donne une direction claire à toute l'équipe.

2. **Fonctionnalités du projet - Portée et Périmètre :** Le cahier des charges délimite la portée du projet en détaillant ce qui est inclus (et ce qui ne l'est pas). Cela évite les malentendus et les débordements qui pourraient compromettre le budget et les délais. Pour ce faire, il va falloir être sage et définir deux types de fonctionnalités : les `must-have` et les `nice-to-have`.

    > Les `must-have` sont les fonctionnalités principales qui apparaîtront sur le projet final terminé dans les temps.

    > Les `nice-to-have` sont des fonctionnalités optionnelles qui pourront être ajoutées **si on a le temps** et **si leur installation ne nécessite pas une refonte totale des fichiers html/css/js** ! Généralement, ce seront des options que vous garderez dans le coin de votre tête et qui pourront être ajoutées après la soutenance de votre certification (mais dont vous pourrez vous targuer d'y avoir pensé avant !).

3. **Personnes cibles - Qui va utiliser votre produit :** Il est important de définir quelle catégories (socio-professionnelle, genre, tranche d'âge, etc.) va venir le plus souvent sur notre site ; cela va engendrer des prises de décisions sur l'aspect fonctionel du site mais aussi visuel (plus d'accessibilité pour des personnes âgées, plus de couleurs vives pour de jeunes adultes, etc.). On différencie plusieurs publics : 
    - les cibles principales : c'est le groupe de personnes prioritairement visé par le site web. Ce sont les utilisateurs principaux, ceux pour qui le site est d'abord conçu, car ils ont le plus grand intérêt pour le service/produit ou génèrent le plus de valeur pour l'organisation.
    - les cibles secondaires : c'est un ou plusieurs groupes complémentaires à la cible principale. Ils sont également pris en compte dans la conception, mais ce ne sont pas les utilisateurs prioritaires. 
    - le cœur de cible : il s’agit de la partie la plus spécifique et engagée de la cible principale. C’est le noyau dur, le segment le plus réactif ou le plus rentable. Toute l’expérience utilisateur est souvent pensée en fonction de ce groupe.
    - quant aux personas, ce sont des portraits fictifs mais réalistes d'utilisateurs types de votre projet. Ils permettent de mieux comprendre les attentes, les comportements, les objectifs et les contraintes de vos utilisateurs cibles. En les créant, vous allez pouvoir **adapter votre site à de vraies attentes**, et non à des suppositions vagues. Un bon persona comprend :

        - Un prénom, une tranche d’âge
        - Une profession ou un statut
        - Une situation personnelle (famille, lieu de vie…)
        - Son rapport au numérique (à l’aise ou non, appareil utilisé)
        - Ses besoins, ses motivations
        - Ses difficultés et frustrations face à ses attentes
        - Ses attentes vis-à-vis de votre site, et les solutions à apporter

        > Exemple de persona :
        >
        > **Prénom et âge** : Camille, 32 ans  
        > **Profession** : Responsable communication dans une PME  
        > **Situation** : Travaille souvent à distance, se déplace beaucoup  
        > **Appareils utilisés** : Smartphone et ordinateur portable  
        > **Objectifs** : Trouver rapidement de l’information claire et fiable  
        > **Difficultés** : Sites non adaptés au mobile, navigation confuse  
        > **Solution** : Site rapide, responsive, bien organisé visuellement

4. **User stories - Actions et rôles :** Quels seront les souhaits de chaque personne utilisant votre site web, pourquoi voudront-ils effectuer ces actions, et comment vont-elles y arriver. On définit pour cela les user stories :

    En tant que | Je veux | Afin de
    -- | -- | --
    Visiteur | ... | ...

    >Vous trouverez des exemples de user stories dans le dossier exemples-user-stories (dossier 3.DPROJET-cdc -> exemples-user-stories). Ce ne sont que des exemples, il faudra créer vos propres user-stories selon le contexte de votre projet dans le fichier `user-stories.md`.

5. **Contraintes et Exigences Fonctionnelles et Techniques :** Pour assurer le succès du projet, le cahier des charges spécifie les fonctionnalités attendues et les contraintes techniques à respecter. Cela garantit que le produit final répondra aux besoins de l'utilisateur et aux normes de qualité. Par exemple permettre d'avoir un formulaire de contact implique de recevoir la donnée de l'utilisateur pour ensuite la traiter de manière sécurisée.

6. **Accessibilité spécifique au projet :** L'accessibilité ne se limite pas aux personnes en situation de handicap. Elle concerne **tous les utilisateurs**, dans toutes les conditions d’utilisation : écran petit, forte lumière, navigation rapide, etc. Voici les axes à prendre en compte : 

    - Accessibilité aux handicaps (bonne lisibilité, contraste suffisant, pas de textes trop petits, alt pour les images, etc.)
    - Accessibilité contextuelle selon votre projet (public senior → taille de police, contraste, simplicité de navigation / professionnels en situation de stress (urgence, santé, transport, etc.) → rapidité d’accès à l’information)

7. **Autres (facultatifs) :**

- **Planning et Délais :** Un bon cahier des charges comprend un calendrier réaliste avec des jalons clés et des échéances précises. Cela aide à maintenir le projet sur la bonne voie et à éviter les retards coûteux.

- **Budget et Ressources :** En détaillant les coûts estimés et les ressources nécessaires, le cahier des charges permet une gestion financière efficace du projet. Il aide également à allouer les ressources humaines et matérielles de manière optimale.

- **Responsabilités et Rôles :** Si le projet s'effectue à plusieurs, chaque membre de l'équipe doit savoir ce qui est attendu de lui. Le cahier des charges attribue clairement les responsabilités et définit les rôles de chacun, ce qui favorise une collaboration efficace.

- **Communication et Suivi :** Enfin, le cahier des charges établit un cadre pour la communication et le suivi du projet. Il définit les canaux de communication, les réunions régulières et les rapports d'avancement pour assurer une collaboration transparente et une gestion efficace des risques.

En résumé, un cahier des charges bien élaboré est la pierre angulaire de tout projet réussi. Il aligne les attentes, définit les paramètres et fournit une feuille de route claire pour guider l'équipe vers le succès. En investissant du temps et des ressources dans l'élaboration d'un cahier des charges solide, vous augmentez considérablement les chances de livrer un produit de qualité, dans les délais et le budget impartis.

## Instructions

Complétez chaque sous-partie du Cahier des Charges dans votre fichier texte du dossier de projet.

Servez vous du plan du cahier des charges indiqué plus haut.

Pour chaque sous-partie, **soyez clairs, concrets et réalistes**. Votre projet doit être réalisable dans le temps imparti !

Ne restez pas bloqués trop longtemps sur une section : **avancez et revenez dessus plus tard si besoin**.

Pour les personnes cibles, on demandera de détailler les besoins et problématiques pour les cibles principales, secondaires et le coeur de cible.

Pour les personas, on demandera 3 personas différents pour votre projet

## Definition of Done

- [ ] Le cahier des charges est rédigé.
- [ ] Toutes les sections du plan sont remplies (même de façon simple ou temporaire).
- [ ] Au moins 3 personas sont créés et contextualisés.
- [ ] Les fonctionnalités `must-have` doivent absolument être listées.
- [ ] Les contraintes techniques et fonctionnelles sont réfléchies.
- [ ] Les user-stories ont été complétées dans le fichier `user-stories.md`.
- [ ] L’accessibilité a été pensée selon le public cible.
- [ ] Le document est prêt à être présenté ou corrigé.

### Le mot de la fin

A la fin de cette étape, vous aurez une vision claire de **ce que vous allez construire**, **pour qui**, et **comment**.