# Site de pizzeria avec commande en ligne

### Deux Rôles : Visiteur et Utilisateur connecté

En tant que | Je veux | Afin de
-- | -- | --
Visiteur | Consulter le menu de la pizzeria | Voir les pizzas proposées
Visiteur | Voir les promotions en cours | Profiter des meilleures offres
Visiteur | Accéder à une carte ou aux coordonnées | Localiser la pizzeria
Utilisateur connecté | Me connecter à mon compte | Passer une commande
Utilisateur connecté | Personnaliser ma pizza (pâte, ingrédients, taille) | Commander selon mes goûts
Utilisateur connecté | Ajouter plusieurs produits à mon panier | Faire une commande groupée
Utilisateur connecté | Choisir entre livraison et retrait sur place | Avoir plus de flexibilité
Utilisateur connecté | Suivre le statut de ma commande en temps réel | Savoir quand ma commande sera prête ou livrée
Utilisateur connecté | Consulter l’historique de mes commandes | Recommander facilement
Utilisateur connecté | Enregistrer mes adresses de livraison | Commander plus rapidement
Utilisateur connecté | Recevoir une notification ou un mail de confirmation | Être informé que ma commande est bien prise en compte