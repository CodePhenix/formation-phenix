# Site vitrine pour une galerie d'art

### Un Rôle : Visiteur

En tant que | Je veux | Afin de
-- | -- | --
Visiteur | Pouvoir consulter la page d'accueil | Découvrir la galerie
Visiteur | Voir les expositions en cours et à venir | Planifier une visite
Visiteur | Consulter une page dédiée à chaque artiste | En apprendre davantage sur leur travail
Visiteur | Voir une galerie d'images d'œuvres exposées | Me faire une idée de la collection
Visiteur | Consulter les horaires et l'adresse de la galerie | Organiser ma venue
Visiteur | Accéder à un formulaire de contact | Poser des questions ou prendre rendez-vous
Visiteur | Pouvoir lire les actualités ou événements spéciaux | Être informé des activités de la galerie