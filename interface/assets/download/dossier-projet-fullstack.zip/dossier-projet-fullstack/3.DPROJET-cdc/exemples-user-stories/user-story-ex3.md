# Forum pour passionnés de cuisine

### Trois Rôles : Visiteur, Utilisateur connecté et Administrateur

En tant que | Je veux | Afin de
-- | -- | --
Visiteur | Lire les sujets publics du forum | Découvrir les discussions en cours
Visiteur | Utiliser la fonction recherche | Trouver des recettes ou conseils
Visiteur | Voir les catégories du forum (ex : pâtisserie, cuisine du monde...) | Naviguer facilement
Visiteur | Voir les profils publics des membres | Comprendre leur spécialité
Utilisateur connecté | Créer un compte | Participer aux discussions
Utilisateur connecté | Créer de nouveaux sujets | Poser mes questions ou partager mes recettes
Utilisateur connecté | Répondre à des sujets existants | Aider ou échanger avec d'autres passionnés
Utilisateur connecté | Liker ou remercier un post utile | Valoriser les contributions
Utilisateur connecté | Recevoir des notifications | Être informé quand quelqu’un répond à mes sujets
Utilisateur connecté | Personnaliser mon profil | Montrer mes goûts et compétences
Utilisateur connecté | Signaler un contenu inapproprié | Alerter les admin
Administrateur | Modérer les discussions | Garantir le respect des règles
Administrateur | Supprimer ou éditer des messages inappropriés | Maintenir un espace sain
Administrateur | Bannir ou suspendre un utilisateur | Réagir en cas de comportement abusif
Administrateur | Gérer les catégories du forum | Organiser les discussions
Administrateur | Épingler des sujets importants ou populaires | Les rendre visibles
Administrateur | Consulter les statistiques du forum sur une page admin | Suivre son activité
