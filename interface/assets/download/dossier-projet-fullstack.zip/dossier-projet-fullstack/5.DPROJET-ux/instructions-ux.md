# Expérience Utilisateur (User Experience : UX)

Dans le ticket précédent, nous nous sommes intéressés à l'**interface visuelle**, à l'UI (User Interface ou Interface Utilisateur). Mais une UI ne peut fonctionner sans UX !

L’**UX (User Experience)**, c’est tout ce qui concerne **la manière dont l'utilisateur interagit avec votre site**, ce qu’il ressent, comment il navigue, ce qu’il comprend, ce qu’il attend — bref, **ce qu’il vit**.

> Un site peut être très beau (UI) mais difficile à utiliser (UX ratée)… L’objectif est d’avoir les deux !

## Objectif

Travailler l’UX, c’est anticiper ce que va vivre l’utilisateur lorsqu’il navigue sur votre projet.  
Voici les points essentiels à travailler :

- **Arborescence (et parcours utilisateur)**  
  Dans le parcours utilisateur, on peut définir des user-journeys, qui sont des représentations étape par étape de ce que fait un utilisateur pour atteindre un objectif sur un site ou une application. Ils vont décrire ses actions, ses besoins et parfois ses émotions à chaque étape. **Rassurez-vous**, nous n'allons pas créer ici de user-journeys, mais simplement réfléchir à tout le parcours sur votre projet d'un utilisateur pour atteindre son but ; combien de pages doit-il visiter avant d'atteindre son but depuis la page d'accueil, les informations sont elles facilement compréhensibles pour aller d'un point A à un point B, etc. Posez-vous la question : *Mon utilisateur trouve-t-il ce qu’il cherche facilement ?* Si ce n'est pas le cas, il faut repenser chacune des actions possibles effectuables par l'utilisateur (user stories), redéfinir leurs liens sur le site, et modifier leur accessibilté pour qu'elles soient plus facilement exécutables : cela va définir votre **arborescence**. Le user journey est une manière détaillée et scénarisée de décrire un parcours, alors que l’arborescence est plus une carte des pages.

  L’**arborescence d’un site web**, c'est la structure hiérarchique de toutes ses pages, comme un plan ou un organigramme. Elle montre : les pages principales (Accueil, Contact, À propos…), les pages secondaires (ex : Nos services (page principale) → Développement web, Graphisme (page secondaire)…), et surtout **comment les pages sont reliées entre elles**.
  
  En comprenant les priorités de l’utilisateur, vous allez pouvoir identifier les pages réellement nécessaires, organiser les contenus et les liens selon les besoins réels (et non selon une logique interne), et réduire le nombre d'étapes pour atteindre un objectif (meilleure UX).

  >Un exemple d'arborescence pour un site de refuge chien et chat est disponible dans le dossier 5.DPROJET-ux -> exemples-arborescence, sous trois formes (map, matrix, outline), choisissez celle que vous préférez pour votre site.

- **User Flows :** 
  Ce sont des schémas qui représentent les étapes concrètes que suit un utilisateur sur un site pour accomplir une action précise (s’inscrire, acheter, envoyer un message, etc.). Jusque là, nous avions imaginé le parcours d'un utilisateur dans un scénario précis pour nous aider à concevoir l'arborescence du site. Maintenant, il va falloir cartographier les **liens entre toutes les pages** et les **actions possibles** (cliquer sur un bouton affiche un texte, remplir un formulaire me renvoie vers la page d'accueil, etc…). Avec des blocs, des flèches, on va symboliser toutes les actions réalisables pour afficher/cacher des éléments, enregistrer l'utilisateur, l'emmener vers une autre page (d'où l'importance de l'arborescence pensée en amont), etc. Cela nous servira à visualiser les parcours d’action possibles, à simplifier les étapes inutiles ou complexes, à améliorer l’expérience utilisateur en rendant les objectifs faciles à atteindre, et en guidant les utilisateurs le plus directement possible vers leur objectif. Avant le maquettage réel, on commence par cela pour comprendre si nos éléments vont bien se succéder.

  >Un exemple de user-flow pour le même site de refuge chien et chat est disponible dans le dossier 5.DPROJET-ux.


- **Zoning**  
  Planifier l’agencement des principaux blocs de contenu sur chaque page : où sont les menus principaux, le header, la nav, la sidebar si il y en a, le footer, les grosses images, etc. C'est la dernière étape avant le maquettage (ou la première du maquettage, cela dépend comment on le voit), qui prend ses sources dans une bonne UX bien pensée pour le projet.

- **Écoconception**  
  Penser performance et légèreté :
  - Réduire les clics inutiles
  - Design épuré (pas trop d’animations)
  - Contenu optimisé (images compressées, peu de polices, JS/CSS factorisé)
  - Moins de fichiers = chargement plus rapide = utilisateur content + planète soulagée

- **Sécurité et accessibilité**
  - Protéger son site (contenu, données, pas de console.log en JS qui pourraient faire fuiter des informations...)
  - Penser aux **utilisateurs en situation de handicap** : navigation clavier, contraste suffisant, lisibilité...

- **Respect de la législation**
  - En France, le **RGAA** (Référentiel Général d'Amélioration de l'Accessibilité) fixe des normes pour rendre les sites accessibles à tous.
  - Même pour un site perso, il est important de respecter un **minimum d’accessibilité**.

## Instructions

Complétez chaque sous-partie de l'UX dans votre fichier texte du dossier de projet.

Travaillez les éléments suivants :
   - Définissez votre arborescence de navigation (au choix : texte explicatif, carte ou schéma simple)
   - Construisez des User Flows de votre projet ; ce peut être fait au crayon, avec des blocs et des flèches (un carré pour une action, un cercle pour une page, un losange pour un formulaire menant vers différents embranchements, etc.)
   - Réalisez un zoning pour vos principales pages (au crayon, en noir et blanc), en mobile et desktop
   - Notez vos réflexions sur l’écoconception, la sécurité et l’accessibilité
   - Justifiez vos choix en fonction **de votre projet et de votre public cible**

## Cours associés et Outils

Se rendre sur https://codephenix.com -> Connaissances -> UX

## Definition of Done

- [ ] Avoir réfléchi à l'expérience utilisateur spécifique pour mon projet et mon public cible (en particulier le coeur de cible).
- [ ] L'avoir défini dans mon fichier texte pour garantir la meilleure des expériences à mes utilisateurs, tout en restant en adéquation avec le thème, l'idée de mon projet.
- [ ] Avoir dessiné un **zoning** pour au moins une page de son projet, en version mobile et desktop pour chaque.
- [ ] Avoir imaginé et dessiné ou expliqué l'**arborescence** de son projet.
- [ ] Avoir imaginé chaque situation qu'un utilisateur pourrait avoir en venant sur son site.
- [ ] Avoir dessiné au moins un **User Flow** de son projet.
- [ ] Pouvoir expliquer pourquoi j’ai fait ces choix pour améliorer l’expérience sur mon site.

### Le mot de la fin

Vous ne construisez pas un site seulement pour vous, mais **pour les gens qui vont l’utiliser**.  
Penser UX, c’est penser *comme eux*, et leur offrir un site **fluide, logique, agréable, rapide et accessible**. Courage dans cette tâche !