# Gestion de Projet

Petit ticket aujourd'hui, mais non des moindres ! Imaginez que vous partez en expédition pour construire votre propre site web. Comme tout bon explorateur, vous aurez besoin d’un **plan de route**, de **matériel adapté**, d’un **objectif clair** et d’une **organisation solide**. C’est exactement ce que propose la gestion de projet : vous permettre de ne pas vous perdre en chemin, de garder le cap, et de savoir **quoi faire, quand, comment et avec quoi**.

## Objectif

1. **Organiser son travail de manière efficace :**  
   Avoir une bonne organisation est essentiel pour aller au bout de son projet personnel, surtout quand on alterne entre des phases de développement, des cours, des exercices et des reproductions de maquettes.

2. **Maîtriser son environnement de développement :**  
   Connaître et bien utiliser ses outils (éditeurs de code, structure de dossier, GitLab local) est une base solide pour travailler efficacement.

3. **Comprendre l’environnement technique du projet :**  
   Utiliser les bons langages, formats de fichiers, et outils adaptés à un site web : HTML, CSS, JavaScript, fichiers images, etc.

## Organisation du Travail

Avant de coder, on **structure**.

Voici le déroulé typique d’une bonne organisation de projet :
- Création du Dossier de Conception : si vous l'avez déjà fait, vous avez une bonne base pour la suite (si vous ne l'avez pas commencé, je le répète ici, prenez le temps pour tous les documents de conception, si c'est bancal ou que vous ne savez pas où allez, la phase de dev se passera forcément moins bien), il contient donc le cahier des charges (public cible, personas, user stories, fonctionnalités du projet, etc.), et la refléxion sur l'UX/UI (arborescence, user flows).
- Les zoning, wireframes et maquettes finales : là aussi, prenez-le temps, vous n'allez pas vous lancer dans le CSS sans avoir réfléchi à l'emplacement des blocs ou à la différence des media queries entre deskop et mobile.
- Le code source (HTML/CSS/JS) : la phase de développement, celle dont on pense en premier lieu, qui peut prendre plusieurs semaines mais être rapide si elle a été bien pensée en amont.
- L'ajout des ressources (images, polices, etc.) : cela sera fait au fur et à mesure de l'avancée du projet si besoin, mais normalement, les ressources auront été définies dans la phase de conception.

### Planification

Vous n’avez pas besoin de faire de véritables **sprints** comme dans la méthodologie de travail *Agile*, mais il est essentiel de :
- **Lister vos tâches principales.** (ce qui selon vous va prendre le plus de temps, là où vous êtes moins à l'aise)
- Vous fixer des **objectifs réalistes pour chaque session** de travail.
- Suivre votre avancement (avec une todo-list, par exemple).

### Organisation dans le temps

Les premières phases du projet se font **en parallèle des cours et exercices**. Vous pouvez bien sûr ajuster selon vos besoins ; à partir de la phase de dev, davantage de temps sera alloué au projet.

## Technologies Utilisées

### Environnement de Développement

- Vous allez utiliser **VS Code** ou **Sublime Text** comme éditeur, mais aussi parfois certains logiciels d'édition d'images, de schémas, etc. : précisez-le !

- Le projet est hébergé **localement**, dans un dossier bien structuré.
- Vous utilisez **GitLab en local** pour :
  - Sauvegarder les versions.
  - Organiser vos commits.
  - Lire les tickets et remplir les checklist.
  - Travailler proprement, comme en entreprise.

### Environnement Technique

Le code est organisé dans des fichiers : on parle de l'arborescence de votre projet : 

Vous pouvez déjà commencer à construire votre futur projet, en l'ordonnant dans vos dossiers :
- un dossier principal, qui prendra le nom de votre projet (ou 'app', 'code', 'website', 'projet'...), qui contiendra :
  - un dossier `components`
  - un dossier `assets`, qui contiendra :
    - un dossier `css`, qui contiendra lui même :
      - un dossier `pages`
    - un dossier `js`
    - un dossier `images`, qui contiendra :
      - un dossier `icons`
    - un dossier `fonts`

## Instructions

Complétez chaque sous-partie de la Gestion de Projet dans votre fichier texte du dossier de projet.

1. **Préparez votre partie 'Gestion de projet'** avec toute votre structure (explication de l'organisation de travail, des technologies utilisées).

2. **Identifiez vos objectifs** : quelles pages coder ? Quelles fonctionnalités vont prendre du temps ?

3. **Tenez un suivi de vos tâches** (feuille, carnet, fichier de traitement de texte, peu importe tant que c’est clair pour vous ; si vous le voulez, vous avez un fichier intitulé `logbook.md` dans le dossier 7.DPROJET-gestion-projet qui pourra contenir votre journal de bord) : pour l'instant, définissez vos objectifs dans la colonne 'Objectifs', pour chaque semaine.

## Definition of Done

- [ ] Avoir défini ses objectifs de travail.
- [ ] Être capable d’expliquer comment vous vous organisez entre projet, cours et exercices.
- [ ] Être capable d’expliquer les outils techniques que vous utilisez et pourquoi.
- [ ] Avoir préparé son journal de bord.

### Le mot de la fin

Un bon projet commence par une bonne **organisation**. Prenez le temps de structurer, de planifier, de comprendre vos outils, et tout se passera bien !