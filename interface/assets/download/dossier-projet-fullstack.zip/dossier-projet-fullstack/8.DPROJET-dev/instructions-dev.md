# Développement

On a toutes les cartes en main pour notre projet, alors on prend le temps de bien s'organiser !

## Objectif

**Suivre le planning qu'on s'est fixé, avancer sur le développement des pages, et suivre un petit journal de bord qu'on pourra remplir à la fin de chaque semaine**

## Instructions

Vous allez créer un dossier 'app', 'code', 'website', 'projet', '*nom_du_projet*' (comme vous voulez !) dans le dossier 8.DPROJET-dev, qui contiendra tous vos fichiers, images, favicon, etc. Mais il va falloir l'ordonner ce dossier : on parle ici de l'arborescence de votre projet (attention, c'est différent de l'arborescence de votre site, qui lui va lister les pages) dont on a commencé à parler dans le ticket précédent. Dans ce dossier *`nom_du_projet`*, vous allez donc inclure dans la partie front :
  - un fichier README.md (fichier markdown qui sera du texte) : pour présenter rapidement votre projet, le contexte et les fonctionnalités, et donner les instructions d'utilisation/lancement de votre projet (ça, c'est pour les prochains développeurs qui vont récupérer votre code !).
  - un fichier html par page (pour chaque page du site, il faudra un fichier html), avec votre page d'accueil qui s'appellera `index.html`, et les autres `contact.html` ou `menu.html`
  - un dossier `components` qui contiendra lui même :
    - un fichier `header.html`.
    - un fichier `footer.html`.
  - un dossier `js`, qui contiendra lui même :
    - un fichier `js` par page ou par fonctionnalité, avec par exemple `main.js` pour gérer le fetch des header et footer, et les autres `form.js` ou `menu.js` si vous allez gérer l'affichage de votre carte avec un tableau d'objets.
  - un dossier `assets`, qui contiendra :
    - un dossier `css`, qui contiendra lui même :
      - un fichier `base.css` qui pourra gérer le css principal de toutes les pages (reset, variables root, polices, typographies, etc.).
      - un fichier `components.css` qui pourra gérer le css de votre header et de votre footer.
      - un dossier `pages`, qui contiendra :
        - un fichier css par page (pour chaque page du site, il faudra un fichier css), avec votre page d'accueil qui s'appellera par exemple `home.css`, et les autres `contact.css` ou `menu.css`.
    - un dossier `images`, qui contiendra :
      - un dossier `icons` (avec dedans une favicon, ainsi que le dossier `icomoon` (codePhenix → Outils) si vous comptiez utiliser des icons)
      - chacun des photos que vous souhaitez utiliser pour votre site (si besoin est, ajouter des dossiers ici pour les trier par page, par exemple `img-products` ou `img-drawings`)
    - un dossier `fonts` qui contiendra toutes les polices que vous souhaitez ajouter à vos pages.

Pour la partie back, voir avec votre formateur comment organiser son architecture.

Vos objectifs ont été définis, vos fonctionnalités détaillées, et vos wireframes dessinés : vous allez pouvoir développer votre projet bien plus facilement grâce à ça maintenant !

Vous vous souvenez du fichier `logbook.md` de suivi de gestion de projet détaillé dans le ticket précédent ? Vous allez pouvoir le remplir à la fin de chaque semaine, en détaillant ce que vous avez fait, si vous avez rempli les objectifs de la semaine, où vous avez eu des difficultés, si vous avez pris de l'avance, etc.

## Definition of Done

- [ ] Le code est fonctionnel, sans erreur dans les logs de la console, correspond aux attentes fixées par le cahier des charges, et visuellement similaire aux attendus des maquettes.
- [ ] Le journal de bord (dans le dossier 7.DPROJET-gestion-projet) est complété chaque fin de semaine.

## Code quality:

- [ ] HTML: 0 erreurs/warnings selon les standards du W3C
- [ ] HTML: Les textes visibles ne comportent pas de fautes d'orthographe
- [ ] HTML: Les textes visibles commencent tous par une majuscule
- [ ] HTML: La langue du document est renseignée
- [ ] HTML - SEO: title, description et favicon ont été renseignés
- [ ] HTML - SEO: Si c'est pertinent, les balises sémantiques <header>, <footer>, <main>, <nav>, <section> ont été utilisées
- [ ] CSS: Aucun padding ni margin négatif sauf exception dûment documentée
- [ ] CSS: Aucun padding ni margin supérieur à 50px sauf exception dûment documentée
- [ ] CSS: Le css comporte un "reset CSS" (cf plus bas)
- [ ] CSS: Tous les élements cliquables (liens, boutons, autres) ont un cursor de type pointer
- [ ] CSS: Les `class`, `id` et autres attributs ont des noms respectables et porteurs de sens (pas de `aa` ou `toto` ou `texte2`)
- [ ] JS: Le code est commenté
- [ ] JS: Pas d'erreur ni de logs inutiles dans la console
- [ ] JS: Les variables ont des noms respectables et porteurs de sens

## Code quality ++ (Bonus)

- [ ] HTML - SEO: Description et preview image pour Facebook, Linkedin et Twitter sont renseignées
- [ ] CSS: Les couleurs principales du site sont renseignées dans des variables CSS (ex: `color: var(--main-blue)`)
- [ ] CSS: Les noms de `class` et `id` sont en "kebab-case" c'est à dire avec des tirets. Bon ex: "btn-submit", mauvais ex: "btnSubmit" ou "btn_submit"
- [ ] JS: Les noms de variables sont en "camelCase" c'est à dire avec des majuscules. Bon ex: "btnSubmit", mauvais ex : "btn_submit"

NB: Reset CSS de Codephenix (à mettre dans le fichier base.css)

```css
* {
  margin: 0px;
  padding: 0px;
  box-sizing: border-box;
}

a {
  text-decoration: none;
  color: inherit;
}

li {
  list-style-type: none;
}
```

### Le mot de la fin

C'est le moment tant attendu, celui on on peut enfin coder ! Profitez-en !