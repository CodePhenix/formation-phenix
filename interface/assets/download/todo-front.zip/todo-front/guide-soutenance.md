# Guide des bonnes pratiques à l'usage des candidats de la CCP1 du DWWM

## Conseils avant la soutenance
### Les jours qui précédent
- Pas de dinguerie ! On se repose, on essaie de se coucher tôt les soirs.
- Rélire le Guide Mémo : {{ codephenix_url }}/cours/supports/guide-memo.pdf
- Choisir et avoir mis une fois la tenue du jour J.
- S'entrainer à faire sa présentation.

### La veille
- On ne touche plus rien au code !!!
- Mettre le mode clair sur VSCode.
- Vérifier que LibreOffice fonctionne (Writer et Impress), pareil pour VSCode.
- Vérifier que son projet et sa présentation powerpoint soient bien accessible.
- Se coucher tôt.

### Le jour de la soutenance
- Le matin : pas trop de café.
- Etat d'esprit : vous vous présentez en tant que professionnel du métier : vous avez géré un projet web frontend de A à Z. Vous allez parler à des professionnels développeurs, vous allez parler d'égal à égal.
- Pas de "Je suis désolé" à tout bout de champ.
- Pas de "je pense que" si vous savez, dites le franchement. Si vous ne le savez pas, dites le aussi. Si vous n'êtes pas sûr, proposez quelque chose, les examinateurs vont sûrement vous aiguiller vers la réponse si ils sentent que vous pouvez l'avoir. Ils ne sont pas là pour vous piéger.
- Prévoir un gobelet d'eau pour l'oral.

## Présentation projet (20 min) :
Voici quelques bonne pratiques à adopter :

- Evitez de lire ou paraphraser votre dossier de projet pendant la soutenance, les examinateurs l'ont lu, votre présentation sera un condensé de ce que vous avez écrit dans le dossier de projet.
- La présentation du rapport doit être axée sur le vécu (historique de la période de projet en fin de formation ; comment vous vous êtes organisés).
- Détailler l'expression des besoins (public cible visé par le projet web par exemple), les spécifications fonctionnelles et techniques (devoir faire un formulaire pour enregistrer les futurs clients par exemple), les outils utilisés (VSCode, Gitlab), la phase de conception/modélisation (zoning et wireframes), l'implémentation, les tests sur plusieurs navigateurs...
- Prendre le soin de parler des difficultés rencontrées et des solutions apportées.
- Prise de recul en conclusion : autocritique, améliorations possibles.
- Penser à écrire une trame de la présentation à l'oral que vous allez raconter : numéroter vos slides de présentations dans le powerpoint et indiquer sur votre texte de présentation à quelle slide vous allez dire telle ou telle partie, cela permet de s'y retrouver.
- Mettre les captures de codes dans votre présentation en thème light.

## Entretien technique (30 min) :
Vous n'aurez jamais de questions pièges pendant l'entretien mais des questions simples, essentiellement théoriques, qui porte directement sur le référentiel (REAC). 9 fois sur 10 il s'agit simplement de répondre à des demandes de :

- Définitions
- Rôles
- Exemples (outils, implémentations ...)
- etc ...

*Ex. Qu'est ce que "XXX" ? Connaissez-vous quelques exemples de "YYY" ? A quoi sert "ZZZ" ?*

On attend des réponses simples et rapides :
    * Mieux vaut dire que vous ne savez pas que de répondre au hasard,
    * Demander au jury de reformuler la question si vous n'êtes pas sûrs de la comprendre (sans leur faire répéter trois fois...),
    * Soyez technique dans vos réponses (vous n'êtes plus un débutant : pas de 'je clique sur le machin').

Il faut rester sobre en matière de langage :
    * Pas d'excès de zèle dans le langage employé,
    * Éviter d'essayer de *flatter* les jurés.

Ayez si possible une tenue correcte (conseillée : *une tenue dans laquelle vous êtes confortable tout en faisant professionnel, pas la peine de venir en costard*).

C'est généralement à la fin de l'entretien que les jurés vérifient que vous connaissez bien le métier dans lequel vous vous engagez et vous questionnent sur votre vision de votre avenir professionnel dans le métier. Cet échange final ne contient pas de questions techniques.
