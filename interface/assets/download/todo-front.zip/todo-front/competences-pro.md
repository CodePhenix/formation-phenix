# Critères d'évaluation des Compétences Professionnelles

## CP 1 : Installer et configurer son environnement de travail en fonction du projet web ou web mobile

Les outils de développement nécessaires sont installés et configurés (exemple : IDE = Visual Studio Code avec extension installée grâce au terminal, à partir d'un fichier vsix).

Les outils de gestion des versions et de collaboration sont installés (exemple : utilisation des commandes Git et de la plateforme GitLab).

La documentation technique de l'environnement de travail est comprise, en langue française ou anglaise (utilisation de DevDocs et de StackOverflow en anglais, avec parfois l'utilisation de LibreTranslate).

## CP 2 : Maquetter des interfaces utilisateur web ou web mobile

Les maquettes sont réalisées conformément au dossier de conception (zoning, wireframes, mockups = maquettes).

La charte graphique de l'entreprise / du projet est respectée (palette de couleurs, typographies).

Les exigences de sécurisation sont respectées (vérifier le type de données que l'on reçoit dans les `<inpu>` d'un formulaire).

Les maquettes tiennent compte de l'expérience utilisateur, y compris pour les personnes en situation de handicap et du type d'utilisation, y compris pour les équipements mobiles (avoir du responsive qui permet une lisibilité pour tous : attributs `alt` dans les `<img>`, attributs ARIA, contraste de couleurs correct).

L'enchainement des maquettes est formalisé par un schéma (arborescence, user flow).

La législation en vigueur est respectée, y compris celle relative à l'accessibilité (obligation d'ajouter les attributs `alt` pour les balises `<img>`, attention à la succession des titres).

## CP 3 : Réaliser des interfaces utilisateur statiques web ou web mobile

L'interface est conforme à la maquette et les besoins en éco-conception sont pris en compte (pas trop de couleurs ni d'animations trop lourdes).

L'interface tient compte de l'expérience utilisateur, y compris pour les personnes en situation de handicap (avoir un 'parcours utilisateur' logique).

L'interface respecte les recommandations de sécurité liées aux applications web ou web mobile (empêcher les utilisateurs d'inscrire du code HTML dans les commentaires, les messages et les entrées de formulaires).

L'interface s'adapte au type d'utilisation de l‘application, et notamment à la taille, au type et à la disposition du support, y compris pour les équipements mobiles (design responsive avec media queries pour desktop/mobile, généralement conception en mobile-first).

La règlementation en vigueur est respectée, y compris celle relative à l'accessibilité (navigation clavier pour les carousels, contrastes respectés).

Le site est visible sur les moteurs de recherche et le référencement dépend du public (pour plus tard, penser à utiliser le protocole HTTPS que HTTP si il y a une gestion de données utilisateurs sensibles + SEO adapté pour le type de public cible avec balises HTML `<title>` et `<meta description>` optimisées).

## CP 4 : Développer la partie dynamique des interfaces utilisateur web ou web mobile

L'interface utilisateur est conforme au dossier de conception.

L'interface est dynamique et l'expérience utilisateur est améliorée, y compris pour les personnes en situation de handicap (utilisation de composants interactifs (modales), animations légères).

Les recommandations de sécurité liées aux applications web et web mobile sont respectées (validation des inputs côté frontend).

La règlementation en vigueur sont respectées, y compris celle relative à l'accessibilité (avoir pensé à la gestion des données personnelles et des cookies).

Le code est documenté, en anglais si nécessaire.