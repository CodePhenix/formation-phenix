# TODO Soutenance
## Administratif:
- [ ] Compléter les informations administratives du Dossier Professionnel (Pages 1/2 et page 'Diplômes')
- [ ] Faire le maquettage (zonings, wireframes, maquettes, prototypes, arborescence, user flows...)
- [ ] Compléter Dossier Professionnel 
- [ ] Compléter Dossier projet
- [ ] Coder le projet en entier (commenté et propre)
- [ ] Compléter résumé du projet
- [ ] Compléter Présentation avec slides du projet

## Préparation soutenance
- [ ] Réviser les questions de cours
- [ ] Relire ses exos (CV, Analytics, MyFood, formulaire)
- [ ] Lire le Guide Mémo avec les définitions : {{ codephenix_url }}/cours/supports/guide-memo.pdf
- [ ] Avoir préparé un petit plan écrit pour la soutenance (bullet points, grands titres) avec le numéro des slides approprié
- [ ] Le SEO du projet a été optimisé sur CHAQUE page (title, description…)
- [ ] Le code est commenté PAR VOUS
- [ ] Le nom des classes/des ids et des constantes/variables est logique et porteur de sens
- [ ] Vos tickets gitlab/github sont bien remplis et rangés
- [ ] L'arborescence de votre ordinateur est logique et rapide à comprendre (vos dossiers et fichiers doivent être RANGES)
- [ ] S'entrainer à faire sa présentation
- [ ] Choisir et avoir mis une fois la tenue du jour J
