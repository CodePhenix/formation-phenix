# Dossier Professionnel

Aujourd'hui, que faire ? Tout simplement commencer le **Dossier Professionnel**.

## Instructions

Il vous suffit de copier le fichier de la trame du dossier professionnel et de le coller dans le dossier 3.DP-final, l'ouvrir, et de le remplir à l'aide de votre fichier d'**exemples d'activités professionnelles** (eap.md du dossier 2.DP-eap) : vous allez renseigner pour chaque exemple le nom de l'exercice/projet, les opérations effectuées, les moyens utilisés, avec qui vous avez travaillé et le contexte.

1. Soyez précis et concis, pas besoin d'écrire trois pages sur chaque exemple mais vous devez expliquer en quoi votre exemple couvre la CP et votre bonne compréhension de la CP, donc évitez d'écrire seulement : **"Dans cet exercice, j'ai fait des maquettes."**, ce ne sera PAS suffisant.

2. Montrez ce que vous expliquez ! Vous parlez de code, montrez des extraits, vous parlez de wireframes, de users stories, ou quoi que ce soit d'autre, ajoutez-le ! Dans les annexes ou directement dans le corps de l'exemple, c'est vous qui voyez, mais ajoutez tout ça !

3. Mettez des captures de code (Sublime ou VSCode) en thème light ! C'est une demande des jurys, ils en ont marre de se casser les yeux sur du thème dark...

4. **Rappel :**
- Au minimum 4 exemples, au maximum 12 exemples
- Un exemple peut couvrir plusieurs CP
- Ne pas mettre des exemples venant du projet personnel
- Toutes les CP doivent être couvertes par au moins un exemple (3 au maximum)

5. Une fois tous les exemples renseignés, complétez le sommaire, et la page 'Déclaration sur l'honneur' (à la fin).

6. Une fois terminé, votre fichier devra être exporté en PDF (Fichier > Télécharger > Document PDF). Prenez bien soin de le nommer **exactement** `votrenom-dossier-professionnel.pdf` : pas d'espace, pas de majuscule, `pdf` en minuscule, etc.

**Pour vous aider dans cette tâche, n'hésitez pas à demander à votre formateur ou à des collègues de consulter des DP des précédentes promotions.**

## Definition of Done

- [ ] La première page a été remplie.
- [ ] Le sommaire avec le numéro des pages a été complété.
- [ ] L'activité-type a été complétée pour chaque exemple.
- [ ] Le nom de l'exercice/projet a été renseigné.
- [ ] Pas de fautes d'orthographe (se faire relire par un tiers ou utiliser un correcteur automatique).
- [ ] Toutes les phrases comportent une majuscule et un point.
- [ ] Des wireframes et extraits des users stories et du cahier des charges pour la CP 2 ont été insérés.
- [ ] Des captures d'écran des rendus de l'application/page/site sur les différents type de média pour la CP 3 ont été ajoutées.
- [ ] Des extraits de code significatifs pour couvrir la compétences pour les CP 3 et 4 ont été ajoutés.
- [ ] Chaque extrait de code possède des explications.
- [ ] Tous les extraits de code sont en thème light.
- [ ] Les pages sont numérotées.
- [ ] L'attestation sur l'honneur a été remplie.

Toutes les Compétences Professionnelles ont au moins un exemple qui permettent de prouver qu'elles sont acquises :
- [ ] CP 1 : Installer et configurer son environnement de travail en fonction du projet web ou web mobile
- [ ] CP 2 : Maquetter des interfaces utilisateur web ou web mobile
- [ ] CP 3 : Réaliser des interfaces utilisateur statiques web ou web mobile
- [ ] CP 4 : Développer la partie dynamique des interfaces utilisateur web ou web mobile

### Le mot de la fin

Dernière ligne droite, courage, et bravo.