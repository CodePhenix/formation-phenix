# Le Dossier Professionnel

A l'issue de la formation, vous allez donc devoir présenter un Dossier Professionnel à votre jury pour passer la certification du Titre Professionnel de Développeur Web et Web Mobile.

## Objecifs du Dossier Professionnel

C'est un document officiel et obligatoire qui décrit vos expériences dans le domaine.

Ses fonctions sont multiples :
- Il vous prépare à l'entretien avec le jury, et facilite la prise de parole,
- Il sert au jury pour mieux vous connaître,
- Il servira comme CV détaillé pour une recherche d'emploi,
- Il documente vos projets.

Ce dossier a pour but de montrer comment vous avez travaillé et acquis les différentes compétences professionnelles requises pour le Certificat de Compétences Professionnelles 1 (frontend) du titre DWWM au travers d'exemples de projets que vous présenterez. Vous pouvez le voir comme une forme de livre de bord qui vous accompagnera pendant les prochains mois et auquel vous reviendrez régulièrement pour y ajouter vos nouvelles avancées.

Le Dossier Professionnel est à rédiger tout au long de la formation. Les exemples intégrés doivent être conservés.

Il s'écrit au **présent**.

## Présenter son travail

Présenter son travail est avant tout un exercice de reformulation d'un travail qui a déjà été fait. C'est aussi un travail de présentation, le front-end de vos dossiers est important, il faut que ce soit illustré et agréable à lire.

Présenter son travail à plusieurs objectifs :
- Documenter des exercices réalisés,
- Montrer ses compétences (acquises et/ou maîtrisées),
- Permettre au lecteur de comprendre le travail effectué (comme un tutoriel).

Pour cela, il faut d'abord donner un aperçu global des exercices, expliquer en quelques phrases les consignes et attendus, puis les solutions mises en oeuvre dans son code.

Le titre des exemples doit être explicite et indiquer si dans son ensemble l'exemple est un site / une page web / des fonctions javascript. Par exemple :
- Design Sprint : refonte du site 'Les fourmis solidaires',
- Réalisation d'un portfolio et publication sur Gitlab,
- Codage d'une galerie d'images en JS.

## Instructions
Pour cette première tache, l'objectif est multiple :

- vous familiariser avec le document du Dossier Professionnel en le lisant une première fois (dossier 1.DP-presentation -> documents -> Dossier Professionnel (trame)),
- compléter la première page (Titre professionnel visé, Nom, Prénom, Adresse, Modalité d'accès) avec vos informations personnelles,
- compléter la page 'Titres, diplômes, CQP, attestations de formation' (à la fin),
- parcourir le document REAC présentant les Compétences Professionnelles nécessaires pour l'obtention de la certification (dossier 1.DP-presentation -> documents -> REAC_DWWM),
- pour y voir plus clair et comprendre l'intérêt et l'enjeu du DP, lire le fichier support (dossier 1.DP-presentation -> support.md).

**Les compétences professionnelles requises concernent le CCP1, c'est à dire l'Activité 'Développer la partie front-end d'une application web ou web mobile sécurisée'.**

### Le mot de la fin
C'est un bon début, courage, ça va le faire !