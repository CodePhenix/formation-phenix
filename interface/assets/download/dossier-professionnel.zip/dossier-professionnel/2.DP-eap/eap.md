# Synthèse
- Au minimum 4 exemples, au maximum 12 exemples
- Un exemple peut couvrir plusieurs CP
- Ne pas mettre des exemples venant du projet personnel
- Toutes les CP doivent être couvertes par au moins un exemple (3 au maximum)

## Activité Type 1 - Développer la partie front-end d'une application web ou web mobile sécurisée

*les balise `<br>` servent à aller à la ligne, même dans les fichiers markdown, servez-vous en pour afficher un tableau propre en preview.*

N° de la Compétence professionnelle | Nom de l'exercice, projets ou autre | Expliquez votre choix
-- | -- | --
CP 1 - Installer et configurer son environnement de travail en fonction du projet web ou web mobile | - _nom de l'exo_ <br> - _nom de l'exo_ | - ... <br> - ... |
CP 2 - Maquetter des interfaces utilisateur web ou web mobile | _nom du projet perso_ | ... |
CP 3 - Réaliser des interfaces utilisateur statiques web ou web mobile | - _nom de l'exo_<br> - _nom de l'exo_ <br> - _nom de l'exo_ | - ... <br> - ... <br> - ... |
CP 4 - Développer la partie dynamique des interfaces utilisateur web ou web mobile | - _nom de l'exo_<br> - _nom de l'exo_ <br> - _nom de l'exo_ | - ... <br> - ... <br> - ... |