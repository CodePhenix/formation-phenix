# Exemples d'Activités Professionnelles

Pour vous permettre d'aborder plus sereinement la rédaction de votre Dossier Professionnel, vous allez commencer par sélectionner les :

- exercices,
- petits projets,
- _activités professionnelles_...

que vous avez pu faire pendant la formation et à les lister simplement dans le fichier eap (dossier 2.DP-eap -> eap.md).

Ainsi tout au long de la formation, lorsque vous aurez terminé un projet intermédiaire ou un exercice complet, vous viendrez l'ajouter dans ce fichier eap.md, pour après l'inscrire dans votre DP plus facilement et sans urgence. 

- Si vous avez un doute sur une compétence, relisez la page de cette CP dans le fichier REAC
- Si les doutes persistent, on peut en parler ensemble !

Vous trouverez des exemples complets d'activités professionnelles dans le fichier exemples-eap (dossier 2.DP-eap -> exemples-ap.md). Ce ne sont que des exemples, il faudra compléter le fichier eap.md avec vos propres mots.

**La dernière colonne est importante, c'est grâce à elle que vous saurez si vous avez bien compris ce qui est attendu dans chaque Compétence Professionnelle.**

## Instructions

Merci de sélectionner 1 à 3 exemples par Compétence Professionnelle. Inutile d'en faire plus, mieux vaut choisir un seul exercice bien maîtrisé plutôt que trois pas très bien compris !

**Vous ne pouvez pas choisir des exemples venant du projet personnel choisi pour votre dossier de projet.**

Exemple : _Je vais présenter mon projet perso de site vitrine pour mon restaurant, pour le dossier de projet... Alors, je ne peux pas choisir des exemples issus de ce projet pour mes activités professionnelles. Je choisis donc parmi les exercices et projets faits durant la formation._  

**Vous pouvez choisir un exemple qui couvre une CP ou un exemple qui va couvrir plusieurs CP à la fois ; le but étant tout de même d'avoir plusieurs exemples différents pour montrer que vous maîtrisez plusieurs sujets dans différents contextes (et pas 1 exemple pour les 4 CP !)**

## Definition of Done

- [ ] J'ai renseigné au minimum un exercice par Compétence Professionnelle.
- [ ] J'ai ajouté pour chaque exercice son nom et sa description détaillée.
- [ ] J'ai expliqué en détail mon choix d'exercice prouvant que je maîtrise la CP en question.

### Le mot de la fin
Cette partie va bien vous aider, ne lâchez rien !