# Critères d'évaluation des Compétences Professionnelles

## CP 1 : Installer et configurer son environnement de travail en fonction du projet web ou web mobile

Les outils de développement nécessaires sont installés et configurés (exemple : IDE = Visual Studio Code avec extension installée grâce au terminal, à partir d'un fichier vsix).

Les outils de gestion des versions et de collaboration sont installés (exemple : utilisation des commandes Git et de la plateforme GitLab).

La documentation technique de l'environnement de travail est comprise, en langue française ou anglaise (utilisation de DevDocs et de StackOverflow en anglais, avec parfois l'utilisation de LibreTranslate).

## CP 2 : Maquetter des interfaces utilisateur web ou web mobile

Les maquettes sont réalisées conformément au dossier de conception (zoning, wireframes, mockups = maquettes).

La charte graphique de l'entreprise / du projet est respectée (palette de couleurs, typographies).

Les exigences de sécurisation sont respectées (vérifier le type de données que l'on reçoit dans les `<inpu>` d'un formulaire).

Les maquettes tiennent compte de l'expérience utilisateur, y compris pour les personnes en situation de handicap et du type d'utilisation, y compris pour les équipements mobiles (avoir du responsive qui permet une lisibilité pour tous : attributs `alt` dans les `<img>`, attributs ARIA, contraste de couleurs correct).

L'enchainement des maquettes est formalisé par un schéma (arborescence, user flow).

La législation en vigueur est respectée, y compris celle relative à l'accessibilité (obligation d'ajouter les attributs `alt` pour les balises `<img>`, attention à la succession des titres).

## CP 3 : Réaliser des interfaces utilisateur statiques web ou web mobile

L'interface est conforme à la maquette et les besoins en éco-conception sont pris en compte (pas trop de couleurs ni d'animations trop lourdes).

L'interface tient compte de l'expérience utilisateur, y compris pour les personnes en situation de handicap (avoir un 'parcours utilisateur' logique).

L'interface respecte les recommandations de sécurité liées aux applications web ou web mobile (empêcher les utilisateurs d'inscrire du code HTML dans les commentaires, les messages et les entrées de formulaires).

L'interface s'adapte au type d'utilisation de l‘application, et notamment à la taille, au type et à la disposition du support, y compris pour les équipements mobiles (design responsive avec media queries pour desktop/mobile, généralement conception en mobile-first).

La règlementation en vigueur est respectée, y compris celle relative à l'accessibilité (navigation clavier pour les carousels, contrastes respectés).

Le site est visible sur les moteurs de recherche et le référencement dépend du public (pour plus tard, penser à utiliser le protocole HTTPS que HTTP si il y a une gestion de données utilisateurs sensibles + SEO adapté pour le type de public cible avec balises HTML `<title>` et `<meta description>` optimisées).

## CP 4 : Développer la partie dynamique des interfaces utilisateur web ou web mobile

L'interface utilisateur est conforme au dossier de conception.

L'interface est dynamique et l'expérience utilisateur est améliorée, y compris pour les personnes en situation de handicap (utilisation de composants interactifs (modales), animations légères).

Les recommandations de sécurité liées aux applications web et web mobile sont respectées (validation des inputs côté frontend).

La règlementation en vigueur sont respectées, y compris celle relative à l'accessibilité (avoir pensé à la gestion des données personnelles et des cookies).

Le code est documenté, en anglais si nécessaire.

## CP 5 : Mettre en place une base de données relationnelle

Les données du schéma conceptuel et leurs relations sont identifiées et prises en compte.

Le schéma physique est conforme aux besoins exprimés dans le dossier de conception et respecte les règles des bases de données relationnelles.

Les règles de nommage sont respectées.

La sécurité, l'intégrité et la confidentialité des données est assurée.

La base de données de tests mise en place est conforme au schéma physique.

Les utilisateurs sont créés avec leurs droits respectifs conformément au dossier de conception.

Un jeu d'essai complet est créé.

La base de données créée est sauvegardée et elle peut être restaurée en cas d'incident.

La documentation technique des bases de données est comprise, en langue française ou anglaise (niveau B1 du CECRL pour l'anglais).


## CP 6 : Développer des composants d'accès aux données SQL et NoSQL

Les traitements relatifs aux manipulations des données répondent aux fonctionnalités décrites dans le dossier de conception.

L'intégrité et la confidentialité des données sont maintenues.

Les cas d'exception sont pris en compte.

Les conflits d'accès aux données sont gérés.

Toutes les entrées sont contrôlées et validées dans les composants serveurs sécurisés.

Les tests unitaires et de sécurité sont associés à chaque composant.

La démarche structurée de résolution de problème est adaptée en cas de dysfonctionnement.

Le système de veille permet de suivre les évolutions technologiques et les problématiques de sécurité liées aux bases de données SQL et NoSQL.

## CP 7 : Développer des composants métier coté serveur

Les traitements répondent aux fonctionnalités décrites dans le dossier de conception.

Les composants métier sont sécurisés.

Les bonnes pratiques de la programmation orientée objet (POO) sont respectées.

Les règles de nommage sont conformes aux normes de qualité de l'entreprise.

Le code source est documenté, y compris en anglais.

La qualité du code est vérifiée, éventuellement à l'aide d'un utilitaire de contrôle de qualité de code.

Un jeu d'essai fonctionnel et les tests unitaires ont été réalisés pour les composants concernés.

Les tests de sécurité sont réalisés.

La démarche structurée de résolution de problème est adaptée en cas de dysfonctionnement.

## CP 8 : Documenter le déploiement d'une application dynamique web ou web mobile

La procédure de déploiement est rédigée ou mise à jour.

Les scripts de déploiement sont écrits et documentés.

Le système de veille permet de suivre les évolutions technologiques et les problématiques de sécurité liées au déploiement d'une application dynamique web ou web mobile, y compris dans le cadre d'une démarche DevOps.