# Dispositifs d'évaluation de la Présentation / Soutenance

## Durée totale

2h

### 1. Présentation d'un projet réalisé en amont de la session

Durée : 35 min

En amont de la session d'examen, le candidat réalise un ou plusieurs projets.

Il prépare un dossier de projet et un support de présentation de type diaporama.

Lors de l'examen, le jury prend connaissance du dossier de projet imprimé avant la présentation du candidat.

Le candidat présente ensuite son projet au jury.

**Bien montrer du code + le rendu dans les deux navigateurs (firefox et chrome), en montrant le responsive !**

CP évaluées : 

- Maquetter des interfaces utilisateur web ou web mobile
- Réaliser des interfaces utilisateur statiques web ou web mobile
- Développer la partie dynamique des interfaces utilisateur web ou web mobile
- Mettre en place une base de données relationnelle
- Développer des composants d’accès aux données SQL et NoSQL
- Développer des composants métier coté serveur

### 2. Entretien technique

Durée : 40 min

Le jury questionne le candidat sur la base de son dossier de projet et de sa présentation, afin de s'assurer de la maîtrise des compétences couvertes par le projet ou les projets.

Un questionnement complémentaire lui permet d'évaluer les compétences qui ne sont pas couvertes par le projet ou les projets.

L'entretien technique se déroule obligatoirement à l'issue de la présentation du projet réalisé en amont de la session.

CP évaluées : 

- Installer et configurer son environnement de travail en fonction du projet web ou web mobile
- Maquetter des interfaces utilisateur web ou web mobile
- Réaliser des interfaces utilisateur statiques web ou web mobile
- Développer la partie dynamique des interfaces utilisateur web ou web mobile
- Mettre en place une base de données relationnelle
- Développer des composants d’accès aux données SQL et NoSQL
- Développer des composants métier coté serveur
- Documenter le déploiement d’une application dynamique web ou web mobile


### 3. Questionnaire professionnel

Durée : 30min

L'ensemble des candidats répondent en même temps au questionnaire professionnel en présence d'un surveillant : une documentation au format papier et en langue anglaise est donnée (paragraphe, documentation, article de journal).

Le candidat étudie une documentation technique rédigée en anglais.

Il répond à :
- deux questions fermées à choix unique posées en français (QCM) ;
- deux questions ouvertes posées en anglais et amenant des réponses courtes, en rédigeant la réponse en anglais.

**Attention au recto-verso !!!**

CP évaluée : 
- Installer et configurer son environnement de travail en fonction du projet web ou web
mobile
- Mettre en place une base de données relationnelle

### 4. Entretien final

Durée : 15min

Temps d’échange avec le candidat sur le dossierprofessionnel.


#### Informations complémentaires concernant le questionnaire professionnel :

- L'ensemble des candidats répondent en même temps au questionnaire professionnel.

- Un surveillant est présent dans la salle.

- Les membres du jury évaluent les réponses du candidat avant sa présentation du projet ou des projets réalisés en amont de la session