# Détails des différents documents à rendre avant les épreuves

## Dossier Professionnel

- [ ] Se familiariser avec le document du Dossier Professionnel en le lisant une première fois (la trame officielle du Dossier Professionnel)
- [ ] Compléter la première page (Titre professionnel visé, Nom, Prénom, Adresse, Modalité d'accès) avec ses informations personnelles (pages 1/2)
- [ ] Compléter la page 'Titres, diplômes, CQP, attestations de formation' (à la fin)
- [ ] Parcourir le document REAC présentant les Compétences Professionnelles nécessaires pour l'obtention de la certification
- [ ] Renseigner au minimum un exercice par Compétence Professionnelle : **Mise à part pour la CP2, il ne faut pas mettre des exemples du projet personnel dans le dossier professionnel ; ça sera des exemples d'exercices réalisés tout au long de la formation**
- [ ] Expliquer en détail ce qui a été fait pendant l'exercice prouvant la maîtrise de la CP en question
- [ ] Mettre des captures d'écran du navigateur pour chaque exemple
- [ ] Mettre des captures d'écran du code en THEME CLAIR
- [ ] Expliquer chacune des captures d'écran, une image seule ne suffit pas
- [ ] Pas de fautes d'orthographe (se faire relire par un tiers ou utiliser un correcteur automatique)
- [ ] Toutes les phrases comportent une majuscule et un point
- [ ] Des zonings, wireframes et extraits des users stories et du cahier des charges pour la CP 2 ont été insérés
- [ ] Une fois tous les exemples ajoutés dans le Dossier Professionnel, compléter le sommaire avec le numéro des pages
- [ ] Remplir l'attestation sur l'honneur (à la fin) et la signer

## Dossier de Projet

- [ ] Hors page de garde, sommaire et annexes, le dossier de projet comporte entre 30 et 50 pages au maximum, schémas et illustrations compris
- [ ] Les annexes comportent 30 pages au maximum
- [ ] Avoir une trame de Dossier de Projet semblable à ceci :
```
I. Introduction
    1. Présentation du projet
    2. Facultatif : Présentation du contexte professionnel

II. Dossier de conception fonctionnel = Cahier des charges
    1. Enjeux
        1.1. Besoins
        1.2. Objectifs
    2. Fonctionnalités du projet
    3. Personnes cibles
        3.1. Cible principale 
        3.2. Cible secondaire 
        3.3. Cœur de cible
        3.4. Personas
    4. User stories
    5. Contraintes techniques et fonctionnelles
    6. Accessibilité
    7. Autres facultatifs (analyse concurrentielle, contexte métier)

III. Dossier de conception structurel = Conception UX/UI
    1. UI : charte graphique
        1.1. Palette de couleurs
        1.2. Typographie
    2. UX
        2.1. Arborescence
        2.2. Zoning (version mobile et desktop)
        2.3. Autres besoins (écoconception, sécurisation, législation)

IV. Maquettage
    1. Wireframes (version mobile et desktop)
    2. User flows
    3. Maquettes (version mobile et desktop)
    4. Autre facultatif (prototypes)

V. Gestion de projet
    1. Organisation de travail
    2. Technologies utilisées
        2.1. Environnement de développeur
        2.2. Environnement technique
            2.2.1. Technologies frontend
            2.2.2. Technologies backend

VI. Réalisations permettant la mise en œuvre des Compétences
    1. Pages développées
        1.1. Interfaces Utilisateur Statiques Web et Web Mobile
        1.2. Interfaces Utilisateur Dynamiques Web et Web Mobile
        1.3. Logique serveur et base de données
        1.4. Sécurité
        1.5. Déploiement
    2. SEO
    3. Compatibilité de navigateurs
    4. Accessibilité

VII. Retour d'expérience
    1. Difficultés rencontrées
    2. Évolutions possibles du site
    3. Évolution personnelle
VIII. Annexes
    1. MCD
    2. MLD
    3. Dictionnaire de données
    4. Routes backend
```
- [ ] Ajouter les zoning, wireframes, maquettes, user-flow, arborescence, user-stories en images
- [ ] La partie des réalisations permettant la mise en œuvre des compétences doit contenir :
    - **DES EXEMPLES DES FONCTIONNALITES : CA DOIT MARCHER, ET CA SE VOIT**
    - **DES CAPTURES D'ECRAN DU CODE EN THEME CLAIR**
    - **DES CAPTURES D'ECRAN DU SITE WEB**
    - **DES EXPLICATIONS DE CES EXEMPLES** (il ne faut pas seulement mettre une capture d'écran mais expliquer ce qui a été fait, comment ça a été implémenté dans le code)
- [ ] Carte blanche pour le visuel du dossier de projet (couleurs, police, titres)
- [ ] Ajouter une jolie image en page de garde (screenshot du site ou logo) avec son nom, le titre visé et le nom du projet
- [ ] Activer la numérotation de pages
- [ ] Le sommaire doit rendre compte exactement des parties du dossier de projet
- [ ] Rendre le dossier de projet propre, lisible, et vérifier les fautes d'orthographes

## Résumé du projet

- [ ] Le résumé du projet est en français d'une longueur d'environ 20 lignes soit 200 à 250 mots, ou environ 1200 caractères espaces non compris (il doit passer sur une page)
- [ ] Il comprend :
    - une introduction (d'où vient l'idée, pourquoi ce projet)
    - l'objectif de l'application
    - les principales fonctionnalités de l'application
    - les technologies front et back utilisées pour l'application

## Support de présentation du projet pour l'oral

- [ ] La présentation est sous format de diapositives (Powerpoint, Canva, Libre Office Impress, ...), entre 7 à 15 slides
- [ ] Elle doit comporter :
    - une présentation rapide de soi, puis du projet
    - une courte parenthèse sur l'historique de la période de projet en fin de formation (quelle a été l'organisation de travail)
    - l'expression des besoins du projet pour définir les objectifs et les limites du projet
    - le cahier des charges (rapidement : la cible principale, quelques user-stories, les contraintes techniques),
    - quelques zonings, wireframes et maquettes ainsi que des indications d'UX et d'UI (polices utilisées, palette de couleurs)
    - les fonctionnalités attendues
    - l'environnement technique
    - les réalisations permettant la mise en œuvre des compétences (captures d'écran d'une partie du code : **prendre les éléments de code les plus significatifs en thème light, ceux qui sont les plus complexes**
    - une slide prévue pour faire la transition avec la démonstration en direct du code
    - une synthèse (pourquoi pas les prochaines étapes du projet, un objectif professionnel après le titre, et une conclusion (satisfactions et difficultés rencontrées)
- [ ] Pas de phrases entières, que des titres et bullet-points
- [ ] Numéroter les slides (pour s'y retrouver, et savoir quoi dire à telle ou telle slide)
- [ ] Définir des transitions entre chaque slide

## Guide sous format papier pour l'oral

- [ ] Avoir un guide sous format papier pour l'oral
- [ ] Que ce soit écrit à la main ou à l'ordi puis imprimé, peu importe.
- [ ] Il complète ce qui est dit pendant l'oral, en s'appuyant sur ce qu'il y a d'écrit sur les slides de la présentation
- [ ] Il doit donc être plus fourni, avec des mots écrits assez gros pour guider pendant l'oral
- [ ] Rajouter pour chaque petit texte le numéro des slides approprié pour s'aider à se repérer
- [ ] Ne pas mettre tout ce qui est dit à l'oral, c'est une aide supplémentaire à la présentation powerpoint, mais ça ne doit pas reprendre mot pour mot chacune des phrases.

## Code du projet et maquettage

- [ ] Faire le maquettage (zonings, wireframes, maquettes, prototypes (pas obligatoire), arborescence, user-flows...)
- [ ] Coder le projet en entier (commenté et propre)
- [ ] Ajouter un fichier README et un fichier copyright pour les images
- [ ] Pousser le code du projet sur GitHub/GitLab
- [ ] Zipper (compresser) le projet

## Détails administratifs finaux

- [ ] Avoir signé les ECF remplis par le formateur
- [ ] Avoir converti le Dossier Professionnel, le Dossier de Projet, le résumé du projet, le support de présentation, sous format pdf
- [ ] Avoir imprimé le Dossier Professionnel, le Dossier de Projet, le support de présentation 
- [ ] Mettre son IDE en thème clair pour le jour de l'oral
- [ ] Réviser ce qui a été vu pendant la formation, s'entrainer à l'oral, s'entrainer pour l'épreuve d'anglais
