import { inverseChaineDeCaractere } from "./easy";

it("devrait retourner une chaine de caractère avec les lettres inversées", () => {
  const mot = "hello";
  const resultatAttendu = "olleh"; // le résultat attendu
  const resultat = inverseChaineDeCaractere(mot); // l'exécution de la fonction
  expect(resultat).toEqual(resultatAttendu); // la vérification que le résultat est égal au résultat attendu
});
