export const inverseChaineDeCaractere = function(mot) {
  return mot
    .split("")
    .reverse()
    .join("");
};
